TiRogue v0.1
~~~~~~~~~~~~

by Christopher Waudby
caw47@cam.ac.uk

THIS IS AN EARLY ALPHA VERSION - i.e. BUGGY!!!
Don't blame me for what it does to your calc,
although I've not had any crashes yet...!

Please email me with comments and bug reports.

This game is the start of a clone of the rogue / 
Angband series of games. You wander round a dungeon
killing stuff etc. Symbols as follows:

.	Open floor
#	Wall
@	You
M	Monster
<	Ascending staircase
>	Descending staircase

Commands:

5	Rest (regain hp)
1-9	Move
Arrows	Scroll map
<	Ascend staircase
>	Descend staircase
Esc	Exit with save
QUIT	Give up - next time you'll start at
	beginning again.

There's a lot to do to this game - items, different
monsters, a much better attack system (rather than
the defender unconditionaly loses exactly one hp),
projectile weapons, magic, lighting. A high priority is a
random level generator.

Anyone who feels they could lend a hand please get
in touch.

Have fun!
