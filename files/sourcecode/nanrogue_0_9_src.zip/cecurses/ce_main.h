
#if !defined(AFX_PPCTEST_H__9DBFC8C3_C2F3_47FF_8D34_9A63C9E81417__INCLUDED_)
#define AFX_PPCTEST_H__9DBFC8C3_C2F3_47FF_8D34_9A63C9E81417__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"

#define MENU_HEIGHT 26

#define CONSOLE_ROWS 24
#define CONSOLE_COLS 80
#define CONSOLE_CHAR_HEIGHT 7
#define CONSOLE_CHAR_WIDTH 5

#define ZOOM_CHAR_HEIGHT 12
#define ZOOM_CHAR_WIDTH 7

#define WM_CONSOLE_STARTME ( WM_APP + 76 )
#define WM_CONSOLE_THREAD_DONE ( WM_APP + 77 )
#define WM_CONSOLE_GET_SAVENAME ( WM_APP + 78 )
#define WM_CONSOLE_MOVE_ROGUE ( WM_APP + 79 )
#define WM_CONSOLE_MESSAGE ( WM_APP + 80 )
#define WM_CONSOLE_HIT_POINTS ( WM_APP + 81 )

typedef struct MyConsoleKey
{
    int iKey;
    MyConsoleKey *pNext;
} MyConsoleKey;

typedef struct MyConsole
{
    TCHAR tchConsole[ CONSOLE_ROWS * CONSOLE_COLS ];
    HWND hMainWindow;
    HFONT hFont;
    HFONT hZoomFont;
    WORD wCurRow;
    WORD wCurCol;

    BOOL fDirty;
    WORD wDirtyLeft, wDirtyRight, wDirtyTop, wDirtyBottom;

    HANDLE hConsoleThread;

    HANDLE hEvent;
    MyConsoleKey *pKeyList;
    BOOL fQuit;

    char szLoadPath[ MAX_PATH ];

    BOOL fScrollFollowsRogue;
    int nScrollOffset;

    TCHAR tszCharName[ MAX_PATH ];

    TCHAR tszMessage[ MAX_PATH ];
    int nHPIcon;

    int nZoomX;
    int nZoomY;
} MyConsole;

extern MyConsole *g_theConsole;

#endif // !defined(AFX_PPCTEST_H__9DBFC8C3_C2F3_47FF_8D34_9A63C9E81417__INCLUDED_)
