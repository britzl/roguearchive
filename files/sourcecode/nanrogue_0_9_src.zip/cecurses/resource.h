    //{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ppctest.rc
//
#define IDS_APP_TITLE                   1
#define IDS_HELLO                       2
#define IDC_PPCTEST                     3
#define IDI_PPCTEST                     101
#define IDM_MENU                        102
#define IDD_ABOUTBOX                    103
#define IDS_HELP                        104
#define IDD_WELCOME                     105
#define IDB_MENUBAR                     106
#define IDD_ZOOM                        107
#define IDS_COMMAND1                    301
#define IDC_NEW                         1001
#define IDC_LOAD                        1002
#define IDC_NAME                        1003
#define IDC_BUTTON1                     1004
#define IDC_LOADCOMBO                   1005
#define IDM_MAIN_COMMAND1               40001
#define IDM_HELP_ABOUT                  40003
#define IDM_LOAD                        40004
#define IDM_SAVE                        40005
#define IDM_QUIT                        40006
#define IDM_NEW                         40007
#define IDM_TOOLS                       40008
#define IDS_CAP_TOOLS                   40010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40011
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
