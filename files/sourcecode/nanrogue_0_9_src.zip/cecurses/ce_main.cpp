#include "stdafx.h"
#include "ce_main.h"
#include "ce_curses.h"
#include "ce_fileio.h"
#include <commctrl.h>
#include <aygshell.h>
#include <sipapi.h>
#include <commdlg.h>

#define MAX_LOADSTRING 100

#define WM_BUTTON_MESSAGE 444
#define WM_BUTTON_HP 445

struct MYSHMENUBARINFO 
{
    DWORD cbSize; 
    HWND hwndParent; 
    DWORD dwFlags; 
    UINT nToolBarId; 
    HINSTANCE hInstRes; 
    int nBmpId; 
    int cBmpImages; 
    HWND hwndMB; 
};

//
// General use Global Variables:
//
HINSTANCE g_hInst; // The current instance
HWND g_hwndCB; // The command bar handle
HMODULE g_hAygShell;
BOOL ( __stdcall *g_pSHCreateMenuBar )( MYSHMENUBARINFO * );
DWORD g_dwCBClientHeight;

//
// Console global variables.
//
MyConsole *g_theConsole;
extern "C" int LINES = CONSOLE_ROWS;
extern "C" int COLS = CONSOLE_COLS;
WINDOW scr_buf;
extern "C" WINDOW *curscr = &scr_buf;

#ifdef NANANGBAND
TCHAR g_tszRegKey[] = L"Software\nanAngband";
#endif
#ifdef NANROGUE
TCHAR g_tszRegKey[] = L"Software\nanRogue";
TCHAR g_tszFileFilter[ MAX_PATH ];
TCHAR g_tszFileExtension[] = L"rog";
#endif

//static SHACTIVATEINFO s_sai;

// Forward declarations of functions included in this code module:
ATOM				MyRegisterClass	(HINSTANCE, LPTSTR);
BOOL				InitInstance	(HINSTANCE, int);
LRESULT CALLBACK	WndProc			(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About			(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	Welcome			(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK    Zoom            (HWND, UINT, WPARAM, LPARAM);
HWND				CreateRpCommandBar( HWND, int nHPState );

BOOL InitConsole( HWND hWnd );
BOOL ResizeConsole( MyConsole *pCon, BOOL fRaiseInputPanel );
BOOL PaintConsole( MyConsole *pCon );
BOOL RunConsole( MyConsole *pCon );
void DestroyConsole( MyConsole *pCon );
DWORD WINAPI ConThread( void *pParam );

#ifdef NANROGUE
void GetSaveName( HWND hWnd, char *szFilename, int cchFilename );
BOOL GetLoadName( HWND hWnd, MyConsole *pCon );
void SanitizeFileName( TCHAR *tszFilename );
#endif

extern "C" main( int argc, char *argv[] );

int WINAPI WinMain(	HINSTANCE hInstance,
					HINSTANCE hPrevInstance,
					LPTSTR    lpCmdLine,
					int       nCmdShow)
{
	MSG msg;
	HACCEL hAccelTable;

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_PPCTEST);

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return msg.wParam;
}

//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    It is important to call this function so that the application 
//    will get 'well formed' small icons associated with it.
//
ATOM MyRegisterClass(HINSTANCE hInstance, LPTSTR szWindowClass)
{
	WNDCLASS	wc;

    wc.style			= CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc		= (WNDPROC) WndProc;
    wc.cbClsExtra		= 0;
    wc.cbWndExtra		= 0;
    wc.hInstance		= hInstance;
    wc.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_PPCTEST));
    wc.hCursor			= 0;
    wc.hbrBackground	= (HBRUSH) GetStockObject(WHITE_BRUSH);
    wc.lpszMenuName		= 0;
    wc.lpszClassName	= szWindowClass;

	return RegisterClass(&wc);
}

//
//  FUNCTION: InitInstance(HANDLE, int)
//
//  PURPOSE: Saves instance handle and creates main window
//
//  COMMENTS:
//
//    In this function, we save the instance handle in a global variable and
//    create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
	HWND	hWnd = NULL;
	TCHAR	szTitle[MAX_LOADSTRING];			// The title bar text
	TCHAR	szWindowClass[MAX_LOADSTRING];		// The window class name

#ifdef NANROGUE
    //
    // Make the file filter string for load/save.
    //
    _tcscpy( g_tszFileFilter, L"*.rog *.rog " );
    TCHAR *ptszTemp = g_tszFileFilter;
    while( *ptszTemp )
    {
        if( *ptszTemp == L' ' )
        {
            *ptszTemp = L'\0';
        }
        ptszTemp++;
    }
#endif

	g_hInst = hInstance;		// Store instance handle in our global variable
	// Initialize global strings
	LoadString(hInstance, IDC_PPCTEST, szWindowClass, MAX_LOADSTRING);
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);

    //
    // See if we can load optional shell functions.
    //
    g_hAygShell = LoadLibrary( L"AygShell.dll" );
    if( g_hAygShell )
    {
        g_pSHCreateMenuBar = ( BOOL ( __stdcall *)( MYSHMENUBARINFO * ) )
            GetProcAddress( g_hAygShell, L"SHCreateMenuBar" );
    }

	//If it is already running, then focus on the window
	hWnd = FindWindow(szWindowClass, szTitle);	
	if (hWnd) 
	{
		SetForegroundWindow ((HWND) (((DWORD)hWnd) | 0x01));    
		return 0;
	} 

	MyRegisterClass(hInstance, szWindowClass);
	
	RECT	rect;
	GetClientRect(hWnd, &rect);
	
	hWnd = CreateWindow(szWindowClass, szTitle, WS_VISIBLE | WS_HSCROLL,
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL);
	if (!hWnd)
	{	
		return FALSE;
	}

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	return( TRUE );
}

//
//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	TCHAR szHello[MAX_LOADSTRING];

    MyConsole *pCon = g_theConsole;
    HMENU hMenu;
    WORD iButton;
    int iAction;

    switch (message) 
    {
    case WM_COMMAND:
        wmId    = LOWORD(wParam); 
        wmEvent = HIWORD(wParam); 
        // Parse the menu selections:
        switch (wmId)
        {
        case IDM_HELP_ABOUT:
            DialogBox(g_hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);

            break;

        case IDM_QUIT:
        case IDOK:
            SendMessage(hWnd, WM_ACTIVATE, MAKEWPARAM(WA_INACTIVE, 0), (LPARAM)hWnd);
            PostMessage (hWnd, WM_CLOSE, 0, 0);

            break;
        case WM_BUTTON_MESSAGE:
            MessageBox( hWnd, pCon->tszMessage, L"Message", MB_OK );
            break;

        default:
            return DefWindowProc(hWnd, message, wParam, lParam);

        }
        break;

    case WM_CREATE:
        g_hwndCB = CreateRpCommandBar( hWnd, 0 );
        PostMessage( hWnd, WM_CONSOLE_STARTME, 0, 0 );
        break;

    case WM_CONSOLE_STARTME:
        InitConsole( hWnd );

        pCon = g_theConsole;

        while( TRUE )
        {
            iAction = DialogBox( g_hInst,
                                 (LPCTSTR) IDD_WELCOME,
                                 hWnd,
                                 (DLGPROC) Welcome );

            BOOL fRunDialogAgain = FALSE;
            switch( iAction )
            {
            case IDC_NEW:
                pCon->szLoadPath[ 0 ] = '\0';
                RunConsole( pCon );
                break;

#ifdef NANROGUE
            case IDC_LOAD:
                if( !GetLoadName( hWnd, pCon ) )
                {
                    fRunDialogAgain = TRUE;
                    break;
                }
                
                RunConsole( pCon );
                break;
#endif

            case IDCANCEL:
            default:
                PostMessage( hWnd, WM_CLOSE, 0, 0 );
                break;
                
            }

            if( !fRunDialogAgain )
            {
                break;
            }
        }

        break;

    case WM_PAINT:
        if( pCon )
        {
            PaintConsole( pCon );
        }

        break; 

    case WM_CONSOLE_THREAD_DONE:
        CloseHandle( pCon->hConsoleThread );
        pCon->hConsoleThread = NULL;
        PostMessage( hWnd, WM_CLOSE, 0, 0 );
        break;

#ifdef NANROGUE
    case WM_CONSOLE_GET_SAVENAME:
        {
            int cchFilename = (int) wParam;
            char *szFilename = (char *) lParam;
            GetSaveName( hWnd, szFilename, cchFilename );
        }
        break;
#endif

    case WM_DESTROY:
        DestroyConsole( pCon );
        CommandBar_Destroy(g_hwndCB);
        PostQuitMessage(0);
        break;

    case WM_SETTINGCHANGE:
        if( pCon )
        {
            ResizeConsole( pCon, FALSE );
        }
        break;

    case WM_HSCROLL:
        {
            SCROLLINFO ScrollInfo;
            ScrollInfo.cbSize = sizeof( ScrollInfo );
            ScrollInfo.fMask = SIF_POS;
            GetScrollInfo( hWnd, SB_HORZ, &ScrollInfo );

            int nScrollCode = (int)LOWORD(wParam);
            int nPos = ScrollInfo.nPos;
            switch( nScrollCode )
            {
            case SB_PAGELEFT:
                nPos -= 8;
                break;

            case SB_PAGERIGHT:
                nPos += 8;
                break;

            case SB_LINELEFT:
                nPos -= 1;
                break;

            case SB_LINERIGHT:
                nPos += 1;
                break;

            case SB_THUMBPOSITION:
            case SB_THUMBTRACK:
                nPos = (int)HIWORD(wParam);
                break;

            default:
                break;
            }

            SetScrollPos( hWnd, SB_HORZ, nPos, TRUE );
            InvalidateRect( hWnd, NULL, TRUE );
            UpdateWindow( hWnd );
        }

        break;
   
    case WM_CHAR:
        if( pCon )
        {
            TCHAR tch = (TCHAR) wParam;
            
            MyConsoleKey *pKey = new MyConsoleKey;
            if( !pKey )
            {
                break;
            }

            char chKey;
            WideCharToMultiByte( CP_ACP,
                                 0,
                                 &tch,
                                 1,
                                 &chKey,
                                 1, 
                                 NULL, 
                                 NULL );
            pKey->iKey = chKey;
            pKey->pNext = pCon->pKeyList;
            pCon->pKeyList = pKey;

            SetEvent( pCon->hEvent );
        }

        break;

    case WM_KEYDOWN:
        if( pCon )
        {
            //
            // Map arrows to movement keys.
            //
            TCHAR tch = (TCHAR) wParam;
            switch( tch )
            {
            case VK_UP:
                tch = L'k';
                SendMessage( hWnd, WM_CHAR, (WPARAM) tch, lParam );
                break;

            case VK_DOWN:
                tch = L'j';
                SendMessage( hWnd, WM_CHAR, (WPARAM) tch, lParam );
                break;

            case VK_LEFT:
                tch = L'h';
                SendMessage( hWnd, WM_CHAR, (WPARAM) tch, lParam );
                break;

            case VK_RIGHT:
                tch = L'l';
                SendMessage( hWnd, WM_CHAR, (WPARAM) tch, lParam );
                break;
            }
        }
        break;

    case WM_LBUTTONUP:
        {
            SCROLLINFO ScrollInfo;
            ScrollInfo.cbSize = sizeof( ScrollInfo );
            ScrollInfo.fMask = SIF_POS;
            GetScrollInfo( hWnd, SB_HORZ, &ScrollInfo );
            int nPos = ScrollInfo.nPos;

            int xPos = LOWORD( lParam );
            int yPos = HIWORD( lParam );
            pCon->nZoomX = xPos / CONSOLE_CHAR_WIDTH + nPos;
            pCon->nZoomY = yPos / CONSOLE_CHAR_HEIGHT;
            DialogBox( g_hInst,
                       (LPCTSTR) IDD_ZOOM,
                       hWnd,
                       (DLGPROC) Zoom );
        }
        break;
        
    case WM_CONSOLE_MOVE_ROGUE:
        if( g_theConsole->fScrollFollowsRogue )
        {
            SCROLLINFO ScrollInfo;
            ScrollInfo.cbSize = sizeof( ScrollInfo );
            ScrollInfo.fMask = SIF_POS;
            GetScrollInfo( hWnd, SB_HORZ, &ScrollInfo );

            int nPos = ScrollInfo.nPos;
            int nNewPos = lParam + g_theConsole->nScrollOffset;

            SetScrollPos( hWnd,
                          SB_HORZ,
                          nNewPos,
                          TRUE );

            //
            // Be sure the scroll pos is actually within the "real" range
            // before actually scrolling the display.
            //
            if( nNewPos > 31 )
            {
                nNewPos = 31;
            }
            if( nNewPos < 0 )
            {
                nNewPos = 0;
            }

            ScrollWindowEx( hWnd,
                            ( nPos - nNewPos ) * CONSOLE_CHAR_WIDTH,
                            0,
                            NULL,
                            NULL,
                            NULL,
                            NULL,
                            SW_ERASE | SW_INVALIDATE );

            UpdateWindow( hWnd );
        }
        break;

    case WM_CONSOLE_MESSAGE:
        {
            TCHAR *pszMessage = (TCHAR *) lParam;
            _tcscpy( pCon->tszMessage, pszMessage );
            delete pszMessage;
        }
        break;

    case WM_CONSOLE_HIT_POINTS:
        {
            int nNewIcon = ( 100 - lParam ) * 8 / 100;

            if( nNewIcon != g_theConsole->nHPIcon )
            {
                CommandBar_Destroy(g_hwndCB);
                g_hwndCB = CreateRpCommandBar( hWnd, nNewIcon );
                g_theConsole->nHPIcon = nNewIcon;
            }
        }
        break;
                
    case WM_CLOSE:
        if( g_theConsole->hConsoleThread )
        {
            pCon->fQuit = TRUE;
            SetEvent( pCon->hEvent );

            WaitForSingleObject( g_theConsole->hConsoleThread, 5000 );
            CloseHandle( pCon->hConsoleThread );
            pCon->hConsoleThread = NULL;
        }
        return( DefWindowProc(hWnd, message, wParam, lParam) );
        break;
        
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

///////////////////////////////////////////////////////////////////////////////

HWND CreateRpCommandBar( HWND hwnd, int nHPState )
{
    TBBUTTON Buttons[] =
    {
        {
            0, WM_BUTTON_MESSAGE, TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, -1
        },
        {
            1 + nHPState, WM_BUTTON_HP, TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, -1
        }
    };

    if( g_pSHCreateMenuBar )
    {
        g_dwCBClientHeight = 0;

        MYSHMENUBARINFO mbi;

        memset(&mbi, 0, sizeof(MYSHMENUBARINFO));
        mbi.cbSize     = sizeof(MYSHMENUBARINFO);
        mbi.hwndParent = hwnd;
        mbi.nToolBarId = IDM_MENU;
        mbi.hInstRes   = g_hInst;
        mbi.nBmpId     = 0;
        mbi.cBmpImages = 0;

        if( !( *g_pSHCreateMenuBar )( &mbi ) )
        {
            return( NULL );
        }

        BOOL fRet = CommandBar_AddBitmap( mbi.hwndMB,
                                          g_hInst,
                                          IDB_MENUBAR, 
                                          10, 
                                          16, 
                                          16 );
        fRet = CommandBar_AddButtons( mbi.hwndMB,
                                      2,
                                      &Buttons[ 0 ] );
        fRet = CommandBar_Show( mbi.hwndMB, TRUE );
        return( mbi.hwndMB );
    }
    else
    {
        HWND hRet = CommandBar_Create( g_hInst, hwnd, 777 );

        CommandBar_InsertMenubar( hRet, g_hInst, IDM_MENU, 0 );

        BOOL fRet = CommandBar_AddBitmap( hRet,
                                          g_hInst,
                                          IDB_MENUBAR, 
                                          10, 
                                          16, 
                                          16 );
        fRet = CommandBar_AddButtons( hRet,
                                      2,
                                      &Buttons[ 0 ] );

        CommandBar_AddAdornments( hRet, 0, 0 );

        RECT rcWindow;
        GetWindowRect( hwnd, &rcWindow );

        g_dwCBClientHeight = CommandBar_Height( hRet );

        return( hRet );
    }
}

///////////////////////////////////////////////////////////////////////////////

LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
    case WM_INITDIALOG:
        {
            HWND hWnd = GetParent( hDlg );
            RECT rcDlg, rcParent;
            GetWindowRect( hDlg, &rcDlg );
            GetWindowRect( hWnd, &rcParent );
            
            LONG lWidth = rcDlg.right - rcDlg.left;
            LONG lHeight = rcDlg.bottom - rcDlg.top;
            
            MoveWindow( hDlg, 
                        ( rcParent.right + rcParent.left - lWidth ) / 2,
                        ( rcParent.top + rcParent.bottom - lHeight ) / 2,
                        lWidth,
                        lHeight,
                        FALSE );
            
            return TRUE; 
        }
        break;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK) {
            EndDialog(hDlg, LOWORD(wParam));
            return TRUE;
        }
        break;
	}
    return FALSE;
}

///////////////////////////////////////////////////////////////////////////////

// Mesage handler for the Welcome box.
LRESULT CALLBACK Welcome(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
    case WM_INITDIALOG:
        {
            HWND hWnd = GetParent( hDlg );
            RECT rcDlg, rcParent;
            GetWindowRect( hDlg, &rcDlg );
            GetWindowRect( hWnd, &rcParent );
            
            LONG lWidth = rcDlg.right - rcDlg.left;
            LONG lHeight = rcDlg.bottom - rcDlg.top;
            
            MoveWindow( hDlg, 
                        ( rcParent.right + rcParent.left - lWidth ) / 2,
                        ( rcParent.top + rcParent.bottom - lHeight ) / 2,
                        lWidth,
                        lHeight,
                        FALSE );

#ifdef NANANGBAND
            char *szFileName = ce_makeauxpathname( "lib\\save\\*." );
            TCHAR tszFName[ MAX_PATH ];
            MultiByteToWideChar( CP_ACP, 
                                 0,
                                 szFileName, 
                                 -1,
                                 tszFName,
                                 MAX_PATH );
            delete szFileName;

            WIN32_FIND_DATA Find;
            HANDLE hFind;
            hFind = FindFirstFile( tszFName,
                                   &Find );
            while( hFind != INVALID_HANDLE_VALUE )
            {
                TCHAR *tszName = Find.cFileName;
                while( *tszName )
                {
                    tszName++;
                }

                while( ( *tszName != L'\\' ) &&
                       ( tszName != Find.cFileName ) )
                {
                    tszName--;
                }

                if( *tszName == L'\\' )
                {
                    tszName++;
                }

                SendDlgItemMessage( hDlg,
                                    IDC_LOADCOMBO,
                                    CB_ADDSTRING,
                                    0,
                                    (LPARAM) tszName );

                if( FindNextFile( hFind, &Find ) )
                {
                    continue;
                }

                FindClose( hFind );
                hFind = INVALID_HANDLE_VALUE;
            }
#endif

            HKEY hKey;
            DWORD dwBlah;
            LONG lRet = RegCreateKeyEx( HKEY_CURRENT_USER,
                                        g_tszRegKey,
                                        0,
                                        NULL,
                                        0,
                                        0,
                                        NULL,
                                        &hKey,
                                        &dwBlah );
            if( lRet == ERROR_SUCCESS )
            {
                TCHAR tszName[ MAX_PATH ];
                DWORD dwType;
                DWORD dwLen = MAX_PATH;
                lRet = RegQueryValueEx( hKey,
                                        L"CharName",
                                        NULL,
                                        &dwType,
                                        (BYTE *) tszName,
                                        &dwLen );
                if( lRet == ERROR_SUCCESS && dwType == REG_SZ && dwLen > 0 )
                {
#ifdef NANANGBAND
                    SetDlgItemText( hDlg,
                                    IDC_LOADCOMBO,
                                    tszName );
#endif
#ifdef NANROGUE
                    SetDlgItemText( hDlg,
                                    IDC_NAME,
                                    tszName );
#endif
                }

                RegCloseKey( hKey );
            }

            return TRUE; 
        }
        
    case WM_COMMAND:
        if( LOWORD( wParam ) == IDC_LOAD )
        {
            EndDialog(hDlg, LOWORD(wParam));
            return TRUE;
        }

        if( LOWORD( wParam ) == IDC_NEW )
        {
#ifdef NANANGBAND
            GetDlgItemText( hDlg, 
                            IDC_LOADCOMBO,
                            g_theConsole->tszCharName, 
                            MAX_PATH );
#endif
#ifdef NANROGUE
            GetDlgItemText( hDlg, 
                            IDC_NAME,
                            g_theConsole->tszCharName, 
                            MAX_PATH );
#endif

            if( _tcslen( g_theConsole->tszCharName ) == 0 )
            {
                MessageBox( hDlg, 
                            L"You must enter a character name to start a new game.",
                            L"Character Name",
                            MB_OK | MB_ICONEXCLAMATION );
                return( TRUE );
            }

            TCHAR *tch = g_theConsole->tszCharName;
            while( *tch )
            {
                if( !IsCharAlphaNumeric( *tch ) )
                {
                    MessageBox( hDlg, 
                                L"Character names can only contain letters and numbers.",
                                L"Character Name",
                                MB_OK | MB_ICONEXCLAMATION );
                    return( TRUE );
                }
                    
                tch++;
            }

            HKEY hKey;
            DWORD dwBlah;
            LONG lRet = RegCreateKeyEx( HKEY_CURRENT_USER,
                                        g_tszRegKey,
                                        0,
                                        NULL,
                                        0,
                                        0,
                                        NULL,
                                        &hKey,
                                        &dwBlah );
            if( lRet == ERROR_SUCCESS )
            {
                lRet = RegSetValueEx( 
                    hKey,
                    L"CharName",
                    0,
                    REG_SZ,
                    (BYTE *) g_theConsole->tszCharName,
                    ( sizeof( TCHAR ) * 
                      ( _tcslen( g_theConsole->tszCharName ) + 1 ) ) );

                RegCloseKey( hKey );
            }

            EndDialog(hDlg, LOWORD(wParam));
            return TRUE;
        }
        break;

    case WM_CLOSE:
        EndDialog( hDlg, IDCANCEL );
        break;

	}
    return FALSE;
}

///////////////////////////////////////////////////////////////////////////////

#define ZOOM_WIDTH 224
#define ZOOM_HEIGHT 120

// Mesage handler for the Zoom box.
LRESULT CALLBACK Zoom(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
    case WM_INITDIALOG:
        {
            HWND hWnd = GetParent( hDlg );
            RECT rcDlg, rcClient, rcParent;
            GetWindowRect( hDlg, &rcDlg );
            GetClientRect( hDlg, &rcClient );
            GetWindowRect( hWnd, &rcParent );
            
            LONG lWidth = rcDlg.right - rcDlg.left;
            LONG lClientWidth = rcClient.right - rcClient.left;
            lWidth = lWidth - lClientWidth + ZOOM_WIDTH;
            LONG lHeight = rcDlg.bottom - rcDlg.top;
            LONG lClientHeight = rcClient.bottom - rcClient.top;
            lHeight = lHeight - lClientHeight + ZOOM_HEIGHT;
            
            MoveWindow( hDlg, 
                        ( rcParent.right + rcParent.left - lWidth ) / 2,
                        ( rcParent.top + rcParent.bottom - lHeight ) / 2,
                        lWidth,
                        lHeight,
                        FALSE );

            return TRUE; 
        }

    case WM_PAINT:
        {
            HDC hdc;
            PAINTSTRUCT ps;
            MyConsole *pCon = g_theConsole;

            hdc = BeginPaint(hDlg, &ps);

            RECT rcClient;
            GetClientRect( hDlg, &rcClient );
            FillRect( hdc, &rcClient, (HBRUSH) ( COLOR_BACKGROUND + 1 ) );

            HGDIOBJ hold = SelectObject( hdc, pCon->hZoomFont );
    
            int i, j;
            RECT rt;

            int y = pCon->nZoomY - ( ZOOM_HEIGHT / ZOOM_CHAR_HEIGHT / 2 );
            if( y < 0 )
            {
                y = 0;
            }
            else if( y + ZOOM_HEIGHT / ZOOM_CHAR_HEIGHT >= CONSOLE_ROWS )
            {
                y = CONSOLE_ROWS - ZOOM_HEIGHT / ZOOM_CHAR_HEIGHT;
            }

            int x = pCon->nZoomX - ( ZOOM_WIDTH / ZOOM_CHAR_WIDTH / 2 );
            if( x < 0 )
            {
                x = 0;
            }
            else if( x + ZOOM_WIDTH / ZOOM_CHAR_WIDTH >= CONSOLE_COLS )
            {
                x = CONSOLE_COLS - ZOOM_WIDTH / ZOOM_CHAR_WIDTH;
            }

            for( i = 0; i < ZOOM_HEIGHT / ZOOM_CHAR_HEIGHT; i++ )
            {
                for( j = 0; j < ZOOM_WIDTH / ZOOM_CHAR_WIDTH; j++ )
                {
                    rt.top = i * ZOOM_CHAR_HEIGHT;
                    rt.bottom = ( i + 1 ) * ZOOM_CHAR_HEIGHT;
                    rt.left = j * ZOOM_CHAR_WIDTH;
                    rt.right = ( j + 1 ) * ZOOM_CHAR_WIDTH;
                    DrawText( hdc, 
                              &pCon->tchConsole[ ( ( i + y ) * CONSOLE_COLS + 
                                                   x + j ) ],
                              1, 
                              &rt, 
                              DT_SINGLELINE | DT_TOP | DT_LEFT );
                }
            }
    
            SelectObject( hdc, hold );
            
            EndPaint(hDlg, &ps);
        }
        break;

    case WM_LBUTTONUP:
    case WM_CLOSE:
        EndDialog( hDlg, IDCANCEL );
        break;

	}
    return FALSE;
}

///////////////////////////////////////////////////////////////////////////////

void ClearConsole( MyConsole *pCon )
{
    int i;
    for( i = 0; i < CONSOLE_ROWS * CONSOLE_COLS; i++ )
    {
        pCon->tchConsole[ i ] = L' ';
    }
    pCon->wCurRow = 0;
    pCon->wCurCol = 0;
}

///////////////////////////////////////////////////////////////////////////////

BOOL ResizeConsole( MyConsole *pCon, BOOL fRaiseInputPanel )
{
    HWND hWnd = pCon->hMainWindow;

    if( fRaiseInputPanel )
    { 
        SipShowIM( SIPF_ON );
    }

    SIPINFO sipInfo;
    sipInfo.cbSize = sizeof( sipInfo );
    sipInfo.dwImDataSize = 0;
    sipInfo.pvImData = NULL;
    SipGetInfo( &sipInfo );

    RECT rcWindow, rcClient;
    GetWindowRect( hWnd, &rcWindow );
    GetClientRect( hWnd, &rcClient );

    if( !( sipInfo.fdwFlags & SIPF_ON ) )
    {
        RECT rcCB;
        GetWindowRect( g_hwndCB, &rcCB );
        if( rcCB.top != 0 )
        {
            sipInfo.rcVisibleDesktop.bottom = rcCB.top;
        }
    }

    rcWindow.bottom = max( 
        ( rcWindow.bottom - rcClient.bottom + 
          CONSOLE_ROWS * CONSOLE_CHAR_HEIGHT ),
        ( sipInfo.rcVisibleDesktop.bottom ) );

    MoveWindow( hWnd, 
                rcWindow.left,
                rcWindow.top,
                rcWindow.right - rcWindow.left,
                rcWindow.bottom - rcWindow.top,
                FALSE);

    GetWindowRect( hWnd, &rcWindow );

    return( TRUE );
}

///////////////////////////////////////////////////////////////////////////////

BOOL InitConsole( HWND hWnd )
{
    BOOL fRet = FALSE;

    HANDLE hThread = NULL;

    do
    {
        g_theConsole = new MyConsole;
        if( !g_theConsole )
        {
            break;
        }

        ClearConsole( g_theConsole );
        
        g_theConsole->tszCharName[ 0 ] = L'\0';
        g_theConsole->tszMessage[ 0 ] = L'\0';
        g_theConsole->nHPIcon = 0;

        g_theConsole->hMainWindow = hWnd;
        g_theConsole->hEvent = CreateEvent( NULL, FALSE, FALSE, NULL );
        if( !g_theConsole->hEvent )
        {
            break;
        }
        g_theConsole->fQuit = FALSE;
        g_theConsole->pKeyList = NULL;
        g_theConsole->hConsoleThread = NULL;
        g_theConsole->fScrollFollowsRogue = TRUE;
        g_theConsole->nScrollOffset = -24;

        g_theConsole->fDirty = TRUE;
        g_theConsole->wDirtyLeft = 0;
        g_theConsole->wDirtyRight = CONSOLE_COLS - 1;
        g_theConsole->wDirtyTop = 0;
        g_theConsole->wDirtyBottom = CONSOLE_ROWS - 1;

        LOGFONT lf;
        lf.lfHeight = CONSOLE_CHAR_HEIGHT + 1;
        lf.lfWidth = CONSOLE_CHAR_WIDTH;
        lf.lfEscapement = 0;
        lf.lfOrientation = 0;
        lf.lfWeight = FW_DONTCARE;
        lf.lfItalic = FALSE;
        lf.lfUnderline = FALSE;
        lf.lfStrikeOut = FALSE;
        lf.lfCharSet = DEFAULT_CHARSET;
        lf.lfOutPrecision = OUT_DEFAULT_PRECIS;
        lf.lfClipPrecision = CLIP_DEFAULT_PRECIS;
        lf.lfQuality = DEFAULT_QUALITY;
        lf.lfPitchAndFamily = FIXED_PITCH | FF_DONTCARE;
        lf.lfFaceName[0] = '\0';
        g_theConsole->hFont = CreateFontIndirect( &lf );

        lf.lfHeight = ZOOM_CHAR_HEIGHT;
        lf.lfWidth = ZOOM_CHAR_WIDTH;
        lf.lfEscapement = 0;
        lf.lfOrientation = 0;
        lf.lfWeight = FW_DONTCARE;
        lf.lfItalic = FALSE;
        lf.lfUnderline = FALSE;
        lf.lfStrikeOut = FALSE;
        lf.lfCharSet = DEFAULT_CHARSET;
        lf.lfOutPrecision = OUT_DEFAULT_PRECIS;
        lf.lfClipPrecision = CLIP_DEFAULT_PRECIS;
        lf.lfQuality = DEFAULT_QUALITY;
        lf.lfPitchAndFamily = FIXED_PITCH | FF_DONTCARE;
        lf.lfFaceName[0] = '\0';
        g_theConsole->hZoomFont = CreateFontIndirect( &lf );

        fRet = ResizeConsole( g_theConsole, TRUE );
        if( !fRet )
        {
            break;
        }

        SCROLLINFO ScrollInfo;
        ScrollInfo.cbSize = sizeof( ScrollInfo );
        ScrollInfo.fMask = SIF_ALL;
        ScrollInfo.nMin = 0;
        ScrollInfo.nMax = 31;
        ScrollInfo.nPage = 0;
        ScrollInfo.nPos = 0;
        SetScrollInfo( hWnd, SB_HORZ, &ScrollInfo, TRUE );

        fRet = TRUE;
    }
    while( FALSE );

    if( hThread )
    {
        CloseHandle( hThread );
    }

    return( fRet );
}

///////////////////////////////////////////////////////////////////////////////

BOOL PaintConsole( MyConsole *pCon )
{
	HDC hdc;
    HWND hWnd = pCon->hMainWindow;
	PAINTSTRUCT ps;

    SCROLLINFO ScrollInfo;
    ScrollInfo.cbSize = sizeof( ScrollInfo );
    ScrollInfo.fMask = SIF_POS;
    GetScrollInfo( hWnd, SB_HORZ, &ScrollInfo );

    if( pCon->fDirty )
    {
        pCon->fDirty = FALSE;
        RECT rcDirty;
        rcDirty.left = 
            ( pCon->wDirtyLeft - ScrollInfo.nPos ) * CONSOLE_CHAR_WIDTH;
        rcDirty.right =
            ( pCon->wDirtyRight - ScrollInfo.nPos + 1 ) * CONSOLE_CHAR_WIDTH - 1;
        rcDirty.top =
            g_dwCBClientHeight + ( pCon->wDirtyTop * CONSOLE_CHAR_HEIGHT );
        rcDirty.bottom =
            g_dwCBClientHeight - 1 +
            ( ( pCon->wDirtyBottom + 1 ) * CONSOLE_CHAR_HEIGHT );
        InvalidateRect( hWnd, &rcDirty, TRUE );
    }

    hdc = BeginPaint(hWnd, &ps);
    
    HGDIOBJ hold = SelectObject( hdc, pCon->hFont );
    
    RECT rcDirty = ps.rcPaint;
    rcDirty.top = ( rcDirty.top - g_dwCBClientHeight ) / CONSOLE_CHAR_HEIGHT;
    rcDirty.bottom = ( rcDirty.bottom - g_dwCBClientHeight ) / CONSOLE_CHAR_HEIGHT;
    rcDirty.left = ( rcDirty.left / CONSOLE_CHAR_WIDTH ) + ScrollInfo.nPos;
    rcDirty.right = ( rcDirty.right / CONSOLE_CHAR_WIDTH ) + ScrollInfo.nPos;

    if( rcDirty.bottom >= CONSOLE_ROWS )
    {
        rcDirty.bottom = CONSOLE_ROWS - 1;
    }

    int i, j;
    RECT rt;
    
    for( i = rcDirty.top; i <= rcDirty.bottom; i++ )
    {
        rt.top = g_dwCBClientHeight + i * CONSOLE_CHAR_HEIGHT - 1;
        rt.bottom = g_dwCBClientHeight + ( i + 1 ) * CONSOLE_CHAR_HEIGHT;
        rt.left = ( rcDirty.left - ScrollInfo.nPos ) * CONSOLE_CHAR_WIDTH;
        rt.right = ( rcDirty.right - ScrollInfo.nPos + 1 ) * CONSOLE_CHAR_WIDTH -
            1;
        DrawText( hdc, 
                  &pCon->tchConsole[ i * CONSOLE_COLS + rcDirty.left ],
                  rcDirty.right - rcDirty.left + 1, 
                  &rt, 
                  DT_SINGLELINE | DT_TOP | DT_LEFT );
    }
    
    SelectObject( hdc, hold );

    EndPaint(hWnd, &ps);

    return( TRUE );
}

///////////////////////////////////////////////////////////////////////////////

BOOL RunConsole( MyConsole *pCon )
{
    if( pCon->hConsoleThread )
    {
        return( FALSE );
    }

    pCon->hConsoleThread = CreateThread( NULL,
                                         0,
                                         ConThread,
                                         g_theConsole,
                                         0,
                                         NULL );

    return( pCon->hConsoleThread != NULL );
}

///////////////////////////////////////////////////////////////////////////////

void DestroyConsole( MyConsole *pCon )
{
    if( !pCon || pCon != g_theConsole )
    {
        return;
    }

    if( pCon->hConsoleThread )
    {
        pCon->fQuit = TRUE;
        SetEvent( pCon->hEvent );

        WaitForSingleObject( pCon->hConsoleThread, 5000 );
        CloseHandle( pCon->hConsoleThread );
        pCon->hConsoleThread = NULL;
    }

    if( pCon->hFont )
    {
        DeleteObject( pCon->hFont );
    }

    if( pCon->hZoomFont )
    {
        DeleteObject( pCon->hZoomFont );
    }

    if( pCon->hEvent )
    {
        CloseHandle( pCon->hEvent );
    }

    MyConsoleKey *pKey = pCon->pKeyList;
    while( pKey )
    {
        MyConsoleKey *pNext = pKey->pNext;
        delete pKey;
        pKey = pNext;
    }

    delete pCon;
    g_theConsole = NULL;
}

///////////////////////////////////////////////////////////////////////////////

DWORD WINAPI ConThread( void *pParam )
{
#ifdef NANANGBAND
    char *argv[2];
    argv[0] = "none";
    char argv2[ MAX_PATH ];
    sprintf( argv2, "-u%S", g_theConsole->tszCharName );
    argv[1] = argv2;
    main( 2, argv );
#endif
#ifdef NANROGUE
    if( g_theConsole->szLoadPath[ 0 ] == '\0' )
    {
        char *argv[1];
        argv[0] = "none";
        main( 1, argv );
    }
    else
    {
        char *argv[2];
        argv[0] = "none";
        argv[1] = g_theConsole->szLoadPath;
        main( 2, argv );
    }
#endif

    return( 0 );
}

///////////////////////////////////////////////////////////////////////////////

#ifdef NANROGUE
void GetSaveName( HWND hWnd, char *szFilename, int cchFilename )
{
    TCHAR tszFileName[ MAX_PATH ];

    _tcscpy( tszFileName, g_theConsole->tszCharName );
    _tcscat( tszFileName, L"." );
    _tcscat( tszFileName, g_tszFileExtension );

    OPENFILENAME ofn;
    ofn.lStructSize = sizeof( ofn );
    ofn.hwndOwner = hWnd;
    ofn.hInstance = NULL;
    ofn.lpstrFilter = g_tszFileFilter;
    ofn.lpstrCustomFilter = NULL;
    ofn.nMaxCustFilter = 0;
    ofn.nFilterIndex = 1;
    ofn.lpstrFile = tszFileName;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrFileTitle = NULL;
    ofn.nMaxFileTitle = 0;
    ofn.lpstrInitialDir = NULL;
    ofn.lpstrTitle = L"Select Save File";
    ofn.Flags = OFN_OVERWRITEPROMPT | OFN_HIDEREADONLY;
    ofn.nFileOffset = 0;
    ofn.nFileExtension = 0;
    ofn.lpstrDefExt = g_tszFileExtension;
    ofn.lCustData = 0;
    ofn.lpfnHook = NULL;
    ofn.lpTemplateName = NULL;
    
    if( !GetSaveFileName( &ofn ) )
    {
        szFilename[ 0 ] = '\0';
        return;
    }

    SanitizeFileName( tszFileName );

    WideCharToMultiByte( CP_ACP,
                         0,
                         tszFileName,
                         -1,
                         szFilename,
                         cchFilename, 
                         NULL, 
                         NULL );
}

///////////////////////////////////////////////////////////////////////////////

BOOL GetLoadName( HWND hWnd, MyConsole *pCon )
{
    TCHAR tszFileName[ MAX_PATH ] = L"Save.rog";

    OPENFILENAME ofn;
    ofn.lStructSize = sizeof( ofn );
    ofn.hwndOwner = hWnd;
    ofn.hInstance = NULL;
    ofn.lpstrFilter = g_tszFileFilter;
    ofn.lpstrCustomFilter = NULL;
    ofn.nMaxCustFilter = 0;
    ofn.nFilterIndex = 0;
    ofn.lpstrFile = tszFileName;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrFileTitle = NULL;
    ofn.nMaxFileTitle = 0;
    ofn.lpstrInitialDir = NULL;
    ofn.lpstrTitle = L"Select Save File";
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
    ofn.nFileOffset = 0;
    ofn.nFileExtension = 0;
    ofn.lpstrDefExt = g_tszFileExtension;
    ofn.lCustData = 0;
    ofn.lpfnHook = NULL;
    ofn.lpTemplateName = NULL;
    
    if( !GetOpenFileName( &ofn ) )
    {
        return( FALSE );
    }

    SanitizeFileName( tszFileName );

    WideCharToMultiByte( CP_ACP,
                         0,
                         tszFileName,
                         -1,
                         pCon->szLoadPath,
                         MAX_PATH, 
                         NULL, 
                         NULL );

    return( TRUE );
}

///////////////////////////////////////////////////////////////////////////////

void SanitizeFileName( TCHAR *tszFilename )
{
    int nLen = _tcslen( tszFilename );

    if( tszFilename[ 0 ] == L'\\' && tszFilename[ 1 ] == L'\\' )
    {
        memmove( tszFilename, ( tszFilename + 1 ), nLen * sizeof( TCHAR ) );
        nLen--;
    }

    if( ( nLen < 3 ) ||
        ( tszFilename[ nLen - 1 ] != g_tszFileExtension[ 2 ] ) ||
        ( tszFilename[ nLen - 2 ] != g_tszFileExtension[ 1 ] ) ||
        ( tszFilename[ nLen - 3 ] != g_tszFileExtension[ 0 ] ) )
    {
        _tcscat( tszFilename, L"." );
        _tcscat( tszFilename, g_tszFileExtension );
    }
}
#endif
