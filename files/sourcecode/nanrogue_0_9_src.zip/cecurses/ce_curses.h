#ifndef __CE_CURSES_H
#define __CE_CURSES_H

#ifdef __cplusplus
extern "C"
{
#endif
    struct _win_st {
        short _cury, _curx;
        short _miny, _minx;
        short _maxy, _maxx;
    };

    typedef struct _win_st WINDOW;

    extern int LINES, COLS;
    extern WINDOW *curscr;
    extern char *CL;

    char *md_gdtcf();

    void initscr();
    void endwin();
    void move(short row, short col);
    void addch(int ch);
    void mvaddch(short row, short col, int ch);
    int mvinch(short row, short col);
    void refresh();
    void wrefresh( WINDOW *scr );
    void crmode();
    void cbreak();
    void nocbreak();
    void noecho();
    void echo();
    void nonl();
    void nl();
    void clrtoeol();
    void addstr(char *str);
    void mvaddstr(short row, short col, char *str);
    void clear();
    void perror( char *szError );
    int setuid(int iUID );
    int getuid();
    int geteuid();
    void standend();
    void standout();
    WINDOW *newwin( int rows, int cols, int y, int x );
    void wmove( WINDOW *win, int y, int x );
    void wclear( WINDOW *win );
    void mvcur( int y, int x, int row, int col );
    void delwin( WINDOW *win );
    void touchwin( WINDOW *win );
    void waddch( WINDOW *win, int ch );
    void wclrtoeol( WINDOW *win );

    void ce_moverogue( int nPos );
    void ce_message( char *szMessage );
    void ce_hp( int nCur, int nMax );

#define getyx( win, y, x ) { y = win->_cury; x = win->_curx; }

#ifdef __cplusplus
}
#endif

#endif
