#ifndef __CE_FILEIO_H
#define __CE_FILEIO_H

#define fopen ce_fopen
#define fclose ce_fclose
#define fflush ce_fflush
#define ferror ce_ferror
#define feof ce_feof

#define fread ce_fread
#define fwrite ce_fwrite
#define fprintf ce_fprintf

#define rewind ce_rewind
#define getchar ce_getchar
#define fgets ce_fgets
#define putc ce_putc
#define fputc ce_putc
#define getc ce_getc
#define time ce_time
#define tmpnam ce_tmpnam
#define remove ce_remove
#define rename ce_rename
#define open ce_open
#define lseek ce_lseek
#define read ce_read
#define write ce_write
#define close ce_close

#define islower ce_islower
#define isdigit ce_isdigit
#define isupper ce_isupper
#define isspace ce_isspace
#define isprint ce_isprint
#define iscntrl ce_iscntrl
#define isalpha ce_isalpha
#define strtol ce_strtol

#define O_BINARY 0
#define O_CREAT 1
#define O_EXCL 2
#define O_WRONLY 4
#define O_RDONLY 8
#define O_RDWR 16

#ifdef __cplusplus
extern "C" {
#endif
    FILE *ce_fopen( const char *filename, const char *mode );
    int ce_fclose( FILE *stream );
    int ce_ferror( FILE *stream );
    int ce_fflush( FILE *stream );
    int ce_feof( FILE *stream );

    size_t ce_fwrite( const void *buffer,
                      size_t size,
                      size_t count,
                      FILE *stream );
    size_t ce_fread( void *buffer, 
                     size_t size, 
                     size_t count,
                     FILE *stream );
    int ce_fprintf( FILE *stream, const char *format, ... );

    ce_rewind( FILE *stream );
    int ce_getchar();
    int ce_getchar_nodelay();
    char *ce_fgets( char *string, int n, FILE *stream );
    void ce_putc( int ch, FILE *stream );
    int ce_getc( FILE *stream );

    time_t ce_time( time_t *timer );

    char *ce_tmpnam( char *dummy );
    int ce_remove( char *fname );
    int ce_rename( const char *oldname, const char *newname );

    int ce_open( const char *filename, int oflag );
    long ce_lseek( int handle, long offset, int origin );
    int ce_read( int handle, void *buffer, unsigned int count );
    int ce_write( int handle, const void *buffer, unsigned int count );
    int ce_close( int handle );

    int ce_islower( int c );
    int ce_isdigit( int c );
    int ce_isupper( int c );
    int ce_isspace( int c );
    int ce_isprint( int c );
    int ce_iscntrl( int c );
    int ce_isalpha( int c );
    long ce_strtol( const char *nptr, char **endptr, int base );

    //
    // This isn't actually a normal Unix function, but I want to put it here
    // anyways.
    //
    int ce_getfilename( char *szFilename, int cchFilename );
    char *ce_makeauxpathname( char *szFile );
#ifdef __cplusplus
}
#endif

#endif
