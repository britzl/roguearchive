#include "stdafx.h"
#include "ce_fileio.h"
#include "ce_main.h"

#define MAX_FILE_HANDLES 256
static HANDLE s_hFiles[ MAX_FILE_HANDLES ];
static BOOL s_fFilesInit = FALSE;

///////////////////////////////////////////////////////////////////////////////

extern "C" FILE *ce_fopen( const char *filename, const char *mode )
{
    DWORD dwAccess = 0;
    DWORD dwCreate = OPEN_EXISTING;

    if( strstr( mode, "w" ) )
    {
        dwAccess |= GENERIC_WRITE;
        dwCreate = CREATE_ALWAYS;
    }

    if( strstr( mode, "r" ) )
    {
        dwAccess |= GENERIC_READ;
        dwCreate = OPEN_EXISTING;
    }

    TCHAR tszFName[ MAX_PATH ];
    MultiByteToWideChar( CP_ACP, 0, filename, -1, tszFName, MAX_PATH );
    HANDLE hFile = CreateFile( tszFName,
                               dwAccess,
                               0,
                               NULL,
                               dwCreate,
                               0,
                               NULL );

    if( INVALID_HANDLE_VALUE == hFile )
    {
        return( NULL );
    }
    else
    {
        return( (FILE *) hFile );
    }
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_fclose( FILE *stream )
{
    CloseHandle( (HANDLE) stream );
    return( 0 );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_ferror( FILE *stream )
{
    return( 0 );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_fflush( FILE *stream )
{
    return( 0 );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_feof( FILE *stream )
{
    HANDLE hFile = (HANDLE) stream;
    DWORD dwSize = GetFileSize( hFile, NULL );
    DWORD dwPos = SetFilePointer( hFile, 0, NULL, FILE_CURRENT );
    if( dwPos == dwSize )
    {
        return( TRUE );
    }
    else
    {
        return( FALSE );
    }
}

///////////////////////////////////////////////////////////////////////////////

extern "C" size_t ce_fwrite( const void *buffer,
                             size_t size,
                             size_t count,
                             FILE *stream )
{
    DWORD dwToWrite = size * count;
    DWORD dwWritten;
    if( WriteFile( (HANDLE) stream,
                   buffer,
                   dwToWrite,
                   &dwWritten,
                   NULL ) )
    {
        return( dwWritten / size );
    }
    else
    {
        return( 0 );
    }
}

///////////////////////////////////////////////////////////////////////////////

extern "C" size_t ce_fread( void *buffer, 
                            size_t size, 
                            size_t count,
                            FILE *stream )
{
    DWORD dwToRead = size * count;
    DWORD dwRead;
    if( ReadFile( (HANDLE) stream,
                  buffer,
                  dwToRead,
                  &dwRead,
                  NULL ) )
    {
        return( dwRead / size );
    }
    else
    {
        return( 0 );
    }
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_fprintf( FILE *stream, const char *format, ... )
{
    va_list Args;
    char szStr[ MAX_PATH ];
    int x;

    va_start( Args, x );
    vsprintf( szStr, format, Args );

    int nLen = strlen( szStr );
    return( ce_fwrite( szStr, 1, nLen, stream ) );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" ce_rewind( FILE *stream )
{
    SetFilePointer( (HANDLE) stream, 0, NULL, FILE_BEGIN );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_getchar()
{
    do
    {
        WaitForSingleObject( g_theConsole->hEvent, INFINITE );
        
        if( g_theConsole->fQuit )
        {
            ExitThread( 0 );
            return( 0 );
        }
    }
    while( !g_theConsole->pKeyList );

    MyConsoleKey *pKey = g_theConsole->pKeyList;
    g_theConsole->pKeyList = pKey->pNext;

    int iRet = pKey->iKey;
    delete pKey;

    if( g_theConsole->pKeyList )
    {
        SetEvent( g_theConsole->hEvent );
    }

    return( iRet );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_getchar_nodelay()
{
    if( g_theConsole->fQuit )
    {
        ExitThread( 0 );
        return( 0 );
    }

    if( !g_theConsole->pKeyList )
    {
        return( EOF );
    }

    MyConsoleKey *pKey = g_theConsole->pKeyList;
    g_theConsole->pKeyList = pKey->pNext;

    int iRet = pKey->iKey;
    delete pKey;

    if( g_theConsole->pKeyList )
    {
        SetEvent( g_theConsole->hEvent );
    }

    return( iRet );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" char *ce_fgets( char *string, int n, FILE *stream )
{
    DWORD dwRead;
    BOOL fRet = ReadFile( (HANDLE) stream,
                          string,
                          n - 1,
                          &dwRead,
                          NULL );
    if( !fRet || !dwRead )
    {
        return( NULL );
    }

    SetFilePointer( (HANDLE) stream, -dwRead, NULL, FILE_CURRENT );

    DWORD i;
    for( i = 0; ; i++ )
    {
        if( ( i < ( n - 1 ) ) && 
            ( string[ i ] == '\r' ) &&
            ( string[ i + 1 ] == '\n' ) )
        {
            //
            // Whoops... CR/LF... just make the CR disappear.
            //
            string[ i ] = '\n';
            string[ i + 1 ] = '\0';
            SetFilePointer( (HANDLE) stream, i + 2, NULL, FILE_CURRENT );
            return( string );
        }

        if( ( string[ i ] == '\n' ) || ( i == ( n - 1 ) ) )
        {
            string[ i + 1 ] = '\0';
            SetFilePointer( (HANDLE) stream, i + 1, NULL, FILE_CURRENT );
            return( string );
        }
    }

    //
    // Included just to make the compiler happy.
    //
    return( NULL );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void ce_putc( int ch, FILE *stream )
{
    char c = (char) ch;
    ce_fwrite( &c, 1, 1, stream );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_getc( FILE *stream )
{
    char ch;
    if( ce_fread( &ch, 1, 1, stream ) )
    {
        return( (int) ch );
    }
    else
    {
        return( EOF );
    }
}

///////////////////////////////////////////////////////////////////////////////

extern "C" time_t ce_time( time_t *timer )
{
    time_t temp = (time_t) GetTickCount();
    if( timer )
    {
        *timer = temp;
    }
    return( temp );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" char *ce_tmpnam( char *dummy )
{
    HMODULE hMod = GetModuleHandle( NULL );
    
    TCHAR tszPath[ MAX_PATH ];
    if( !GetModuleFileName( hMod, tszPath, MAX_PATH ) )
    {
        return( NULL );
    }

    int i = wcslen( tszPath );
    while( tszPath[ i ] != L'\\' )
    {
        i--;
    }
    tszPath[ i ] = L'\0';

    TCHAR tszName[ MAX_PATH ];
    i = 0;
    do
    {
        wsprintf( tszName, L"%s\\%u.tmp", tszPath, GetTickCount() + i );
        if( 0xffffffff == GetFileAttributes( tszName ) )
        {
            break;
        }
        i++;
    }
    while( TRUE );

    char *pszName = new char[ wcslen( tszName ) + 1 ];
    WideCharToMultiByte( CP_ACP,
                         0,
                         tszName,
                         -1,
                         pszName,
                         MAX_PATH, 
                         NULL, 
                         NULL );

    return( pszName );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_remove( char *fname )
{
    TCHAR tszFilename[ MAX_PATH ];
    MultiByteToWideChar( CP_ACP,
                         0,
                         fname,
                         -1,
                         tszFilename,
                         MAX_PATH );
    if( DeleteFile( tszFilename ) )
    {
        return( 1 );
    }
    else
    {
        return( 0 );
    }
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_rename( const char *oldname, const char *newname )
{
    TCHAR tszOld[ MAX_PATH ];
    MultiByteToWideChar( CP_ACP,
                         0,
                         oldname,
                         -1,
                         tszOld,
                         MAX_PATH );
    TCHAR tszNew[ MAX_PATH ];
    MultiByteToWideChar( CP_ACP,
                         0,
                         newname,
                         -1,
                         tszNew,
                         MAX_PATH );
    if( MoveFile( tszOld, tszNew ) )
    {
        return( 1 );
    }
    else
    {
        return( 0 );
    }
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_open( const char *filename, int oflag )
{
    if( !s_fFilesInit )
    {
        int i;
        for( i = 0; i < MAX_FILE_HANDLES; i++ )
        {
            s_hFiles[ i ] = INVALID_HANDLE_VALUE;
        }
        s_fFilesInit = TRUE;
    }

    DWORD dwAccess = GENERIC_WRITE | GENERIC_READ;
    DWORD dwCreate = OPEN_EXISTING;

    if( oflag & O_CREAT )
    {
        dwCreate = CREATE_ALWAYS;
    }
    else
    {
        dwCreate = OPEN_EXISTING;
    }

    TCHAR tszFName[ MAX_PATH ];
    MultiByteToWideChar( CP_ACP, 0, filename, -1, tszFName, MAX_PATH );
    HANDLE hFile = CreateFile( tszFName,
                               dwAccess,
                               0,
                               NULL,
                               dwCreate,
                               0,
                               NULL );

    if( INVALID_HANDLE_VALUE == hFile )
    {
        return( -1 );
    }

    int i;
    for( i = 0; i < MAX_FILE_HANDLES; i++ )
    {
        if( s_hFiles[ i ] == INVALID_HANDLE_VALUE )
        {
            s_hFiles[ i ] = hFile;
            return( i );
        }
    }

    CloseHandle( hFile );
    return( -1 );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" long ce_lseek( int handle, long offset, int origin )
{
    HANDLE hFile = s_hFiles[ handle ];
    if( origin == SEEK_SET )
    {
        return( SetFilePointer( hFile, offset, NULL, FILE_BEGIN ) );
    }

    return( 0 );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_read( int handle, void *buffer, unsigned int count )
{
    HANDLE hFile = s_hFiles[ handle ];
    DWORD dwRet;
    if( !ReadFile( hFile, buffer, count, &dwRet, NULL ) )
    {
        return( 0 );
    }

    return( dwRet );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_write( int handle, const void *buffer, unsigned int count )
{
    HANDLE hFile = s_hFiles[ handle ];
    DWORD dwRet;
    if( !WriteFile( hFile, buffer, count, &dwRet, NULL ) )
    {
        return( 0 );
    }

    return( dwRet );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_close( int handle )
{
    HANDLE hFile = s_hFiles[ handle ];
    s_hFiles[ handle ] = INVALID_HANDLE_VALUE;
    CloseHandle( hFile );
    return ( 0 );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_islower( int c )
{
    if( c >= 'a' && c <= 'z' )
    {
        return( 1 );
    }
    else
    {
        return( 0 );
    }
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_isdigit( int c )
{
    if( c >= '0' && c <= '9' )
    {
        return( 1 );
    }
    else
    {
        return( 0 );
    }
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_isupper( int c )
{
    if( c >= 'A' && c <= 'Z' )
    {
        return( 1 );
    }
    else
    {
        return( 0 );
    }
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_isspace( int c )
{
    if( ( c >= 0x9 && c <= 0xd ) ||
        ( c == 0x20 ) )
    {
        return( 1 );
    }
    else
    {
        return( 0 );
    }
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_isprint( int c )
{
    if( c >= 0x20 && c <= 0x7e )
    {
        return( 1 );
    }
    else
    {
        return( 0 );
    }
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_iscntrl( int c )
{
    if( ( c >= 0x0 && c <= 0x1f ) ||
        ( c == 0x7f ) )
    {
        return( 1 );
    }
    else
    {
        return( 0 );
    }
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_isalpha( int c )
{
    if( ce_isupper( c ) || ce_islower( c ) )
    {
        return( 1 );
    }
    else
    {
        return( 0 );
    }
}

///////////////////////////////////////////////////////////////////////////////

extern "C" long ce_strtol( const char *nptr, char **endptr, int base )
{
    long lRet;
    if( nptr[ 0 ] == '0' && nptr[ 1 ] == 'x' )
    {
        sscanf( nptr, "%x", &lRet );
    }
    else
    {
        sscanf( nptr, "%d", &lRet );
    }
    return( lRet );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int ce_getfilename( char *szFilename, int cchFilename )
{
    SendMessage( g_theConsole->hMainWindow,
                 WM_CONSOLE_GET_SAVENAME,
                 (WPARAM) cchFilename,
                 (LPARAM) szFilename );

    if( szFilename[ 0 ] == '\0' )
    {
        return( 0 );
    }
    else
    {
        return( 1 );
    }
}

///////////////////////////////////////////////////////////////////////////////

extern "C" char *ce_makeauxpathname( char *szFile )
{
    HMODULE hMod = GetModuleHandle( NULL );
    
    TCHAR tszName[ MAX_PATH ];
    if( !GetModuleFileName( hMod, tszName, MAX_PATH ) )
    {
        return( NULL );
    }

    char szPath[ MAX_PATH ];
    WideCharToMultiByte( CP_ACP,
                         0,
                         tszName,
                         -1,
                         szPath,
                         MAX_PATH, 
                         NULL, 
                         NULL );

    int i = strlen( szPath );
    while( szPath[ i ] != '\\' )
    {
        i--;
    }
    if( szFile )
    {
        i++;
    }
    szPath[ i ] = '\0';

    int nLen = i + 1;
    if( szFile )
    {
        nLen += strlen( szFile );
    }

    char *szRet = new char[ nLen ];
    strcpy( szRet, szPath );
    if( szFile )
    {
        strcat( szRet, szFile );
    }
    return( szRet );
}
