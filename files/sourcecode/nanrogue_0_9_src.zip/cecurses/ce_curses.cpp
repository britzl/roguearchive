#include "stdafx.h"
#include "ce_main.h"
#include "ce_curses.h"

void SetConsoleDirty( MyConsole *pCon, WORD wX, WORD wY );
void ClearConsole( MyConsole *pCon );

///////////////////////////////////////////////////////////////////////////////

extern "C" void initscr()
{
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void endwin()
{
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void move(short row, short col)
{
    g_theConsole->wCurRow = row;
    g_theConsole->wCurCol = col;
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void addch(int ch)
{
    TCHAR tch;
    MultiByteToWideChar( CP_ACP, 0, (char *) (&ch), 1, &tch, 1 );
    g_theConsole->tchConsole[ ( g_theConsole->wCurRow * CONSOLE_COLS +
                                g_theConsole->wCurCol ) ] = tch;
    SetConsoleDirty( g_theConsole, 
                     g_theConsole->wCurCol, 
                     g_theConsole->wCurRow );
    g_theConsole->wCurCol++;
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void mvaddch(short row, short col, int ch)
{
	move(row, col);
	addch(ch);
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int mvinch(short row, short col)
{
	move(row, col);
    TCHAR tch = g_theConsole->tchConsole[ 
        ( g_theConsole->wCurRow * CONSOLE_COLS + g_theConsole->wCurCol ) ];
    char chRet;
    WideCharToMultiByte( CP_ACP, 0, &tch, 1, &chRet, 1, NULL, NULL );
	return( (int) chRet );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void refresh()
{
    HWND hWnd = g_theConsole->hMainWindow;
    PostMessage( hWnd, WM_PAINT, 0, 0 );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void wrefresh( WINDOW *scr )
{
    refresh();
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void crmode()
{
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void cbreak()
{
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void nocbreak()
{
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void noecho()
{
	/* crmode() takes care of this */
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void echo()
{
	/* crmode() takes care of this */
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void nonl()
{
	/* crmode() takes care of this */
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void nl()
{
	/* crmode() takes care of this */
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void clrtoeol()
{
    WORD wRow = g_theConsole->wCurRow;
    WORD wCol = g_theConsole->wCurCol;

    SetConsoleDirty( g_theConsole, 
                     g_theConsole->wCurCol, 
                     g_theConsole->wCurRow );
    SetConsoleDirty( g_theConsole, 
                     CONSOLE_COLS - 1, 
                     g_theConsole->wCurRow );

	for( ; wCol < CONSOLE_COLS; wCol++ )
    {
        g_theConsole->tchConsole[ wRow * CONSOLE_COLS + wCol ] = L' ';
	}
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void addstr(char *str)
{
	while (*str) {
		addch((int) *str++);
	}
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void mvaddstr(short row, short col, char *str)
{
	move(row, col);
	addstr(str);
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void clear()
{
    ClearConsole( g_theConsole );
    SetConsoleDirty( g_theConsole, 0, 0 );
    SetConsoleDirty( g_theConsole, CONSOLE_COLS - 1, CONSOLE_ROWS - 1 );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void perror( char *szError )
{
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int setuid(int iUID )
{
    return( 0 );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int getuid()
{
    return( 0 );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" int geteuid()
{
    return( 0 );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void standend()
{
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void standout()
{
}

///////////////////////////////////////////////////////////////////////////////

extern "C" WINDOW *newwin( int rows, int cols, int y, int x )
{
    WINDOW *ret = new WINDOW;
    ret->_cury = ret->_curx = 0;
    ret->_miny = y;
    ret->_minx = x;
    ret->_maxy = y + rows;
    ret->_maxx = x + cols;
    return( ret );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void wmove( WINDOW *win, int y, int x )
{
    win->_cury = win->_miny + y;
    win->_curx = win->_minx + x;
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void wclear( WINDOW *win )
{
    int i, j;
    for( j = win->_miny; j < win->_maxy; j++ )
    {
        for( i = win->_minx; i < win->_maxx; i++ )
        {
            mvaddch( j, i, ' ' );
        }
    }
    win->_curx = win->_cury = 0;
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void mvcur( int y, int x, int row, int col )
{
    move( row, col );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void delwin( WINDOW *win )
{
    delete win;
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void touchwin( WINDOW *win )
{
    SetConsoleDirty( g_theConsole, 0, 0 );
    SetConsoleDirty( g_theConsole, CONSOLE_COLS - 1, CONSOLE_ROWS - 1 );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void waddch( WINDOW *win, int ch )
{
    mvaddch( win->_miny + win->_cury, win->_minx + win->_curx, ch );
    win->_curx++;
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void wclrtoeol( WINDOW *win )
{
    while( win->_curx < win->_maxx)
    {
        waddch( win, ' ' );
    }
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void ce_moverogue( int nPos )
{
    PostMessage( g_theConsole->hMainWindow, 
                 WM_CONSOLE_MOVE_ROGUE,
                 0,
                 nPos );
}

///////////////////////////////////////////////////////////////////////////////
    
extern "C" void ce_message( char *szMessage )
{
    TCHAR *ptszMessage = new TCHAR[ strlen( szMessage ) + 1 ];
    MultiByteToWideChar( CP_ACP,
                         0,
                         szMessage,
                         -1,
                         ptszMessage,
                         MAX_PATH );
    PostMessage( g_theConsole->hMainWindow,
                 WM_CONSOLE_MESSAGE,
                 0,
                 (LPARAM) ptszMessage );
}

///////////////////////////////////////////////////////////////////////////////

extern "C" void ce_hp( int nCur, int nMax )
{
    PostMessage( g_theConsole->hMainWindow,
                 WM_CONSOLE_HIT_POINTS,
                 0,
                 nCur * 100 / nMax );
}

///////////////////////////////////////////////////////////////////////////////

void SetConsoleDirty( MyConsole *pCon, WORD wX, WORD wY )
{
    if( pCon->fDirty )
    {
        if( wX < pCon->wDirtyLeft )
        {
            pCon->wDirtyLeft = wX;
        }

        //
        // Hack... dirty things one column to the right of the expected, to
        // deal with some true-type font wackiness.
        //
        if( wX < COLS - 1 )
        {
            wX++;
        }

        if( wX > pCon->wDirtyRight )
        {
            pCon->wDirtyRight = wX;
        }
        if( wY < pCon->wDirtyTop )
        {
            pCon->wDirtyTop = wY;
        }
        if( wY > pCon->wDirtyBottom )
        {
            pCon->wDirtyBottom = wY;
        }
    }
    else
    {
        pCon->fDirty = TRUE;
        pCon->wDirtyLeft = wX;

        //
        // Hack... dirty things one column to the right of the expected, to
        // deal with some true-type font wackiness.
        //
        if( wX < COLS - 1 )
        {
            wX++;
        }
        pCon->wDirtyRight = wX;

        pCon->wDirtyTop = pCon->wDirtyBottom = wY;
    }
}

