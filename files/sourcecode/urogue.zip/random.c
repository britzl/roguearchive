/*
    random.c - random and associated routines lifted from 4.2BSD
   
    UltraRogue: Further Adventures in the Dungeons of Doom

    Based on  "Rogue: Exploring the dungeons of doom"
    Copyright (C) 1980,1981 by Michael Toy, Ken Arnold and Glenn Wichman
    All rights reserved

    Portions Copyright (C) 1984,1991 by Herb Chong

    THIS WORK CONTAINS UNPUBLISHED PROPRIETARY SOURCE CODE OF HERB CHONG
    The copyright notice above does not evidence any actual or intended
    publication of such source code.

    Possession, redistribution, or storage of this source code in any form,
    in an electronic retrieval system or otherwise, without prior written
    consent of Herb Chong is strictly prohibited.

    See the file LICENSE.TXT for more information.
             
    History

        7/28/85    UltraRogue 1.03a, Herb Chong
       12/30/90    UltraRogue 1.04a, Herb Chong
        8/14/93    UltraRogue 1.05a, Nick Kisseberth
*/

#include "rogue.h"


void
ur_srandom(unsigned x)
{
    srandom(x);
}

long
ur_random(void)
{
    return( random() );
}
