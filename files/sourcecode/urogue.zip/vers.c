/*
    vers.c - version number
         
    UltraRogue: Further Adventures in the Dungeons of Doom

    Based on  "Rogue: Exploring the dungeons of doom"
    Copyright (C) 1980,1981 by Michael Toy, Ken Arnold and Glenn Wichman
    All rights reserved

    Portions Copyright (C) 1984,1991 by Herb Chong

    THIS WORK CONTAINS UNPUBLISHED PROPRIETARY SOURCE CODE OF HERB CHONG
    The copyright notice above does not evidence any actual or intended
    publication of such source code.

    Possession, redistribution, or storage of this source code in any form,
    in an electronic retrieval system or otherwise, without prior written
    consent of Herb Chong is strictly prohibited.

    See the file LICENSE.TXT for more information.
                   
    History:
        4/21/81    Rogue 3.6 (vers.c 3.6)
       12/25/90    UltraRogue 1.04a, Herb Chong
        8/13/93    UltraRogue 1.05a, Nick Kisseberth
		7/21/95    UltraRogue 1.06a, Herb Chong
*/

const char *save_format = "UltraRogue Portable Save File Release 001\04";
const char *version     = "UltraRogue 1.06a October 1995";
const char *release     = "1.06 Alpha (October 1995)";
