/*
    save.c - save and restore routines
 
    UltraRogue: Further Adventures in the Dungeons of Doom

    Based on  "Rogue: Exploring the dungeons of doom"
    Copyright (C) 1980,1981 by Michael Toy, Ken Arnold and Glenn Wichman
    All rights reserved

    Portions Copyright (C) 1984,1991 by Herb Chong

    THIS WORK CONTAINS UNPUBLISHED PROPRIETARY SOURCE CODE OF HERB CHONG
    The copyright notice above does not evidence any actual or intended
    publication of such source code.

    Possession, redistribution, or storage of this source code in any form,
    in an electronic retrieval system or otherwise, without prior written
    consent of Herb Chong is strictly prohibited.

    See the file LICENSE.TXT for more information.
                 
    History

        6/16/81    Rogue 3.6 (save.c 3.9)
       12/30/90    UltraRogue 1.04a, Herb Chong
        8/13/93    UltraRogue 1.05a, Nick Kisseberth
*/

#define _ALL_SOURCE /* need to remove need for this AIXism */

#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include "rogue.h"

int
save_game(void)
{
    FILE *savefd;
    int c;
    char    buf[2 * LINELEN];
    char    oldfile[2*LINELEN];

    /* get file name */

    strcpy(oldfile,file_name);

    do
    {
        mpos = 0;

        if (oldfile[0] != '\0')
            msg("Save file [%s]: ", file_name);
        else
            msg("Save file as: ");

        mpos = 0;
        buf[0] = '\0';

        if (get_string(buf, cw) == QUIT)
        {
            msg("");
            return(FALSE);
        }

        if ( (buf[0] == 0) && (oldfile[0] != 0) )
            strcpy(file_name, oldfile);
        else if (buf[0] != 0)
            strcpy(file_name, buf);
        else
        {
            msg("");
            return(FALSE);
        }

        wclear(hw);
        wmove(hw, LINES - 1, 0);
        wrefresh(hw);

        if ((savefd = fopen(file_name, "w")) == NULL)
            msg(strerror(errno));    /* fake perror() */
    }
    while (savefd == NULL);

    /* write out [compressed?] file */

    save_file(savefd);
    return(TRUE);
}

int
restore(char *file)
{
    FILE *infd;
    char    *sp;
    char    buf[2 * LINELEN];

    if (strcmp(file, "-r") == 0)
        file = file_name;

    if ((infd = fopen(file, "r")) == NULL)
    {
        perror(file);
        return(FALSE);
    }

    if ( restore_file(infd) == FALSE )
        return(FALSE);

    /*
     * we do not close the file so that we will have a hold of the inode
     * for as long as possible
     */

    if (remove(file) < 0)
    {
        printf("Cannot unlink file\n");
        return(FALSE);
    }

    if ((sp = getenv("OPTIONS")) != NULL)
        parse_opts(sp);

    strcpy(file_name, file);

    clearok(cw, TRUE);
    touchwin(cw);
    noecho();
    nonl();

    while(playing)
    {
        do_daemons(BEFORE);
        do_fuses(BEFORE);

        command();  /* Command execution */

        if (after)
            do_after_effects();
    }

    fatal("");

    return(FALSE);
}
