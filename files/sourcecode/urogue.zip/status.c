/*
    status.c - functions for complex status determination of monsters/objects
         
    UltraRogue: Further Adventures in the Dungeons of Doom

    Based on  "Rogue: Exploring the dungeons of doom"
    Copyright (C) 1980,1981 by Michael Toy, Ken Arnold and Glenn Wichman
    All rights reserved

    Portions Copyright (C) 1984,1991 by Herb Chong

    THIS WORK CONTAINS UNPUBLISHED PROPRIETARY SOURCE CODE OF HERB CHONG
    The copyright notice above does not evidence any actual or intended
    publication of such source code.

    Possession, redistribution, or storage of this source code in any form,
    in an electronic retrieval system or otherwise, without prior written
    consent of Herb Chong is strictly prohibited.

    See the file LICENSE.TXT for more information.
                   
    History

        6/22/86    UltraRogue 1.03a, Herb Chong
        1/07/91    UltraRogue 1.04a, Herb Chong
        8/14/93    UltraRogue 1.05a, Nick Kisseberth
*/

#include "rogue.h"

/*
    has_defensive_spell()
        has monster cast a defensive spell.
        Any flags added here must also be in player_powers[].
*/

int
has_defensive_spell(struct thing th)
{
    if (on(th, HASOXYGEN))
        return(TRUE);
    if (on(th, CANFLY))
        return(TRUE);
    if (on(th, CANINWALL))
        return(TRUE);
    if (on(th, CANREFLECT))
        return(TRUE);
    if (on(th, CANSEE))
        return(TRUE);
    if (on(th, HASMSHIELD))
        return(TRUE);
    if (on(th, HASSHIELD))
        return(TRUE);
    if (on(th, ISHASTE))
        return(TRUE);
    if (on(th, ISREGEN))
        return(TRUE);
    if (on(th, ISDISGUISE))
        return(TRUE);
    if (on(th, ISINVIS))
        return(TRUE);
    if (on(th, NOCOLD))
        return(TRUE);
    if (on(th, NOFIRE))
        return(TRUE);
    if (on(th, ISELECTRIC))
        return(TRUE);

    return(FALSE);
}
