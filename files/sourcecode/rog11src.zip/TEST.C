main()
{
	int i=1;
	printf("START\n");
	while (i++) ;
	printf("STOP\n");
}
