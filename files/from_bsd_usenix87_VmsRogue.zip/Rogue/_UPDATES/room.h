#define MAXROOMS 9

#define NO_ROOM -1		/* these two only for doors[] */
#define DEAD_END -2

#define PASSAGE -3		/* current_room value */

#define SCOREFILE "dsk:[richs.games.rogue]SCORE_FILE"

