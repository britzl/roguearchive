#define swap(x,y) {int t; t = x; x = y; y = t;}
#define two_sort(x,y) if (x > y) {int t; t = x; x = y; y = t;}
#define swap_string(x,y) {char *t; t = x; x = y; y = t;}
