There is a new command line option, "-more".  What this option 
does is reduce the number of pauses in the game during combat and 
during tunneling by removing the "-more-" prompt at the end of 
messages.  This option has the potential to reduce your 
situational awareness.  You could, for example, fight a monster 
for a long time with a shovel instead of a holy avenger and not 
realize it until you are dead.  You could also potentially walk 
around and not realize that spells are being cast upon your 
character from some off-screen enemy.

With all of the new options that I have added, I set up a batch 
file called PLAY.BAT so that I can play with my favorite options:

     umoria -h -v177 -rp -d3000 -more

This turns off haggling, uses the 177 character for mineral veins, 
lets (R) armor give resistance against poison gas, pauses for 3000 
milliseconds (actually much less than that on my 800Mhz Athlon 
system) in between projectile movements, and reduces the number of 
instances where the game pauses to display "-more-".  I have also 
included the save file for a high level halfing mage character 
named FRODO.SAV.  I originally called him Frodor before he got 
killed by an ancient multi-hued dragon.  If you do not like 
starting characters from scratch, perhaps you can take him all the 
way to victory by playing:

     play frodor.sav

 -Ed L, June 1, 2003


In this latest release, wielded flame tongue weapons light up the 
area like a brass lantern that never runs out of fuel.  A flame 
tongue weapon that gives off no light is like a light sabre that 
gives off no light in the Jedi Knight II game.  This adds a new 
factor to consider when the time comes to decide whether or not to 
drop a flame tongue weapon in order to free up an inventory slot.  
This new feature also makes it possible to identify flame tongue 
weapons without using a scroll of identify by wielding the weapon 
in the dark.

Also, the, "You failed to get the spell off!" message is now 
displayed in red so that you can spot a failure in a magic cast 
with a glance.

-Ed Lee, February 23, 2003

Taking 0 damage from a poison gas attack seems to cause a panic 
save.  The poison_gas() routine now ends immediately when the 
player takes no damage from a poison gas attack.

-Ed Lee, September 8, 2002


I added a new command line option, -v, for specifying the magma 
and quartz vein decimal character code.  Example:

     umoria -v176

Valid character codes are numbers from 0 to 255, but only the 
values from 1 to 31 and 128 to 255 or 37 (the code for "%") would 
really make sense since most of the other characters are already 
used for something else or are not visible.

The see_wall() function now recognizes whatever is defined as the 
vein character with the -v option.  This change makes the run code 
treat whatever is defined as the vein character as a regular wall.

The vein character symbol is back to '%' by default.  This can be 
modified with the -v option described above.

-Ed Lee, September 6, 2002


This latest version adds color to the menus, automates the display 
of the menus, adds color to some messages and to the display of 
your statistics to enhance your situational awareness.  This 
version also adds a new command line option,

     -rp

for resisting poison gas if you effectively have R resistance 
through any combination of permanent or temporary resistance.

My shortcut for playing the game on my 800Mhz Athlon system has a 
line in its properties similar to:

     umoria.exe -h -rp -d3000

for playing without haggling, playing with poison resistance, with 
a delay of less than 3000 milliseconds between the display of bolt 
/ ball / breath weapons.  The -d option now also controls the 
delay for displaying thrown items and the display of the 
earthquake spell or prayer.

A detailed list of changes is recorded in the CHANGES file in the 
source directory.

-Ed Lee, September 6, 2002


Justin Martin Anderson's original code for saving color 
information in the COLOR.SAV file is a potential source of 
instability when the COLOR.SAV file already exists for one Moria 
save file and a different Moria save file with a different number 
of inventory items gets played.  Additionally, storing the 
player's inventory item colors in the COLOR.SAV file is 
unnecessary since the color information is stored in the 
object_list[] array and an index to the corresponding item in the 
object_list[] is stored with each inventory item.  The items with 
random colors get their colors regenerated from the random number 
seed which is stored in the Moria save file (e.g. MORIA.SAV).  So, 
I have cleaned up the SAVE.C file, eliminating the use of the 
COLOR.SAV file.

Locations of Files:
http://www.chinet.com/~edlee/mor552c.zip  Executable, documentation, etc.
http://www.chinet.com/~edlee/mor552cs.zip Source code
http://www.chinet.com/~edlee/mor552cx.zip Just the executable program

-Ed Lee, August 26, 2002


New command line options for Umoria v5.5.2 Turbo C Color:

-h
     No haggling.  This option deactivates haggling entirely.  
     Haggling in the stores is amusing when you first encounter 
     it, but it can become tiresome after a while.  Most of the 
     fun is in the dungeon.

-m
     Monochrome.  This option deactivates the display of colors 
     other than the default monochrome colors.

-dtime

     Delay.  The amount of time in milliseconds to delay after 
     displaying a bolt/ball/breath so that you can actually see 
     the bolt/ball/breath weapons in action on fast computers.  
     This option lets you get that 300 baud tty feel for the 
     bolt/ball/breath weapons without slowing down the rest of the 
     display.  This option also lets you see the items that a 
     creature drops before the items are destroyed by a 
     frostball/lightning ball/acid ball/fireball.  The time value 
     can be from 0 to 65535.  The timing is most accurate on slow 
     computers.  For fast computers, you may have to use a higher 
     time value.  For example, on my 800Mhz Athlon computer, I 
     have a shortcut icon on the Windows 98 desktop that I use to 
     play Moria.  The shortcut contains a line similar to:

          c:\moria\umoria.exe -d3000

     which would indicate a delay of 3000 milliseconds, or 3 
     seconds, between each bolt or breath display, but the actual 
     delay seems to be much less than that, around 300 
     milliseconds.  For my HP 200LX, I use

          c:\moria\umoria.exe -m -d75

     There should be no space in between the -d and the time 
     value.  The default delay time is zero.

     When I was trying to test the -d option to calibrate it for 
     stinking cloud on my HP 200LX, I was wondering why the ball 
     did not appear.  It turned out that I was firing at a wall 
     that was too far away.  The maximum range of any weapon is 18 
     spaces.

These options can be in either upper case or lower case.

Locations of Files:
http://www.chinet.com/~edlee/mor552c.zip  Executable, documentation, etc.
http://www.chinet.com/~edlee/mor552cs.zip Source code
http://www.chinet.com/~edlee/mor552cx.zip Just the executable program

The uncompressed MSDOS executable program size is 439,079 bytes.  It has 
been compressed with PKLITE down to 165,223 bytes.

-Ed Lee, August 23, 2002
