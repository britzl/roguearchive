/*
 * Read and execute the user commands
 *
 * @(#)command.c	4.73 (Berkeley) 08/06/83
 *
 * Rogue: Exploring the Dungeons of Doom
 * Copyright (C) 1980-1983, 1985, 1999 Michael Toy, Ken Arnold and Glenn Wichman
 * All rights reserved.
 *
 * See the file LICENSE.TXT for full copyright and licensing information.
 */

#include <stdlib.h>
#include <string.h>
#include <curses.h>
#include <ctype.h>
#include "rogue.h"

//CAT
int CHx, CHy;
int mEvX, mEvY;
extern char msgHISTORY[9][80];

MEVENT event;
int CATmouse= 0;
int multiSEARCH= 0;

bool stopONCE;
bool stopMOUS;
bool countTURN;
unsigned int nTURNS= 0;

typedef struct mACTION
{
    int pos;
    int len;
    char *name;
    bool active;

}mACTION;

bool infoUP;
bool menuUP;
int menuPOS;
int nACTIONS;

THING *menuITM;
mACTION mACT[15];

int trapPCK= -1;
int trapPCKx= 0;
int trapPCKy= 0;

bool scrID= FALSE;


//CAT
bool monsterNEAR(void)
{
    char c;
    int i,j;
    int sx, sy;
    THING *m;
    for(i= hero.x-1; i <= hero.x+1; i++)
    {
        for(j= hero.y-1; j <= hero.y+1; j++)
        {
            sx= (i < 0) ? 0 : i;
            sy= (j < 0) ? 0 : j;

            m= moat(sy, sx);
            c= mvinch(sy, sx);

            if(m != NULL && c != ' ' && isalpha(c))
                return TRUE;

        }
    }

    return FALSE;
}


void CATmousINFO(void)
{
	clearok(stdscr, TRUE);
	wrefresh(stdscr);

    wclear(hw);
    wmove(hw, 1,3);

    waddstr(hw, "Left mouse button \n   ");
    waddstr(hw, "- on @:                          search/rest one turn \n   ");
    waddstr(hw, "- on @ at stairs:                go down, with amulet go up \n   ");
    waddstr(hw, "- on inventory:                  select item \n   ");
    waddstr(hw, "- anywhere else:                 move direction \n   ");

    waddstr(hw, " \n   ");
    waddstr(hw, "Right mouse button \n   ");
    waddstr(hw, "- on @:                          search/rest x10 turns \n   ");
    waddstr(hw, "- on @ at stairs:                go up, with amulet go down \n   ");
    waddstr(hw, "- on monster, bow equipped:      shoot arrow \n   ");
    waddstr(hw, "- on monster, bow not equipped:  throw shuriken/dagger/dart \n   ");
    waddstr(hw, "- at trap direction:             identify/pickup/disarm trap \n   ");
    waddstr(hw, "- at item direction:             move without picking up \n   ");
    waddstr(hw, "- anywhere else:                 single step move direction \n   ");
    waddstr(hw, " \n   ");
    waddstr(hw, " \n   ");
    waddstr(hw, "Keyboard \n   ");
    waddstr(hw, "- s:   search/rest one turn \n   ");
    waddstr(hw, "- m:   show message history\n   ");
    waddstr(hw, "- Q:   quit \n   ");
    waddstr(hw, "- S:   save \n   ");

    wmove(hw, 23,0);

    wrefresh(hw);
    readchar();

    touchwin(stdscr);
	clearok(stdscr, TRUE);
	wrefresh(stdscr);

}

void CATgameINFO(void)
{
	clearok(stdscr, TRUE);
	wrefresh(stdscr);

    wclear(hw);
    wmove(hw, 1,3);

    waddstr(hw, "Rogue is a computer fantasy game. \n   ");
    waddstr(hw, " \n   ");
    waddstr(hw, "To win the game  you must locate the Amulet of Yendor,  somewhere below \n   ");
    waddstr(hw, "the 20th floor of the Dungeons of Doom,  and  get  it  out. Nobody  has \n   ");
    waddstr(hw, "achieved  this  yet, and if somebody does they will probably go down in \n   ");
    waddstr(hw, "history as a hero among heroes. \n   ");
    waddstr(hw, " \n   ");
    waddstr(hw, "When the game ends, either by your death, when you quit, or if you  (by \n   ");
    waddstr(hw, "some  miracle) manage to win,  game will give you a list of the top-ten \n   ");
    waddstr(hw, "scorers.  The scoring is based entirely upon how  much  gold  you  get. \n   ");
    waddstr(hw, "There is a 10% penalty for getting yourself killed. \n   ");
    waddstr(hw, " \n   ");
    waddstr(hw, " \n   ");
    waddstr(hw, "AUTHORS: \n   ");
    waddstr(hw, "Michael Toy, Glenn Wichman, Kenneth Arnold \n   ");

    wmove(hw, 22,51);
    waddstr(hw, "Rogue+ by LazyCat, 2016");

    wmove(hw, 23,0);

    wrefresh(hw);
    readchar();

    touchwin(stdscr);
	clearok(stdscr, TRUE);
	wrefresh(stdscr);
}

void chooseDIR()
{
	curs_set(2);

	msg("Which direction? ");

    if(readchar() == KEY_MOUSE)
    {

        if(mEvX= event.x - hero.x != 0)
            mEvX= (event.x < hero.x) ? -mEvX/mEvX : mEvX/mEvX;

        if(mEvY= event.y - hero.y != 0)
            mEvY= (event.y < hero.y) ? -mEvY/mEvY : mEvY/mEvY;

        if (on(player, ISHUH) && rnd(3) == 0)
        {
            mEvX= rnd(3) - 1;
            mEvY= rnd(3) - 1;
        }
    }
    else
        mEvX=mEvY= 0;


	flushinp();
	curs_set(0);
}

void newIFACE(void)
{
    int i, itmTYPE, sp;
    char menuSTR[80]= "";
    THING *list= pack;


    if(trapPCK >= 0)
    {
        menuUP= TRUE;
        mvaddstr(0, 0, "                                                                              ");

        char trapNAME[80];
        strcpy(trapNAME, tr_name[trapPCK]);
        trapNAME[0] = (char) toupper(trapNAME[0]);

        mvaddstr(0, 0, trapNAME);

        nACTIONS= 2;
        mACT[0].name= " PICKUP ";   mACT[0].len= 8;     mACT[0].active= TRUE;
        mACT[1].name= " DISARM ";   mACT[1].len= 8;     mACT[1].active= TRUE;

        if(trapPCK == 0 || trapPCK == 6 || trapPCK == 7)
            mACT[0].active= FALSE;

        goto drawit;
    }
    else
    if(infoUP)
    {
        menuUP= TRUE;
        mvaddstr(0, 0, "                                                                              ");

        nACTIONS= 4;
        mACT[0].name= " DISCOVERY ";    mACT[0].len= 11;     mACT[0].active= TRUE;
        mACT[1].name= " SYMBOL ID ";    mACT[1].len= 11;     mACT[1].active= TRUE;
        mACT[2].name= " CONTROLS ";     mACT[2].len= 10;     mACT[2].active= TRUE;
        mACT[3].name= " ABOUT ";        mACT[3].len= 7;      mACT[3].active= TRUE;

        goto drawit;
    }


    for(i= 0;i < mEvY;i++)
    {
        list= next(list);

        if(list == NULL)
            return;
    }

    mvaddch(menuPOS,78, ' ');
    menuPOS= mEvY;
    mvaddch(menuPOS,78, '>');

    menuUP= TRUE;
    mvaddstr(0, 0, "                                                                              ");

    menuITM= list;
    itmTYPE= menuITM->o_type;
    mvaddstr(0, 0, CATinv_name(list, FALSE));

    if(scrID)
    {
        nACTIONS= 2;
        mACT[0].name= " IDENTIFY "; mACT[0].len= 10;    mACT[0].active= FALSE;
        mACT[1].name= " CANCEL ";   mACT[1].len= 8;     mACT[1].active= TRUE;

        if(!(menuITM->o_flags & ISKNOW) && (itmTYPE == ARMOR || itmTYPE == WEAPON))
            mACT[0].active= TRUE;
        else
        if(!pot_info[menuITM->o_which].oi_know && itmTYPE == POTION)
            mACT[0].active= TRUE;
        else
        if(!scr_info[menuITM->o_which].oi_know && itmTYPE == SCROLL)
            mACT[0].active= TRUE;
        else
        if(!(menuITM->o_flags & ISKNOW) && itmTYPE == STICK)
            mACT[0].active= TRUE;
        else
        if(itmTYPE == RING)
        {
            int wr= menuITM->o_which;

            if(!(menuITM->o_flags & ISKNOW)
                    && (wr == R_PROTECT || wr == R_ADDSTR || wr == R_ADDHIT || wr == R_ADDDAM))
                mACT[0].active= TRUE;
            else
            if(!ring_info[menuITM->o_which].oi_know)
                mACT[0].active= TRUE;
        }

    }
    else
    if(itmTYPE == TRAP)
    {
        nACTIONS= 2;
        mACT[0].name= " SET DOWN ";     mACT[0].len= 10;    mACT[0].active= TRUE;
        mACT[1].name= " DISMANTLE ";    mACT[1].len= 11;    mACT[1].active= TRUE;
    }
    else
    if(itmTYPE == FOOD)
    {
        nACTIONS= 3;
        mACT[0].name= " EAT ";      mACT[0].len= 5;     mACT[0].active= TRUE;
        mACT[1].name= " THROW ";    mACT[1].len= 7;     mACT[1].active= TRUE;
        mACT[2].name= " DROP ";     mACT[2].len= 6;     mACT[2].active= TRUE;
    }
    else
    if(itmTYPE == STICK)
    {
        nACTIONS= 4;
        mACT[0].name= " ZAP ";      mACT[0].len= 5;     mACT[0].active= TRUE;
        mACT[1].name= " THROW ";    mACT[1].len= 7;     mACT[1].active= TRUE;
        mACT[2].name= " DROP ";     mACT[2].len= 6;     mACT[2].active= TRUE;
        mACT[3].name= " CALL ";     mACT[3].len= 6;     mACT[3].active= TRUE;
    }
    else
    if(itmTYPE == POTION)
    {
        nACTIONS= 4;
        mACT[0].name= " QUAFF ";    mACT[0].len= 7;     mACT[0].active= TRUE;
        mACT[1].name= " THROW ";    mACT[1].len= 7;     mACT[1].active= TRUE;
        mACT[2].name= " DROP ";     mACT[2].len= 6;     mACT[2].active= TRUE;
        mACT[3].name= " CALL ";     mACT[3].len= 6;     mACT[3].active= TRUE;
    }
    else
    if(itmTYPE == SCROLL)
    {
        nACTIONS= 4;
        mACT[0].name= " READ ";     mACT[0].len= 6;     mACT[0].active= TRUE;
        mACT[1].name= " THROW ";    mACT[1].len= 7;     mACT[1].active= TRUE;
        mACT[2].name= " DROP ";     mACT[2].len= 6;     mACT[2].active= TRUE;
        mACT[3].name= " CALL ";     mACT[3].len= 6;     mACT[3].active= TRUE;
    }
    else
    if(itmTYPE == RING || itmTYPE == ARMOR || itmTYPE == WEAPON)
    {
        nACTIONS= 4;
        if(menuITM == cur_ring[LEFT] || menuITM == cur_ring[RIGHT]
                    || menuITM == cur_armor || menuITM == cur_weapon)
            {mACT[0].name= " UNEQUIP ";  mACT[0].len= 9;     mACT[0].active= TRUE;}
        else
            {mACT[0].name= " EQUIP ";    mACT[0].len= 7;     mACT[0].active= TRUE;}

        if(cur_weapon != NULL && cur_weapon->o_which == BOW && menuITM->o_which == ARROW)
            {mACT[1].name= " SHOOT ";    mACT[1].len= 7;    mACT[1].active= TRUE;}
        else
            {mACT[1].name= " THROW ";    mACT[1].len= 7;    mACT[1].active= TRUE;}

        mACT[2].name= " DROP ";     mACT[2].len= 6;     mACT[2].active= TRUE;
        mACT[3].name= " CALL ";     mACT[3].len= 6;     mACT[3].active= TRUE;
    }
    else
    {
//CAT - uncounted for item... amulet of Yendor

        nACTIONS= 1;
        mACT[0].name= " INSPECT ";     mACT[0].len= 9;    mACT[0].active= TRUE;
    }


drawit:
    for(i= nACTIONS-1;i >= 0;i--)
    {
        strcat(menuSTR, mACT[i].name);
        strcat(menuSTR, " ");
    }

    sp= 79-strlen(menuSTR);

    for(i= nACTIONS-1;i >= 0;i--)
    {
        if(mACT[i].active)
            attron(A_REVERSE);

        mvaddstr(0, sp, mACT[i].name);
        mACT[i].pos= sp;
        sp+= mACT[i].len+1;

        attroff(A_REVERSE);
    }
}

void clickIFACE(void)
{
    int i, actBUTTON= -1;

    menuUP= FALSE;
    mvaddch(menuPOS,78, ' ');
    mvaddstr(0, 0, "                                                                              ");
    for(i= 0;i < nACTIONS;i++)
    {
        if(mEvX >= mACT[i].pos && mEvX < mACT[i].pos+mACT[i].len)
        {
            actBUTTON= i;
            break;
        }
    }

    if(actBUTTON < 0 || !mACT[actBUTTON].active)
    {
        trapPCK= -1;
        infoUP= FALSE;
        after= FALSE;
        return;
    }

    if(trapPCK >= 0)
    {
        if(actBUTTON == 0) //pickup
        {

            int trapNO= 0;
            THING *pI= pack;
            while(pI != NULL)
            {
                if(pI->o_type == TRAP)
                    trapNO+= pI->o_count;

                pI= next(pI);
            }

            if(trapNO > 0)
            {
                addmsg("can not carry more than one trap");
                endmsg();
            }
            else
            if (inpack >= MAXPACK)
            {
                addmsg("no room");
                endmsg();
            }
            else
            {
                THING *obj;
                obj= new_item();
                obj->o_type= TRAP;

                obj->o_group= 0;
                obj->o_count= 1;
                obj->o_which= trapPCK;

                add_pack(obj, FALSE);
                msg("picked up %s", tr_name[trapPCK]);

                flat(trapPCKy, trapPCKx)|= F_REAL;
                chat(trapPCKy, trapPCKx)= floor_ch();
            }
        }
        else
        if(actBUTTON == 1) //disarm
        {
            flat(trapPCKy, trapPCKx)|= F_REAL;
            chat(trapPCKy, trapPCKx) = floor_ch();

            msg("disarmed %s", tr_name[trapPCK]);
        }

        trapPCK= -1;
        return;
    }
    else
    if(infoUP)
    {
        if(actBUTTON == 0) //discovery
            CATdiscovered();
        else
        if(actBUTTON == 1) //symbol ID
        {
            curs_set(2);
            msg("click on want you want identified");

            if(readchar() == KEY_MOUSE)
            {
                endmsg();
                mEvX= event.x;
                mEvY= event.y;
                if(mEvX == hero.x && mEvY == hero.y)
                    {msg("'@': it is you"); addmsg(whoami); endmsg();}
                else
                {
                    if(mvinch(mEvY, mEvX) == ' ')
                        msg("nothing there");
                    else
                        CATidentify(mvinch(mEvY, mEvX));

                }
            }

            curs_set(0);
        }
        else
        if(actBUTTON == 2) //mous info
            CATmousINFO();
        else
        if(actBUTTON == 3) //game info
            CATgameINFO();


        after= FALSE;
        infoUP= FALSE;

        return;
    }


    int itmTYPE= menuITM->o_type;

    if(scrID)
    {
        if(actBUTTON == 0)
            CATwhatis(menuITM);

        scrID= FALSE;
    }
    else
    if(itmTYPE == TRAP)
    {
        if(actBUTTON == 0) //set down
        {
            if(chat(hero.y, hero.x) == FLOOR ) //|| chat(hero.y, hero.x) == PASSAGE)
            {
                leave_pack(menuITM, TRUE, FALSE);

                flat(hero.y, hero.x)&= ~(F_REAL | F_TMASK);
                flat(hero.y, hero.x)|= (F_SEEN | menuITM->o_which);

                chat(hero.y, hero.x)= TRAP;
                msg("you set %s", tr_name[menuITM->o_which]);
            }
            else
                msg("you can't set a trap here");
        }
        else
        if(actBUTTON == 1) //dismantle
        {
            msg("dismantled %s", tr_name[menuITM->o_which]);
            leave_pack(menuITM, TRUE, FALSE);
        }
    }
    else
    if(itmTYPE != FOOD && itmTYPE != WEAPON && itmTYPE != ARMOR
            && itmTYPE != RING && itmTYPE != SCROLL && itmTYPE != POTION && itmTYPE != STICK)
    {
//CAT - should be the AMULET
            msg("So, this is it -- the fabled Amulet of Yendor.");

    }
    else
    if(actBUTTON == 0)
    {
        switch(itmTYPE)
        {
            case FOOD:
                CATeat(menuITM);
            break;

            case WEAPON:
                if(menuITM == cur_weapon)
                    CATweapon_off(menuITM);
                else
                    CATwield(menuITM);
            break;

            case ARMOR:
                if(menuITM == cur_armor)
                    CATarmor_off(menuITM);
                else
                    CATwear(menuITM);
            break;

            case RING:
                if(menuITM == cur_ring[LEFT] || menuITM == cur_ring[RIGHT])
                    CATring_off(menuITM);
                else
                    CATring_on(menuITM);
            break;

            case SCROLL:
                CATread_scroll(menuITM);
            break;

            case POTION:
                CATquaff(menuITM);
            break;

            case STICK:

                if(menuITM->o_which == WS_DRAIN || menuITM->o_which == WS_LIGHT)
					mEvX=mEvY= 1;
                else
                    chooseDIR();

                if(mEvX != 0 || mEvY != 0)
                {
                    delta.x= mEvX;
                    delta.y= mEvY;

                    msg("");
                    CATzap(menuITM);
                }
                else
                    msg("What the?!");

            break;
        }
    }
    else
    {
        if(actBUTTON == 1) //throw or shoot
        {
            chooseDIR();
            if(mEvX != 0 || mEvY != 0)
            {
                msg("");
                CATthrow(menuITM, mEvY, mEvX);
            }
            else
                msg("What the?!");

        }
        else
        if(actBUTTON == 2) //drop
            CATdrop(menuITM);
        else
        if(actBUTTON == 3) //call
            CATcall(menuITM);
    }
}
//CAT -end


/*
 * command:
 *	Process the user commands
 */
void
command(void)
{
    int ch, i;
    int ntimes = 1;			/* Number of player moves */
    THING *mp;
    static int countch, direction, newcount = FALSE;


    if (on(player, ISHASTE))
        ntimes++;
    /*
     * Let the daemons start up
     */
    do_daemons(BEFORE);
    do_fuses(BEFORE);


//**********************************************************************
//*** BIG WHILE ********************************************************
    while (ntimes--)
    {

	again = FALSE;
	if (has_hit)
	{
	    endmsg();
	    has_hit = FALSE;
	}

	/*
	 * these are illegal things for the player to be, so if any are
	 * set, someone's been poking in memeory
	 */
	if (on(player, ISSLOW|ISGREED|ISINVIS|ISREGEN|ISTARGET))
	    exit(1);


//CAT - should we wake up monsters just by coming up close?
//steps noise wakes them up, levitate to sneak past
	look(TRUE);


	if (!running)
	    door_stop = FALSE;

    status();



//CAT - display inventory & turn counter
// A_REVERSE vs A_STANDOUT:
// A_STANDOUT stands out less with black bkg as txt is not white but gray

    int vPOS;
    const THING *list = pack;

    for(vPOS= 0;vPOS < 24; vPOS++)
        mvaddch(vPOS,79, ' ');

    for(vPOS= 0;list != NULL;list= next(list))
    {
		if(list == cur_armor || list == cur_weapon
            || list == cur_ring[LEFT] || list == cur_ring[RIGHT])
            attron(A_REVERSE);

        mvaddch(vPOS,79, list->o_type);
        attroff(A_REVERSE);
        vPOS++;
    }

    char nT[9]="";
    sprintf(nT,"T:%d", nTURNS);
    mvaddstr(STATLINE,71, nT);

    attron(A_REVERSE);
    mvaddch(23,79, 'i');
    attroff(A_REVERSE);
//CAT end


	lastscore = purse;
	move(hero.y, hero.x);
	if (!((running || count) && jump))
	    refresh();			/* Draw screen */

	take = 0;
	after = TRUE;
	/*
	 * Read command or continue run
	 */
#ifdef MASTER
	if (wizard)
	    noscore = TRUE;
#endif

	if (!no_command)
	{
//CAT
        move_on = FALSE; //move and pickup

        if(CATmouse > 0)
            ch= KEY_MOUSE;
        else
	    if (running)
            ch = runch;
	    else
        if (count)
            ch = countch;
	    else
	    {
            ch = readchar();

            if (mpos != 0)		/* Erase message if its there */
            {
                if (ch != '.')
                msg("");
            }
	    }
	}
	else
	    ch = '.';

	if (no_command)
	{
	    if (--no_command == 0)
	    {
            msg("you can move again");
	    }
	}
	else
	{
	    /*
	     * check for prefixes
	     */
	    newcount = FALSE;
	    if (isdigit(ch))
	    {
		count = 0;
		newcount = TRUE;
		while (isdigit(ch))
		{
		    count = count * 10 + (ch - '0');
		    if (count > 255)
			count = 255;
		    ch = readchar();
		}
		countch = ch;

		/*
		 * turn off count for commands which don't make sense
		 * to repeat
		 */
		switch (ch)
		{
		    case CTRL('B'): case CTRL('H'): case CTRL('J'):
		    case CTRL('K'): case CTRL('L'): case CTRL('N'):
		    case CTRL('U'): case CTRL('Y'):
		    case '.': case 'a': case 'b': case 'h': case 'j':
		    case 'k': case 'l': case 'm': case 'n': case 'q':
		    case 'r': case 's': case 't': case 'u': case 'y':
		    case 'z': case 'B': case 'C': case 'H': case 'I':
		    case 'J': case 'K': case 'L': case 'N': case 'U':
		    case 'Y':
#ifdef MASTER
		    case CTRL('D'): case CTRL('A'):
#endif
			break;
		    default:
			count = 0;
		}
	    }

	    /*
	     * execute a command
	     */
	    if (count && !running)
            count--;

	    if (ch != 'a' && ch != ESCAPE && !(running || count))
	    {
            l_last_comm = last_comm;
            l_last_dir = last_dir;
            l_last_pick = last_pick;
            last_comm = ch;
            last_dir = '\0';
            last_pick = NULL;
	    }


over:
	    switch (ch)
	    {

//CAT
        case KEY_MOUSE:
//           if(CATmouse > 0
//                || event.bstate & BUTTON1_PRESSED || event.bstate & BUTTON3_PRESSED)
            {

                int Hdx, Hdy;
                int startX, startY;

                countTURN= FALSE;
                if(CATmouse == 0)
                {
                    mEvX= event.x;
                    mEvY= event.y;

                    if(mEvX == 79)
                    {
                        if(mEvY == 23)
                            infoUP= TRUE;

                        newIFACE();

                        after= FALSE;
                        break;
                    }

                    if(menuUP && mEvY == 0)
                    {
                        clickIFACE();
                        break;
                    }
                    else
                    if(menuUP)
                    {
                        mvaddch(menuPOS,78, ' ');
                        mvaddstr(0, 0, "                                                                              ");

                        trapPCK= -1;
                        infoUP= FALSE;
                        menuUP= FALSE;
                        after= FALSE;
                        break;
                    }
                }


                CHx= startX = hero.x;
                CHy= startY = hero.y;

                if(event.bstate & BUTTON3_PRESSED)
                {
                    int x,y;
                    if(x= event.x - hero.x != 0)
                        x= (event.x < hero.x) ? -x/x : x/x;

                    if(y= event.y - hero.y != 0)
                        y= (event.y < hero.y) ? -y/y : y/y;

                    if (moat(mEvY, mEvX) != NULL
							&& on(player, ISHUH) && rnd(3) == 0)
                    {
                        x= rnd(3) - 1;
                        y= rnd(3) - 1;

                        if(x == 0 && y == 0)
                            msg("What the?!");
                    }

                    //CAT - shoot ARROW if any and BOW equipped
                    if(cur_weapon != NULL
                        && cur_weapon->o_which == BOW && moat(mEvY, mEvX) != NULL)
                    {
                        THING *list = pack;
                        bool hasARROW= FALSE;
                        for(vPOS= 0;list != NULL;list= next(list))
                        {
                            if(list->o_type == WEAPON && list->o_which == ARROW)
                            {
                                 hasARROW= TRUE;
                                 break;
                            }
                        }

                        if(hasARROW)
                        {
                            CATthrow(list, y, x);
                            break;
                        }
                    }
                    else
                    if(moat(mEvY, mEvX) != NULL)
                    {
                    //CAT - throw darts, shurikens, or daggers if any

                        THING *list = pack;
                        bool hasDrShDg= FALSE;
                        for(vPOS= 0;list != NULL;list= next(list))
                        {
                            if(list->o_type == WEAPON
                               && (list->o_which == DART || list->o_which == SHIRAKEN || list->o_which == DAGGER))
                            {
                                 hasDrShDg= TRUE;
                                 break;
                            }
                        }

                        if(hasDrShDg)
                        {
                            CATthrow(list, y, x);
                            break;
                        }
                    }


                    delta.y = hero.y+y;
                    delta.x = hero.x+x;

                    //CAT - examine traps or move no-pickup
                    if (chat(delta.y, delta.x) == TRAP)
                    {
                        int *fp;

                        if (!terse)
                            addmsg("You have found ");

                        if (on(player, ISHALU))
                            msg(tr_name[rnd(NTRAPS)]);
                        else
                        {
                            fp = &flat(delta.y, delta.x);
                            msg(tr_name[*fp & F_TMASK]);
                            *fp |= F_SEEN;
                        }

                        trapPCKx= delta.x;
                        trapPCKy= delta.y;
                        trapPCK= *fp & F_TMASK;

                        newIFACE();

                        after = FALSE;
                        break;
                    }
                    else
                        move_on = TRUE; //move no-pickup
                }


                if(multiSEARCH > 0 || (mEvX == hero.x && mEvY == hero.y))
                {
                    if(chat(mEvY, mEvX) == STAIRS && amulet)
                    {
                        after = FALSE;
                        if(event.bstate & BUTTON3_PRESSED)
                            d_level();
                        else
                            u_level();
                    }
                    else
                    if(chat(mEvY, mEvX) == STAIRS && !amulet)
                    {
                        after = FALSE;
                        if(event.bstate & BUTTON3_PRESSED)
                            u_level();
                        else
                            d_level();
                    }
                    else
                    {
                        //CAT - multi search x10
                        if(multiSEARCH == 0 && event.bstate & BUTTON3_PRESSED)
                        {
                            CATmouse= 1;
                            multiSEARCH= 10;
                        }
                        else
                        if(multiSEARCH > 0)
                        {
                            multiSEARCH--;

                            if(stopMOUS || multiSEARCH == 0)
                            {
                                stopMOUS= FALSE;
                                multiSEARCH= 0;
                                CATmouse= 0;

                                after= FALSE;

                                break;
                            }
                            else
                                CATmouse= 1;
                        }

                        msg("Resting/Searching..");
                        search();
                    }

                    break;
                }



                if(stopMOUS && CATmouse > 0)
                {
                    after= FALSE;
                    stopMOUS= FALSE;
                    CATmouse= 0;
                    break;
                }


                if(mEvX > CHx && mEvY > CHy)
                    do_move(1, 1);
                if(mEvX < CHx && mEvY < CHy)
                    do_move(-1, -1);

                if(mEvX > CHx && mEvY < CHy)
                    do_move(-1, 1);
                if(mEvX < CHx && mEvY > CHy)
                    do_move(1, -1);


                CHx= hero.x;
                CHy= hero.y;

                Hdx= abs(mEvX-CHx);
                Hdy= abs(mEvY-CHy);

                if(Hdx > Hdy)
                {
                    if(!countTURN && (startX == CHx && startY == CHy))
                    {
                        if(mEvX < CHx)
                            do_move(0, -1);
                        if(mEvX > CHx)
                            do_move(0, 1);
                    }

                    CHx= hero.x;
                    CHy= hero.y;

                    if(!countTURN && (startX == CHx && startY == CHy))
                    {
                        if(mEvY < CHy)
                            do_move(-1, 0);
                        if(mEvY > CHy)
                            do_move(1, 0);
                    }

                }
                else
                {
                    if(!countTURN && (startX == CHx && startY == CHy))
                    {
                        if(mEvY < CHy)
                            do_move(-1, 0);
                        if(mEvY > CHy)
                            do_move(1, 0);
                    }

                    CHx= hero.x;
                    CHy= hero.y;


                    if(!countTURN && (startX == CHx && startY == CHy))
                    {
                        if(mEvX < CHx)
                            do_move(0, -1);
                        if(mEvX > CHx)
                            do_move(0, 1);
                    }
                }


                CHx= hero.x;
                CHy= hero.y;

                Hdx= abs(mEvX-CHx);
                Hdy= abs(mEvY-CHy);

/*
                char cb[9]=".........";
                sprintf(cb,">%d", sizeof(unsigned int));
                addmsg(cb);
                endmsg();
*/

                napms(30);

                //monsterNEAR() ||
                if(stopMOUS || Hdx+Hdy == 0 || (startX == CHx && startY == CHy))
                    CATmouse= 0;
                else
                {
                    if(event.bstate & BUTTON3_PRESSED || event.bstate & BUTTON3_DOUBLE_CLICKED)
                        CATmouse= 0;
                    else
                    switch(winat(CHy,CHx))
                    {
                        case '.':
                        case '#':
                        case STAIRS:
                            CATmouse= 1;
                            stopONCE= FALSE;
                        break;

                        default:
                            CATmouse= 0;
                    }
                }

                if(countTURN)
                    after= TRUE;

                stopMOUS= FALSE;
            }

        break;


		case ',': {
		    THING *obj = NULL;
		    int found = 0;
		    for (obj = lvl_obj; obj != NULL; obj = next(obj))
    			{
			    if (obj->o_pos.y == hero.y && obj->o_pos.x == hero.x)
			    {
				found=1;
				break;
			    }
    			}

		    if (found) {
			if (levit_check())
			    ;
			else
			    pick_up(obj->o_type);
		    }
		    else {
			if (!terse)
			    addmsg("there is ");
			addmsg("nothing here");
                        if (!terse)
                            addmsg(" to pick up");
                        endmsg();
		    }
		}

//CAT
		when '!':

            curs_set(2);
            char CATpswd[9];
            msg("Shell password: ");
            if (get_str(prbuf, stdscr) == NORM)
            {
                strncpy(CATpswd, prbuf, 7);
                strcat(CATpswd, "\0");
            }
            curs_set(0);

            if(!strcmp("---", CATpswd))
                shell();
            else
                msg("Not quite.");

		when 'h': do_move(0, -1);
		when 'j': do_move(1, 0);
		when 'k': do_move(-1, 0);
		when 'l': do_move(0, 1);
		when 'y': do_move(-1, -1);
		when 'u': do_move(-1, 1);
		when 'b': do_move(1, -1);
		when 'n': do_move(1, 1);
		when 'H': do_run('h');
		when 'J': do_run('j');
		when 'K': do_run('k');
		when 'L': do_run('l');
		when 'Y': do_run('y');
		when 'U': do_run('u');
		when 'B': do_run('b');
		when 'N': do_run('n');
		when CTRL('H'): case CTRL('J'): case CTRL('K'): case CTRL('L'):
		case CTRL('Y'): case CTRL('U'): case CTRL('B'): case CTRL('N'):
		{
		    if (!on(player, ISBLIND))
		    {
                door_stop = TRUE;
                firstmove = TRUE;
		    }
		    if (count && !newcount)
                ch = direction;
		    else
		    {
                ch += ('A' - CTRL('A'));
                direction = ch;
		    }

		    goto over;
		}


		when 'Q':
            curs_set(2);
		    after = FALSE;
		    q_comm = TRUE;
		    quit(0);
		    q_comm = FALSE;
		    curs_set(0);

		when 'i': after = FALSE; inventory(pack, 0);

//CAT
//		when 'o': curs_set(2); option(); after = FALSE; curs_set(0);


//CAT
		when 's': msg("Resting/Searching.."); search();

//CAT - show message
//		when CTRL('P'): after = FALSE; msg(huh);
		when 'm':
		    after = FALSE;
		    //msg(huh);

            clearok(stdscr, TRUE);
            wrefresh(stdscr);

            wclear(hw);
            mvwaddstr(hw, 0,0, "Message history:");

            int i, j= 2;
            for(i= 0; i < 20; i++)
            {
                if(strlen(msgHISTORY[19-i]) < 1)
                    continue;

                mvwaddstr(hw, j++,1, msgHISTORY[19-i]);
            }


            wrefresh(hw);
            readchar();

            touchwin(stdscr);
            clearok(stdscr, TRUE);
            wrefresh(stdscr);


		when CTRL('R'):
		    after = FALSE;
		    clearok(curscr,TRUE);
		    wrefresh(curscr);

//CAT - show monster damage string
		when 'd':

            curs_set(2);
            struct monster *mp;
            msg("monster? ");
            int wm= getch();
            curs_set(0);

            mp = &monsters[wm - 'A'];
		    msg(">>'%c': %s", wm, mp->m_stats.s_dmg);

		when 'v':
		    after = FALSE;
//CAT
		    msg("version %s-plus (Driverman was here)", release);

		when 'S':
//CAT
            curs_set(2);
		    after = FALSE;
		    save_game();
            curs_set(0);

		when '.': ;			/* Rest command */

//CAT
		when ' ': ch= '.'; //after = FALSE;

#ifdef MASTER
		when '+':
		    after = FALSE;
		    if (wizard)
		    {
			wizard = FALSE;
			turn_see(TRUE);
			msg("not wizard any more");
		    }
		    else
		    {
//CAT
//			wizard = passwd();
            wizard = TRUE;
			if (wizard)
			{
			    noscore = TRUE;
			    turn_see(FALSE);
			    msg("you are suddenly as smart as Ken Arnold in dungeon #%d", dnum);
			}
			else
			    msg("sorry");
		    }
#endif
		when ESCAPE:	/* Escape */
		    door_stop = FALSE;
		    count = 0;
		    after = FALSE;
		    again = FALSE;

		otherwise:
		    after = FALSE;
#ifdef MASTER
		    if (wizard) switch (ch)
		    {
			case '|': msg("@ %d,%d", hero.y, hero.x);
			when 'C': create_obj();
			when '$': msg("inpack = %d", inpack);
			when CTRL('G'): inventory(lvl_obj, 0);


			when CTRL('D'): level++; new_level();
			when CTRL('A'): level--; new_level();
			when CTRL('F'): show_map();
			when CTRL('T'): teleport();
			when CTRL('E'): msg("food left: %d", food_left);
			when CTRL('Q'): add_pass();
			when CTRL('X'): turn_see(on(player, SEEMONST));

			when CTRL('I'):
			{
			    int i;
			    THING *obj;

			    for (i = 0; i < 9; i++)
				raise_level();
			    /*
			     * Give him a sword (+1,+1)
			     */
			    obj = new_item();
			    init_weapon(obj, TWOSWORD);
			    obj->o_hplus = 1;
			    obj->o_dplus = 1;
			    add_pack(obj, TRUE);
			    cur_weapon = obj;
			    /*
			     * And his suit of armor
			     */
			    obj = new_item();
			    obj->o_type = ARMOR;
			    obj->o_which = PLATE_MAIL;
			    obj->o_arm = -5;
			    obj->o_flags |= ISKNOW;
			    obj->o_count = 1;
			    obj->o_group = 0;
			    cur_armor = obj;
			    add_pack(obj, TRUE);
			}
			when '*' :
			    pr_list();
			otherwise:
			    illcom(ch);
		    }
		    else
#endif
			illcom(ch);
	    }
	    /*
	     * turn off flags if no longer needed
	     */
	    if (!running)
            door_stop = FALSE;
	}

        /*
         * If he ran into something to take, let him pick it up.
         */
        if (take != 0)
            pick_up(take);

        if (!running)
            door_stop = FALSE;

        if (!after)
            ntimes++;
        else
        {
//CAT
            nTURNS++;
        }
    }
//*** END BIG WHILE ********************************************************
//**********************************************************************


    do_daemons(AFTER);
    do_fuses(AFTER);

    if (ISRING(LEFT, R_SEARCH))
        search();
    else
    if (ISRING(LEFT, R_TELEPORT) && rnd(50) == 0)
    {
        teleport();
        msg("Oy!!");
    }


    if (ISRING(RIGHT, R_SEARCH))
        search();
    else
    if (ISRING(RIGHT, R_TELEPORT) && rnd(50) == 0)
    {
        teleport();
        msg("Ay!!");
    }
}



/*
 * illcom:
 *	What to do with an illegal command
 */
void
illcom(int ch)
{
    save_msg = FALSE;
    count = 0;
//CAT
//    msg("'%s' does nothing", unctrl(ch));
    msg("click 'i' in the bottom-right corner for info.");

    save_msg = TRUE;
}


/*
 * search:
 *	player gropes about him to find hidden things.
 */
void
search(void)
{
    int y, x;
    int *fp;
    int ey, ex;
    int probinc;
    int found;

//CAT
    if(multiSEARCH > 0 && monsterNEAR())
    {
        msg("monster is here!");
        stopMOUS= TRUE;
        after= FALSE;
        return;
    }

    ey = hero.y + 1;
    ex = hero.x + 1;
    probinc = (on(player, ISHALU) ? 3 : 0);
    probinc += (on(player, ISBLIND) ? 2 : 0);
    found = FALSE;
    for (y = hero.y - 1; y <= ey; y++)
	for (x = hero.x - 1; x <= ex; x++)
	{
	    if (y == hero.y && x == hero.x)
		continue;
	    fp = &flat(y, x);
	    if (!(*fp & F_REAL))
		switch (chat(y, x))
		{
		    case '|':
		    case '-':

//CAT
//			if (rnd(5 + probinc) != 0)
			if (multiSEARCH != 1 && rnd(2 + probinc) != 0)
			    break;

			chat(y, x) = DOOR;

            msg("a secret door");
foundone:
			found = TRUE;
			*fp |= F_REAL;
			count = FALSE;
			running = FALSE;
			break;

		    case FLOOR:

//CAT
//			if (rnd(2 + probinc) != 0)
			if (multiSEARCH != 1 && rnd(2 + probinc) != 0)
			    break;

			chat(y, x) = TRAP;
			if (!terse)
			    addmsg("you found ");
			if (on(player, ISHALU))
			    msg(tr_name[rnd(NTRAPS)]);
			else {
			    msg(tr_name[*fp & F_TMASK]);
			    *fp |= F_SEEN;
			}
			goto foundone;
			break;

		    case ' ':
//CAT
//			if (rnd(3 + probinc) != 0)
			if (multiSEARCH != 1 && rnd(2 + probinc) != 0)
			    break;

			chat(y, x) = PASSAGE;
			goto foundone;
		}
	}

//CAT
    if (found)
    {
        look(FALSE);
        stopMOUS= TRUE;

        if(monsterNEAR())
            msg("monster!");
    }
}



//CAT
void CATidentify(int ch)
{
    char str[80]= "unknown character";

    const struct h_list *hp;
    const struct h_list ident_list[] = {
	{'|',		"wall of a room",		FALSE},
	{'-',		"wall of a room",		FALSE},
	{GOLD,		"gold",				FALSE},
	{STAIRS,	"a staircase",			FALSE},
	{DOOR,		"door",				FALSE},
	{FLOOR,		"room floor",			FALSE},
	{PLAYER,	"you",				FALSE},
	{PASSAGE,	"passage",			FALSE},
	{TRAP,		"trap",				FALSE},
	{POTION,	"potion",			FALSE},
	{SCROLL,	"scroll",			FALSE},
	{FOOD,		"food",				FALSE},
	{WEAPON,	"weapon",			FALSE},
	{' ',		"solid rock",			FALSE},
	{ARMOR,		"armor",			FALSE},
	{AMULET,	"the Amulet of Yendor",		FALSE},
	{RING,		"ring",				FALSE},
	{STICK,		"wand or staff",		FALSE},
	{'\0'}
    };

    mpos = 0;
    if (ch == ESCAPE)
    {
        msg("");
        return;
    }

    if (isupper(ch))
    {
//CAT - show monster damage
        const char *cp, *ds;
        int ndice, nsides, nD, nS;
        const struct stats *att;

        THING *m= moat(mEvY, mEvX);
        if(m == NULL)
        {
            msg("");
            return;
        }

        att= &m->t_stats;
        cp=ds= att->s_dmg;

        nD=nS= 0;
        while(cp != NULL && *cp != '\0')
        {
            ndice = atoi(cp);
            nD+= ndice;

            if ((cp = strchr(cp, 'x')) == NULL)
                break;

            nsides = atoi(++cp);
            nS+= ndice*nsides;

            if ((cp = strchr(cp, '/')) == NULL)
                break;
            cp++;
        }

        sprintf(str, "%s [%d-%d]", monsters[ch-'A'].m_name, nD, nS);
    }
    else
    {
//CAT - show item worth in gold?
        for (hp = ident_list; hp->h_ch != '\0'; hp++)
        {
            if (hp->h_ch == ch)
            {
                sprintf(str, hp->h_desc);
                break;
            }
        }
    }

    msg("'%s': %s", unctrl(ch), str);
}



/*
 * d_level:
 *	He wants to go down a level
 */
void
d_level(void)
{
    if (levit_check())
	return;
    if (chat(hero.y, hero.x) != STAIRS)
	msg("I see no way down");
    else
    {
	level++;
	seenstairs = FALSE;
	new_level();
    }
}

/*
 * u_level:
 *	He wants to go up a level
 */
void
u_level(void)
{
    if (levit_check())
	return;
    if (chat(hero.y, hero.x) == STAIRS)
	if (amulet)
	{
	    level--;
	    if (level == 0)
		total_winner();
	    new_level();
//CAT
//	    msg("you feel a wrenching sensation in your gut");
	}
	else
    if (!terse)
	    msg("your way is magically blocked");
    else
        msg("I see no way up");
}

/*
 * levit_check:
 *	Check to see if she's levitating, and if she is, print an
 *	appropriate message.
 */
int
levit_check(void)
{
    if (!on(player, ISLEVIT))
	return FALSE;
    msg("You can't.  You're floating off the ground!");
    return TRUE;
}



//CAT
void CATcall(THING *obj)
{

    struct obj_info *op = NULL;
    char **guess;
    const char *elsewise = NULL;
    int *know;


    if (obj == NULL)
	return;
    switch (obj->o_type)
    {
        case RING:
            op = &ring_info[obj->o_which];
            elsewise = r_stones[obj->o_which];
            goto norm;
        when POTION:
            op = &pot_info[obj->o_which];
            elsewise = p_colors[obj->o_which];
            goto norm;
        when SCROLL:
            op = &scr_info[obj->o_which];
            elsewise = s_names[obj->o_which];
            goto norm;
        when STICK:
            op = &ws_info[obj->o_which];
            elsewise = ws_made[obj->o_which];
norm:
            know = &op->oi_know;
            guess = &op->oi_guess;
            if (*guess != NULL)
            elsewise = *guess;
        when FOOD:
            msg("you can't call that anything");
            return;
        otherwise:
            guess = &obj->o_label;
            know = NULL;
            elsewise = obj->o_label;
    }


    if (know != NULL && *know)
    {
        msg("that has already been identified");
        return;
    }

    if (elsewise != NULL && elsewise == *guess)
    {
        if (!terse)
            addmsg("Was ");
        msg("called \"%s\"", elsewise);
    }


//CAT
	curs_set(2);

    if (terse)
        msg("call it: ");
    else
        msg("what do you want to call it? ");

    if (elsewise == NULL)
        strcpy(prbuf, "");
    else
        strcpy(prbuf, elsewise);

    if (get_str(prbuf, stdscr) == NORM)
    {
        if (*guess != NULL)
            free(*guess);
        *guess = malloc(strlen(prbuf) + 1);
        if (*guess != NULL)
            strcpy(*guess, prbuf);
    }

    curs_set(0);

    msg("");
}


