/*
 * Various input/output functions
 *
 * @(#)io.c	4.32 (Berkeley) 02/05/99
 */

#include <stdarg.h>
#include <curses.h>
#include <ctype.h>
#include <string.h>
#include "rogue.h"

/*
 * msg:
 *	Display a message at the top of the screen.
 */
#define MAXMSG	(NUMCOLS - sizeof "--More--")

//CAT
int CATcurPOS;
char msgHISTORY[20][80];
static char oldMSG[80];
static char newMSG[170];


static int newpos = 0;
static char msgbuf[2*MAXMSG+1];


/* VARARGS1 */
int
msg(const char *fmt, ...)
{
    va_list args;

    /*
     * if the string is "", just clear the line
     */
    if (*fmt == '\0')
    {
        move(0, 0);

//CAT
//      clrtoeol();
        mvaddstr(0, 0, "                                                                               ");

        mpos = 0;
        return ~ESCAPE;
    }
    /*
     * otherwise add to the message and flush it out
     */
    va_start(args, fmt);
    doadd(fmt, args);
    va_end(args);
    return endmsg();
}

/*
 * addmsg:
 *	Add things to the current message
 */
/* VARARGS1 */
void
addmsg(const char *fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    doadd(fmt, args);
    va_end(args);
}

/*
 * endmsg:
 *	Display a new msg (giving him a chance to see the previous one
 *	if it is up there with the --More--)
 */
int
endmsg(void)
{
//CAT - the rest is modified
    /*
     * All messages should start with uppercase, except ones that
     * start with a pack addressing character
     */

    mvaddstr(0, 0, "                                                                               ");

    if(islower((int)msgbuf[0]) && !lower_msg && msgbuf[1] != ')')
        msgbuf[0] = (char) toupper(msgbuf[0]);

    int i;
    for(i= 18; i >= 0; i--)
        strcpy(msgHISTORY[i+1], msgHISTORY[i]);

    strcpy(msgHISTORY[0], msgbuf);
    strcpy(huh, msgbuf);


    if(mpos == 0)
        oldMSG[0] = '\0';

    newMSG[0] = '\0';
    strcpy(newMSG, oldMSG);
    if(mpos != 0)
        strcat(newMSG, ".. ");
    strcat(newMSG, msgbuf);


    oldMSG[0]= '\0';
    strcpy(oldMSG, msgbuf);
    msgbuf[0]= '\0';


    int l= strlen(newMSG);

    if(l>78)
        strncpy(msgbuf, newMSG+(l-78), 78);
    else
        strcpy(msgbuf, newMSG);

    mvaddstr(0, 0, "                                                                               ");
    mvaddstr(0, 0, msgbuf);

    CATcurPOS= strlen(msgbuf);
    mpos= newpos;
    newpos= 0;


    msgbuf[0] = '\0';
    return ~ESCAPE;
}


/*
 * doadd:
 *	Perform an add onto the message buffer
 */
void
doadd(const char *fmt, va_list args)
{
    static char buf[MAXSTR];

    /*
     * Do the printf into buf
     */
    vsprintf(buf, fmt, args);
    if (strlen(buf) + newpos >= MAXMSG)
        endmsg();

    strcat(msgbuf, buf);
    newpos = (int) strlen(msgbuf);
}

/*
 * step_ok:
 *	Returns true if it is ok to step on ch
 */
int
step_ok(int ch)
{
    switch (ch)
    {
	case ' ':
	case '|':
	case '-':
	    return FALSE;

	default:
	    return (!isalpha(ch));
    }
}

/*
 * readchar:
 *	Reads and returns a character, checking for gross input errors
 */

int
readchar(void)
{
    int ch;
    ch = md_readchar(stdscr);

    if (ch == 3)
    {
//CAT
//		quit(0);
        return(27);
    }

    return(ch);
}

int
wreadchar(WINDOW *win)
{
    int ch;

    ch = md_readchar(win);

    if (ch == 3)
    {
		quit(0);
        return(27);
    }

    return(ch);
}


/*
 * status:
 *	Display the important stats line.  Keep the cursor where it was.
 */
void
status(void)
{
    int oy, ox, temp;
    static int hpwidth = 0;
    static int s_hungry = 0;
    static int s_lvl = 0;
    static int s_pur = -1;
    static int s_hp = 0;
    static int s_arm = 0;
    static int s_str = 0;
    static int s_exp = 0;
    static char *state_name[] =
    {
	"", "Hungry", "Weak", "Faint"
    };

    /*
     * If nothing has changed since the last status, don't
     * bother.
     */
    temp = (cur_armor != NULL ? cur_armor->o_arm : pstats.s_arm);
    if (s_hp == pstats.s_hpt && s_exp == pstats.s_exp && s_pur == purse
	&& s_arm == temp && s_str == pstats.s_str && s_lvl == level
	&& s_hungry == hungry_state
	&& !stat_msg
	)
	    return;

    s_arm = temp;

    getyx(stdscr, oy, ox);
    if (s_hp != max_hp)
    {
	temp = max_hp;
	s_hp = max_hp;
	for (hpwidth = 0; temp; hpwidth++)
	    temp /= 10;
    }


    /*
     * Save current status
     */
    s_lvl = level;
    s_pur = purse;
    s_hp = pstats.s_hpt;
    s_str = pstats.s_str;
    s_exp = pstats.s_exp;
    s_hungry = hungry_state;


/*
    purse= 12345;
    hungry_state= 1;
    pstats.s_lvl= 17;
    level= 19;

    pstats.s_hpt= 99;
*/



    int eLvl = e_levels[pstats.s_lvl-1]-pstats.s_exp;
    if(eLvl < 0)
        eLvl= 0;

    move(STATLINE, 0);
    printw("Floor:%d  Gold:%-5d  Hp:%*d(%*d)  Str:%2d(%d)  Xp:%d/%d",
    level, purse, hpwidth, pstats.s_hpt, hpwidth, max_hp, pstats.s_str,
    max_stats.s_str, pstats.s_lvl, eLvl);

//CAT
    int crps= getcurx(stdscr);
    mvaddstr(STATLINE, crps, "        ");

    if(hungry_state > 0)
    {
        if(hungry_state > 1)
            attron(A_REVERSE);

        char hs[20];
        sprintf(hs, " %s ", state_name[hungry_state]);
        mvaddstr(STATLINE, crps+2, hs);

        attroff(A_REVERSE);
    }

    clrtoeol();
    move(oy, ox);
}


/*
 * wait_for
 *	Sit around until the guy types the right key
 */
void
wait_for(WINDOW *win, int ch)
{
    int c;
    if (ch == '\n')
        while ((c= wreadchar(win)) != '\n' && c != '\r')
	    continue;
    else
        while (wreadchar(win) != ch)
	    continue;
}

/*
 * show_win:
 *	Function used to display a window and wait before returning
 */
void
show_win(const char *message)
{
    WINDOW *win;

    win = hw;
    wmove(win, 0, 0);
    waddstr(win, message);
    touchwin(win);
    wrefresh(win);
    wait_for(win, ' ');
    clearok(curscr, TRUE);
    touchwin(stdscr);
}

//CAT
/*
 * show_win:
 *	Function used to display a window and wait before returning
 */
void CATshow_win(const char *message)
{
    WINDOW *win;

    win = hw;
    wmove(win, 0, 0);
    waddstr(win, message);
    touchwin(win);
    wrefresh(win);

    while(readchar() != KEY_MOUSE)
        continue;
    clearok(curscr, TRUE);
    touchwin(stdscr);
}





//*******************************************************************
//*******************************************************************
//CAT - curtains animation
void drop_curtain(WINDOW *cW)
{
    int r, c;
    for (r= 0; r < 24; r++)
    {
        for(c= 0; c < 80; c++)
        {
            wmove(cW, r, c);
            waddch(cW, '%');
        }

        wrefresh(cW);
        napms(20);
    }
}

void raise_curtain(WINDOW *cW)
{
    int r, c;
    for (r= 23; r >= 0; r--)
    {
        for(c= 0; c < 80; c++)
        {
            wmove(cW, r, c);
            waddch(cW, mvwinch(stdscr, r,c));
        }

        wrefresh(cW);
        napms(30);
    }
}

void implode_curtain(WINDOW *cW)
{

    int u= 0;
    int d= 23;
    int l= 0;
    int r= 79;

    int x= 39;
    int y= 11;
    int i, ch= '%';
    while (u <= y && d >= y && l <= x && r >= x)
    {

        for(i= l; i <= r; i++)
        {
            wmove(cW, u, i); //up
            waddch(cW, ch);
        }

        for(i= l; i <= r; i++)
        {
            wmove(cW, d, i); //down
            waddch(cW, ch);
        }



        for(i= u; i <= d; i++)
        {
            wmove(cW, i, l); //left
            waddch(cW, ch);

            wmove(cW, i, l+1); //left
            waddch(cW, ch);

            wmove(cW, i, l+2); //left
            waddch(cW, ch);
        }

        for(i= u; i <= d; i++)
        {
            wmove(cW, i, r); //right
            waddch(cW, ch);

            wmove(cW, i, r-1); //right
            waddch(cW, ch);

            wmove(cW, i, r-2); //right
            waddch(cW, ch);
        }

        u++;
        d--;
        l+= 3;
        r-= 3;

        wrefresh(cW);
        napms(30);
        //wgetch(cW);
    }
}

void explode_curtain(WINDOW *cW)
{

    int u= 11;
    int d= 12;
    int l= 33;
    int r= 46;

    int i, ch= '#';
    while (u >= 0 && d <= 24 && l >= 0 && r <= 79)
    {

        for(i= l; i <= r; i++)
        {
            ch= mvwinch(stdscr, u,i);
            wmove(cW, u, i); //up
            waddch(cW, ch);
        }

        for(i= l; i <= r; i++)
        {
            ch= mvwinch(stdscr, d,i);
            wmove(cW, d, i); //down
            waddch(cW, ch);
        }


        for(i= u; i <= d; i++)
        {
            ch= mvwinch(stdscr, i, l);
            wmove(cW, i, l); //left
            waddch(cW, ch);

            ch= mvwinch(stdscr, i, l+1);
            wmove(cW, i, l+1); //left
            waddch(cW, ch);

            ch= mvwinch(stdscr, i, l+2);
            wmove(cW, i, l+2); //left
            waddch(cW, ch);
        }

        for(i= u; i <= d; i++)
        {
            ch= mvwinch(stdscr, i, r);
            wmove(cW, i, r); //right
            waddch(cW, ch);

            ch= mvwinch(stdscr, i, r-1);
            wmove(cW, i, r-1); //right
            waddch(cW, ch);

            ch= mvwinch(stdscr, i, r-2);
            wmove(cW, i, r-2); //right
            waddch(cW, ch);
        }

        u--;
        d++;
        l-= 3;
        r+= 3;

        wrefresh(cW);
        napms(30);
        //wgetch(cW);
    }
}

