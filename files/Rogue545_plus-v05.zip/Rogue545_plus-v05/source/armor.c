/*
 * This file contains misc functions for dealing with armor
 * @(#)armor.c	4.14 (Berkeley) 02/05/99
 *
 * Rogue: Exploring the Dungeons of Doom
 * Copyright (C) 1980-1983, 1985, 1999 Michael Toy, Ken Arnold and Glenn Wichman
 * All rights reserved.
 *
 * See the file LICENSE.TXT for full copyright and licensing information.
 */

#include <curses.h>
#include "rogue.h"

//CAT
unsigned int nTURNS;


//CAT
void CATwear(THING *obj)
{
    char *sp;

    if (!dropcheck(cur_armor))
        return;

    waste_time();
    obj->o_flags |= ISKNOW;
    sp = CATinv_name(obj, TRUE);
    cur_armor = obj;

    if (!terse)
        addmsg("you are now ");
    msg("wearing %s", sp);
}


//CAT
void CATarmor_off(THING *obj)
{
    if (!dropcheck(cur_armor))
        return;

    cur_armor = NULL;

    if (terse)
        addmsg("was");
    else
        addmsg("you used to be");

    msg(" wearing %s", CATinv_name(obj, TRUE));
}


/*
 * waste_time:
 *	Do nothing but let other things happen
 */
void
waste_time(void)
{
//CAT
    nTURNS++;

    do_daemons(BEFORE);
    do_fuses(BEFORE);
    do_daemons(AFTER);
    do_fuses(AFTER);
}
