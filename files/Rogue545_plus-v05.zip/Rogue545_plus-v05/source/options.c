/*
 * This file has all the code for the option command.  I would rather
 * this command were not necessary, but it is the only way to keep the
 * wolves off of my back.
 *
 * @(#)options.c	4.24 (Berkeley) 05/10/83
 *
 * Rogue: Exploring the Dungeons of Doom
 * Copyright (C) 1980-1983, 1985, 1999 Michael Toy, Ken Arnold and Glenn Wichman
 * All rights reserved.
 *
 * See the file LICENSE.TXT for full copyright and licensing information.
 */

#include <stdlib.h>
#include <curses.h>
#include <ctype.h>
#include <string.h>
#include "rogue.h"

#define	EQSTR(a, b, c)	(strncmp(a, b, c) == 0)

#define	NUM_OPTS	(sizeof optlist / sizeof (OPTION))

/*
 * description of an option and what to do with it
 */
struct optstruct {
    char	*o_name;	/* option name */
    char	*o_prompt;	/* prompt for interactive entry */
    void 	*o_opt;		/* pointer to thing to set */
				/* function to print value */
    void 	(*o_putfunc)(void *opt);
				/* function to get value interactively */
    int		(*o_getfunc)(void *opt, WINDOW *win);
};

typedef struct optstruct	OPTION;

void	pr_optname(const OPTION *op);




/*
 * get_str:
 *	Set a string option
 */
#define MAXINP	50	/* max string to read from terminal or environment */

int
get_str(void *vopt, WINDOW *win)
{
    char *opt = (char *) vopt;
    char *sp;
    int oy, ox;
    size_t i;
    int c;
    static char buf[MAXSTR];

    getyx(win, oy, ox);
    wrefresh(win);

    /*
     * loop reading in the string, and put it in a temporary buffer
     */
//CAT wreadchar(win)/readchar()
//CAT wclrtoeol(win), wrefresh(win)
    for (sp = buf; (c = wreadchar(win)) != '\n' && c != '\r' && c != ESCAPE; wrefresh(win))
    {

//CAT
        if (c != erasechar() && c != ' ' && c != '?' && c != '!' && c != '/' && c != '-'
                && (c == -1 || !(c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z')))
            continue;
        else if (c == erasechar())	/* process erase character */
        {
            if (sp > buf)
            {
                sp--;
                for (i = strlen(unctrl(*sp)); i; i--)
                {
//CAT
                    waddch(win, '\b');
                    waddch(win, ' ');
                    waddch(win, '\b');
                }
            }

            continue;
        }
        else if (c == killchar())	/* process kill character */
        {
            sp = buf;
            wmove(win, oy, ox);
            continue;
        }
        else if (sp == buf)
        {
            if (c == '-' && win != stdscr)
            break;
            else if (c == '~')
            {
            strcpy(buf, home);
            waddstr(win, home);
            sp += strlen(home);
            continue;
            }
        }
        if (sp >= &buf[MAXINP] || !(isprint(c) || c == ' '))
            putchar(CTRL('G'));
        else
        {
            *sp++ = (char) c;
            waddstr(win, unctrl(c));
        }

    }

    *sp = '\0';
    if (sp > buf)	/* only change option if something has been typed */
	strucpy(opt, buf, strlen(buf));
    mvwprintw(win, oy, ox, "%s\n", opt);
    wrefresh(win);
    if (win == stdscr)
	mpos += (int)(sp - buf);
    if (c == '-')
	return MINUS;
    else if (c == ESCAPE)
	return QUIT;
    else
	return NORM;
}



#ifdef MASTER
/*
 * get_num:
 *	Get a numeric option
 */
int
get_num(void *vp, WINDOW *win)
{
    int *opt = (int *) vp;
    int i;
    static char buf[MAXSTR];

    if ((i = get_str(buf, win)) == NORM)
	*opt = atoi(buf);
    return i;
}
#endif

/*
 * strucpy:
 *	Copy string using unctrl for things
 */

void
strucpy(char *s1, const char *s2, size_t len)
{
    if (len > MAXINP)
	len = MAXINP;
    while (len--)
    {
	if (isprint((int)*s2) || *s2 == ' ')
	    *s1++ = *s2;
	s2++;
    }
    *s1 = '\0';
}

