main()
{
    printf("%s\n", crypt(getpass("Password: "), "mT"));
}
