/*
 * vars.c
 *
 * This source herein may be modified and/or distributed by anybody who
 * so desires, with the following restrictions:
 *    1.)  No portion of this notice shall be removed.
 *    2.)  Credit shall not be taken for the creation of this source.
 *    3.)  This code is not to be traded, sold, or used for personal
 *         gain or profit.
 *
 */

#include "rogue.h"

boolean interrupted;

char *win_msg[7] = 
{
    MESG_700,
    MESG_701,
    MESG_702,
    MESG_703,
    MESG_704,
    MESG_705,
    MESG_706
};

/* vars.c */
struct Game game;
char is_first;
char buf[DCOLS];
char current_score[82];

char terminal[DROWS][DCOLS];
char buffer[DROWS][DCOLS];

ScreenType screen;
RectangleType g = {0, 11, 160, 138};
char **invList;
unsigned short actionFlag = 0;
unsigned short direction = 0;
char paused = 0;
unsigned char statusPage = 0;
int count = 0;
char map_shown;
WinHandle font;

prefs_t prefs;
