#include "rogue.h"
#include "RogueRsc.h"

/***********************************************************************
 ***********************************************************************/
static void LoadPrefs()
{
    if (!PrefGetAppPreferencesV10(ROGUE, 2, &prefs, sizeof(prefs_t)))
    {
        if (!PrefGetAppPreferencesV10(ROGUE, 1, &prefs.use_hardkeys, sizeof(char)))
            prefs.use_hardkeys = true;
        prefs.dont_remove  = false;
    }
}

static void SavePrefs()
{
    PrefSetAppPreferencesV10(ROGUE, 2, &prefs, sizeof(prefs_t));
}

/***********************************************************************
 ***********************************************************************/
static void init_id_table(ULong type, char *name, int total, int size)
{
    VoidHand handle;
    DmOpenRef ref;
    Err err;
	UInt i;
    char *p;

    ref = DmOpenDatabaseByTypeCreator(type, ROGUE, dmModeWrite);
    if (ref) goto exit;

    err = DmCreateDatabase(0, name, ROGUE, type, false);
    ErrFatalDisplayIf(err, "");

    ref = DmOpenDatabaseByTypeCreator(type, ROGUE, dmModeWrite);
    ErrFatalDisplayIf(!ref, "");

    p = MemPtrNew(size);
    MemSet(p, size, 0);
    for (i = 0; i < total; i++) {
        handle = DmNewRecord(ref, &i, size);
        DmWrite(MemHandleLock(handle), 0, p, size);
        MemHandleUnlock(handle);
        DmReleaseRecord(ref, i, true);
    }
    MemPtrFree(p);

exit:
    DmCloseDatabase(ref);
}

/***********************************************************************
 ***********************************************************************/
static void SetScreen(void)
{
    screen.charWidth  = 6; // 8;
    screen.charHeight = 8;

    screen.width      = 26; // 160 / screen.charWidth;
    screen.height     = 17; // 160 / screen.charHeight;
}

/***********************************************************************
 ***********************************************************************/
static void InitFont(Boolean create)
{
    WinHandle work;
    Word err;

    if (create)
    {
        font = WinCreateOffscreenWindow(96, 32, screenFormat, &err);
		ErrFatalDisplayIf(err, "");
	    work = WinGetDrawWindow();
        WinSetDrawWindow(font);

        DrawBitmap(0, 0, FontBitmap);

        WinSetDrawWindow(work);
    }
    else
    {
        WinDeleteWindow(font, false);
    }
}

/***********************************************************************
 ***********************************************************************/
static Boolean AppHandleEvent( EventPtr eventP)
{
    Word formId;
    FormPtr frmP;


    if (eventP->eType == frmLoadEvent) {
        // Load the form resource.
        formId = eventP->data.frmLoad.formID;
        frmP = FrmInitForm( formId);
        FrmSetActiveForm(frmP);

        // Set the event handler for the form.  The handler of the currently
        // active form is called by FrmHandleEvent each time is receives an
        // event.
        switch (formId) { //{{PFW_FORM_LOAD
		case MainForm:
			FrmSetEventHandler(frmP, MainFormHandleEvent);
			break;
		case AboutForm:
			FrmSetEventHandler(frmP, AboutFormHandleEvent);
			break;
        case RipForm:
            FrmSetEventHandler(frmP, RipFormHandleEvent);
            break;
        case ScoreForm:
            FrmSetEventHandler(frmP, ScoreFormHandleEvent);
            break;
        case OptionsForm:
            FrmSetEventHandler(frmP, OptionFormHandleEvent);
            break;
		default:
			//ErrNonFatalDisplay("Invalid Form Load Event");
			break;

        } //}}PFW_FORM_LOAD

        return true;
    }

    return false;
}

/***********************************************************************
 ***********************************************************************/
static void AppEventLoop(void)
{
    Word error;
    EventType event;

    do {
        EvtGetEvent(&event, evtWaitForever);

		if (event.eType == winExitEvent) {
			if (event.data.winExit.exitWindow == (WinHandle)FrmGetFormPtr(MainForm))
				paused = true;
		}
		else if (event.eType == winEnterEvent) {
			if (event.data.winEnter.enterWindow == (WinHandle) FrmGetFormPtr(MainForm) &&
				event.data.winEnter.enterWindow == (WinHandle) FrmGetFirstForm ())
				paused = false;
		}

		if (! HardKeyHandleEvent(&event))
        	if (! SysHandleEvent(&event))
                if (! MenuHandleEvent(0, &event, &error))
                    if (! AppHandleEvent(&event))
                        FrmDispatchEvent(&event);
    } while (event.eType != appStopEvent);
}

/***********************************************************************
 ***********************************************************************/
static Err AppStart(void)
{
    LoadPrefs();

    check_message();
    message(MESG_600, 0);

    InitFont(true);
    SetScreen();
    rogue.gameOver = 1;
    
    init_id_table(TMP_TYPE, TMP_NAME, ALL, sizeof(struct did));
    init_id_table(SAV_TYPE, SAV_NAME, ALL, sizeof(struct did));
    init_id_table(SCO_TYPE, SCO_NAME, 11,  sizeof(ScoreType));

    check_message();

    return 0;
}

/***********************************************************************
 ***********************************************************************/
static void AppStop(void)
{
    SavePrefs();

    InitFont(false);

    FrmSaveAllForms();
    FrmCloseAllForms();

	if (!rogue.gameOver)
        save_game(TMP_NAME, TMP_TYPE);

	rogueFreeLevel();

    EvtFlushPenQueue();
    EvtFlushKeyQueue();
}

/***********************************************************************
 ***********************************************************************/
#define version20					0x02000000

static Err RomVersionCompatible(DWord requiredVersion, Word launchFlags)
{
	DWord romVersion;

	// See if we're on in minimum required version of the ROM or later.
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if (romVersion < requiredVersion)
		{
		if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
			(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
			{
			FrmAlert (RomIncompatibleAlert);
		
			// Pilot 1.0 will continuously relaunch this app unless we switch to 
			// another safe one.
			if (romVersion < version20)
				{
				Err err = 0;
				
				AppLaunchWithCommand(sysFileCDefaultApp, sysAppLaunchCmdNormalLaunch, NULL);
				}
			}
		
		return (sysErrRomIncompatible);
		}

	return (0);
}

static DWord RoguePilotMain( Word cmd, Ptr cmdPBP, Word launchFlags)
{
    Err error;

	error = RomVersionCompatible (version20, launchFlags);
	if (error) return (error);

	switch (cmd)
		{
		case sysAppLaunchCmdNormalLaunch:
			error = AppStart();
			if (error) 
				return error;
				
			FrmGotoForm(MainForm);
			AppEventLoop();
			AppStop();
			break;

		default:
			break;

		}
	return 0;
}

/***********************************************************************
 ***********************************************************************/
DWord PilotMain( Word cmd, Ptr cmdPBP, Word launchFlags)
{
    return RoguePilotMain( cmd, cmdPBP, launchFlags);
}

