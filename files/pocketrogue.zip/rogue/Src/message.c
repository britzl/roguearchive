/*
 * message.c
 *
 * This source herein may be modified and/or distributed by anybody who
 * so desires, with the following restrictions:
 *    1.)  No portion of this notice shall be removed.
 *    2.)  Credit shall not be taken for the creation of this source.
 *    3.)  This code is not to be traded, sold, or used for personal
 *         gain or profit.
 *
 */
        

#include "rogue.h"

#define	CTRL(c)	((c) & 037)

char msg_line[DCOLS] = "";
short msg_col = 0;
boolean msg_cleared = 1;
char hunger_str[8] = "";

extern boolean cant_int, did_int, interrupted, save_is_interactive;
extern short add_strength;
extern short cur_level;


void message(char *msg, boolean intrpt)
{
    if (rogue.gameOver)
        return;

    if (intrpt) {
        interrupted = 1;
    }
    if (!msg_cleared) {
        refresh();
        wait_for_ack();
        check_message();
    }

    strcpy(msg_line, msg);
    RogueMessage(msg_line);
    msg_cleared = 0;
}

void remessage(void)
{
    if (msg_line[0]) {
        message(msg_line, 0);
    }
}
        
void check_message(void)
{
    if (msg_cleared) {
        return;
    }
    ClearString(); // RogueMessage("");

    refresh();
    msg_cleared = 1;
}

/*
 LEVEL:99  Gold:999999 
 HP:999(999) ST:99(99) 
 AC:99 EXP:21/10000000 
 Hungry
*/
void print_stats(register int stat_mask)
{
    switch (stat_mask)
    {
    case STAT_ALL:
    case STAT_GOLD:
    case STAT_HP:
    case STAT_HUNGER:
        statusPage = 0;
        break;

    case STAT_STRENGTH:
    case STAT_ARMOR:
    case STAT_EXP:
        statusPage = 1;
        break;

    default:
        break;
    }
    RogueStatus();
}
