/*
 * curses.c
 *
 * This source herein may be modified and/or distributed by anybody who
 * so desires, with the following restrictions:
 *    1.)  No portion of this notice shall be removed.
 *    2.)  Credit shall not be taken for the creation of this source.
 *    3.)  This code is not to be traded, sold, or used for personal
 *         gain or profit.
 *
 */

#include "rogue.h"

static void clear_buffers();

static WINDOW scr_buf;
static WINDOW *curscr = &scr_buf;

static void move(short row, short col)
{
	curscr->_cury = row;
	curscr->_curx = col;
}

void addch(int ch)
{
	short row, col;

	row = curscr->_cury;
	col = curscr->_curx++;

	ch |= ST_MASK;

	buffer[row][col] = (char) ch;
	terminal[row][col] = 1;
}

void mvaddch(short row, short col, int ch)
{
	move(row, col);
	addch(ch);
}


mvinch(short row, short col)
{
	move(row, col);
	return((int) buffer[row][col] & TS_MASK);
}

void clear()
{
//	cur_row = cur_col = 0;
	move(0, 0);
    clear_buffers();
}

static void clear_buffers()
{
	int i, j;

	for (i = 0; i < DROWS; i++) {
		for (j = 0; j < DCOLS; j++) {
			terminal[i][j] = 0;
			buffer[i][j] = ' ';
		}
	}
}
