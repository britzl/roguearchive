/*
 * object.c
 *
 * This source herein may be modified and/or distributed by anybody who
 * so desires, with the following restrictions:
 *    1.)  No portion of this notice shall be removed.
 *    2.)  Credit shall not be taken for the creation of this source.
 *    3.)  This code is not to be traded, sold, or used for personal
 *         gain or profit.
 *
 */

#include "rogue.h"

char *fruit = MESG_333;


static void put_gold();
static void plant_gold(short row, short col, boolean is_maze);
static unsigned short gr_what_is();
static void gr_scroll(object *obj);
static void gr_potion(object *obj);
static void gr_weapon(object *obj, int assign_wk);
static void gr_armor(object *obj, int assign_wk);
static void gr_wand(object *obj);
static void make_party();
static void rand_place(object *obj);
static int next_party();


object level_objects;
unsigned short dungeon[DROWS][DCOLS];
short foods = 0;
short party_counter;
object *free_list = (object *)0;
 
fighter rogue = {
    0, 0,       /* armor, weapon */
    0, 0,       /* rings */
    INIT_HP,    /* Hp current */
    INIT_HP,    /* Hp max */
    16, 16,     /* Str */
    {0},        /* pack */
    0,          /* gold */
    1, 0,       /* exp, exp_points */
    0, 0,       /* row, col */
    '@',        /* char */
    1250,       /* moves */
};
     
char *po_color[14] = {
    MESG_334, MESG_335, MESG_336, MESG_337, MESG_338,
    MESG_339, MESG_340, MESG_341, MESG_342, MESG_343,
    MESG_344, MESG_345, MESG_346, MESG_347,
};

char po_title[14][34], sc_title[12][34], wa_title[10][34], ri_title[11][34];

struct id id_potions[POTIONS] = {
     {100, po_title[ 0], MESG_348, 0},
     {250, po_title[ 1], MESG_349, 0},
     {100, po_title[ 2], MESG_350, 0},
     {200, po_title[ 3], MESG_351, 0},
     {10,  po_title[ 4], MESG_352, 0},
     {300, po_title[ 5], MESG_353, 0},
     {10,  po_title[ 6], MESG_354, 0},
     {25,  po_title[ 7], MESG_355, 0},
     {100, po_title[ 8], MESG_356, 0},
     {100, po_title[ 9], MESG_357, 0},
     {10,  po_title[10], MESG_358, 0},
     {80,  po_title[11], MESG_359, 0},
     {150, po_title[12], MESG_360, 0},
     {145, po_title[13], MESG_361, 0},
 };

struct id id_scrolls[SCROLLS] = {
    {505, sc_title[ 0], MESG_362, 0},
    {200, sc_title[ 1], MESG_363, 0},
    {235, sc_title[ 2], MESG_364, 0},
    {235, sc_title[ 3], MESG_365, 0},
    {175, sc_title[ 4], MESG_366, 0},
    {190, sc_title[ 5], MESG_367, 0},
    {25,  sc_title[ 6], MESG_368, 0},
    {610, sc_title[ 7], MESG_369, 0},
    {210, sc_title[ 8], MESG_370, 0},
    {100, sc_title[ 9], MESG_371, 0},
    {25,  sc_title[10], MESG_372, 0},
    {180, sc_title[11], MESG_373, 0},
};

struct id id_weapons[WEAPONS] = {
    {150, MESG_374,   "", 0},
    {8,   MESG_375, "", 0},
    {15,  MESG_376, "", 0},
    {27,  MESG_377, "", 0},
    {35,  MESG_378, "", 0},
    {360, MESG_379, "", 0},
    {470, MESG_380, "", 0},
    {580, MESG_381, "", 0},
};
     
struct id id_armors[ARMORS] = {
    {300, MESG_382, "", (UNIDENTIFIED)},
    {300, MESG_383, "", (UNIDENTIFIED)},
    {400, MESG_384, "", (UNIDENTIFIED)},
    {500, MESG_385, "", (UNIDENTIFIED)},
    {600, MESG_386, "", (UNIDENTIFIED)},
    {600, MESG_387, "", (UNIDENTIFIED)},
    {700, MESG_388, "", (UNIDENTIFIED)}
};

struct id id_wands[WANDS] = {
    {25, wa_title[ 0], MESG_389, 0},
    {50, wa_title[ 1], MESG_390, 0},
    {45, wa_title[ 2], MESG_391, 0},
    {8,  wa_title[ 3], MESG_392, 0},
    {55, wa_title[ 4], MESG_393, 0},
    {2,  wa_title[ 5], MESG_394, 0},
    {25, wa_title[ 6], MESG_395, 0},
    {20, wa_title[ 7], MESG_396, 0},
    {20, wa_title[ 8], MESG_397, 0},
    {0,  wa_title[ 9], MESG_398, 0},
};
     
struct id id_rings[RINGS] = {
    {250, ri_title[ 0], MESG_399, 0},
    {100, ri_title[ 1], MESG_400, 0},
    {255, ri_title[ 2], MESG_401, 0},
    {295, ri_title[ 3], MESG_402, 0},
    {200, ri_title[ 4], MESG_403, 0},
    {250, ri_title[ 5], MESG_404, 0},
    {250, ri_title[ 6], MESG_405, 0},
    {25,  ri_title[ 7], MESG_406, 0},
    {300, ri_title[ 8], MESG_407, 0},
    {290, ri_title[ 9], MESG_408, 0},
    {270, ri_title[10], MESG_409, 0},
};

extern short cur_level, max_level;
extern short party_room;
extern char *error_file;
extern boolean is_wood[];


void put_objects()
{
    short i, n;
    object *obj;
        
    if (game.cur_level < game.max_level) {
        return;
    }
    n = coin_toss() ? get_rand(2, 4) : get_rand(3, 5);
    while (rand_percent(33)) {
        n++;
    }
    if (game.cur_level == game.party_counter) {
        make_party();
        game.party_counter = next_party();
    }
    for (i = 0; i < n; i++) {
        obj = gr_object();
        rand_place(obj);
    }
    put_gold();
}
        
static void put_gold()
{
    short i, j;
    short row,col;
    boolean is_maze, is_room;

    for (i = 0; i < MAXROOMS; i++) {
        is_maze = (rooms[i].is_room & R_MAZE) ? 1 : 0;
        is_room = (rooms[i].is_room & R_ROOM) ? 1 : 0;

        if (!(is_room || is_maze)) {
            continue;
        }
        if (is_maze || rand_percent(GOLD_PERCENT)) {
            for (j = 0; j < 50; j++) {
                row = get_rand(rooms[i].top_row+1,
                               rooms[i].bottom_row-1);
                col = get_rand(rooms[i].left_col+1,
                               rooms[i].right_col-1);
                if ((dungeon[row][col] == FLOOR) ||
                    (dungeon[row][col] == TUNNEL)) {
                    plant_gold(row, col, is_maze);
                    break;
                }
            }
        }
    }
}
        
static void plant_gold(short row, short col, boolean is_maze)
{
    object *obj;

    obj = alloc_object();
    obj->row = row; obj->col = col;
    obj->what_is = GOLD;
    obj->quantity = get_rand((2 * game.cur_level), (16 * game.cur_level));
    if (is_maze) {
        obj->quantity += obj->quantity / 2;
    }
    dungeon[row][col] |= OBJECT;
    (void) add_to_pack(obj, &level_objects, 0);
}

void place_at(object *obj, int row, int col)
{
    obj->row = row;
    obj->col = col;
    dungeon[row][col] |= OBJECT;
    (void) add_to_pack(obj, &level_objects, 0);
}

object *object_at(register object *pack, short row, short col)
{
    object *obj;
    obj = pack->next_object;

    while (obj && ((obj->row != row) || (obj->col != col))) {
        obj = obj->next_object;
    }
    return(obj);
}
        
object *get_letter_object(int ch)
{
    object *obj;

    obj = rogue.pack.next_object;
    while (obj && (obj->ichar != ch)) {
        obj = obj->next_object;
    }
    return(obj);
}
        
void free_stuff(object *objlist, int type)
{
    object *obj;

    if (!objlist)
        return;

    while (objlist->next_object) {
        obj = objlist->next_object;
        objlist->next_object = objlist->next_object->next_object;
        if (type)
        {
            VoidHand h = MemPtrRecoverHandle(obj);
            MemHandleUnlock(h);
            MemHandleFree(h);
        }
        else
            free_object(obj); // �v�f�̍폜
    }
    objlist = (object*)0;
}

char *name_of(object *obj)
{
    int i;
    static char bf[81];     /* by Yasha */
    static unsigned short wa[] = {
        SCROLL, POTION, WAND, ARMOR, RING, AMULET
    };
    static char *na[] = {
        MESG_003, MESG_004, MESG_005, MESG_007, MESG_008, MESG_009,
    };

#ifndef JP
    if (obj->what_is == WAND) {
        return game.is_wood[obj->which_kind] ? MESG_006 : MESG_005;
    }
#endif

    if (obj->what_is == WEAPON) {
#ifdef JP
        return id_weapons[obj->which_kind].title;
#else
        strcpy(bf, id_weapons[obj->which_kind].title);
        switch (obj->which_kind) {
            case DART:
            case ARROW:
            case DAGGER:
            case SHURIKEN:
            if (obj->quantity == 1) {
                i = strlen(bf);
                bf[i-2] = ' ';
                bf[i-1] = '\0';
            }
            break;
        }
        return bf;
#endif
    }

    if (obj->what_is == FOOD) {
        return (obj->which_kind == RATION)? MESG_002 : fruit;
    }

    for (i = 0; i < 6; i++) {
        if (obj->what_is == wa[i]) {
#ifdef JP
            return na[i];
#else
            sprintf(bf, na[i], obj->quantity > 1 ? "s" : "");
            return bf;
#endif
        }
    }
    return MESG_080;
}

object *gr_object()
{
    object *obj;

    obj = alloc_object();

    if (game.foods < (game.cur_level/3))
    {
        obj->what_is = FOOD;
        game.foods++;
    } else {
        obj->what_is = gr_what_is();
    }
    switch(obj->what_is) {
    case SCROLL:
        gr_scroll(obj);
        break;
    case POTION:
        gr_potion(obj);
        break;
    case WEAPON:
        gr_weapon(obj, 1);
        break;
    case ARMOR:
        gr_armor(obj, 1);
        break;
    case WAND:
        gr_wand(obj);
        break;
    case FOOD:
        get_food(obj, 0);
        break;
    case RING:
        gr_ring(obj, 1);
        break;
    }
    return(obj);
}
        

static unsigned short gr_what_is()
{
    register short percent;
    register int i;
    static short per[] = { 30, 60, 64, 74, 83, 88, 91 };
    static unsigned short ret[] = {
        SCROLL, POTION, WAND, WEAPON, ARMOR, FOOD, RING,
    };
    percent = get_rand(1, 91);

    for (i = 0;; i++) {
        if (percent <= per[i])
            return ret[i];
    }
}
        
static void gr_scroll(object *obj)
{
    short percent;
    register int i;
    static short per[SCROLLS] = {
        5, 11, 16, 21, 36, 44, 51, 56, 65, 74, 80, 85,
    };

    percent = get_rand(0, 85);
    obj->what_is = SCROLL;
    for (i = 0;; i++) {
        if (percent <= per[i]) {
            obj->which_kind = i;
            return;
        }
    }
}

static void gr_potion(object *obj)
{
    short percent;
    register int i;
    static short per[POTIONS] = {
        10, 20, 30, 40, 50, 55, 65, 75, 85, 95, 105, 110, 114, 118,
    };

    percent = get_rand(1, 118);
    obj->what_is = POTION;

    for (i = 0; i < POTIONS; i++) {
        if (percent <= per[i]) {
            obj->which_kind = i;
            return;
        }
    }
}

static void gr_weapon(object *obj, int assign_wk)
{
    short i;
    short percent;
    short blessing, increment;
    static char *da[WEAPONS] = 
    { "1d1", "1d1", "1d2", "1d3", "1d4", "2d3", "3d4", "4d5"};

    obj->what_is = WEAPON;
    if (assign_wk) {
        obj->which_kind = get_rand(0, (WEAPONS - 1));
    }
    if ((i = obj->which_kind) == ARROW || i == DAGGER ||
        i == SHURIKEN || i == DART) {
        obj->quantity = get_rand(3, 15);
        obj->quiver = get_rand(0, 126);
    } else {
        obj->quantity = 1;
    }
    obj->hit_enchant = obj->d_enchant = 0;

    percent = get_rand(1, 96);
    blessing = get_rand(1, 3);

    if (percent <= 16) {
        increment = 1;
    } else if (percent <= 32) {
        increment = -1;
        obj->is_cursed = 1;
    }
    if (percent <= 32) {
        for (i = 0; i < blessing; i++) {
            if (coin_toss()) {
                obj->hit_enchant += increment;
            } else {
                obj->d_enchant += increment;
            }
        }
    }
    strcpy(obj->damage, da[obj->which_kind]);
}

static void gr_armor(object *obj, int assign_wk)
{
    short percent;
    short blessing;

    obj->what_is = ARMOR;
    if (assign_wk)  /* by Yasha */
        obj->which_kind = get_rand(0, (ARMORS - 1));
    obj->class = obj->which_kind + 2;
    if ((obj->which_kind == PLATE) || (obj->which_kind == SPLINT)) {
        obj->class--;
    }
    obj->is_protected = 0;
    obj->d_enchant = 0;

    percent = get_rand(1, 100);
    blessing = get_rand(1, 3);

    if (percent <= 16) {
        obj->is_cursed = 1;
        obj->d_enchant -= blessing;
    } else if (percent <= 33) {
        obj->d_enchant += blessing;
    }
}
        
static void gr_wand(object *obj)
{
    obj->what_is = WAND;
    obj->which_kind = get_rand(0, (WANDS - 1));
    if (obj->which_kind == MAGIC_MISSILE) {
        obj->class = get_rand(6, 12);
    } else if (obj->which_kind == CANCELLATION) {
        obj->class = get_rand(5, 9);
    } else {
        obj->class = get_rand(3, 6);
    }
}
        
void get_food(object *obj, boolean force_ration)
{
    obj->what_is = FOOD;

    if (force_ration || rand_percent(80)) {
        obj->which_kind = RATION;
    } else {
        obj->which_kind = FRUIT;
    }
}
        
void put_stairs()
{
    short row, col;

    gr_row_col(&row, &col, (FLOOR | TUNNEL));
    dungeon[row][col] |= STAIRS;
}
        
get_armor_class(object *obj)
{
    if (obj) {
        return(obj->class + obj->d_enchant);
    }
    return(0);
}
        
object *alloc_object()
{
    object *obj;
        
    if (free_list) {
        obj = free_list;
        free_list = free_list->next_object;
    } else {
        VoidHand h = MemHandleNew(sizeof(object));
        if (!h) {
            message("Cannot allocate object, saving game", 0);
//            save_into_file(error_file);
            return (object *)0;
        }
        obj = (object *)MemHandleLock(h);
    }
    obj->quantity = 1;
    obj->ichar = 'L';
    obj->picked_up = obj->is_cursed = 0;
    obj->in_use_flags = NOT_USED;
    obj->identified = UNIDENTIFIED;
    strcpy(obj->damage, "1d1");

    return(obj);
}
        
void free_object(object *obj)
{
    obj->next_object = free_list;
    free_list = obj;
}
        
static void make_party()
{
    short n;

    game.party_room = gr_room();
    n = rand_percent(99) ? party_objects(game.party_room) : 11;
    if (rand_percent(99)) {
        party_monsters(game.party_room, n);
    }
}
        
void show_objects()
{
    object *obj;
    short mc, rc, row, col;
    object *monster;
        
    obj = level_objects.next_object;
    while (obj) {
        row = obj->row;
        col = obj->col;
        rc = get_mask_char(obj->what_is);

        if (dungeon[row][col] & MONSTER) {
            monster = object_at(&level_monsters, row, col);
            if (monster) {
                monster->trail_char = rc;
            }
        }
        mc = mvinch(row, col);
        if (((mc < 'A') || (mc > 'Z')) &&
            ((row != rogue.row) || (col != rogue.col))) {
            mvaddch(row, col, rc);
        }
        obj = obj->next_object;
    }
    monster = level_monsters.next_object;

    while (monster) {
        if (monster->m_flags & IMITATES) {
            mvaddch(monster->row, monster->col, (int) monster->disguise);
        }
        monster = monster->next_monster;
    }
}
        
void put_amulet()
{
    object *obj;

    obj = alloc_object();
    obj->what_is = AMULET;
    rand_place(obj);
}
        
static void rand_place(object *obj)
{
    short row, col;

    gr_row_col(&row, &col, (FLOOR | TUNNEL));
    place_at(obj, row, col);

}

static int next_party()
{
    int n;

    n = game.cur_level;
    while (n % PARTY_TIME) {
        n++;
    }
    return(get_rand((n + 1), (n + PARTY_TIME)));
}
