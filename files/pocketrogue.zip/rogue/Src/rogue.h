#ifndef __ROGUE_H__
#define __ROGUE_H__

/*
 * rogue.h
 *
 * This source herein may be modified and/or distributed by anybody who
 * so desires, with the following restrictions:
 *    1.)  This notice shall not be removed.
 *    2.)  Credit shall not be taken for the creation of this source.
 *    3.)  This code is not to be traded, sold, or used for personal
 *         gain or profit.
 *
 */
#include <Pilot.h>
#include <SysEvtMgr.h>
#include <DateTime.h>

// #define JP
#include "mesg.h"

#include "constant.h"
#include "types.h"
#include "externs.h"

#endif
