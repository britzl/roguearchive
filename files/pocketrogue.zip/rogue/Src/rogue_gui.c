#include "rogue.h"
#include "rogueRsc.h"

static VoidHand h;

static void SetStrToField(FormPtr frm, int theFieldID, char *theDrawStr);
static int  GetFldStr(FormPtr frm, Int FldID, CharPtr theStr);
static void DrawBitmapChar(char c, SWord x, SWord y);
static Word GetCommand(char c);

static char redraw_req = 0;

struct command
{
    char c;
    Word cmd;
};

struct command command_table[] = 
{
    {'.', A1Rest},
    {'s', A1Search},
    {'i', A2Inventory},
    {'f', A1Fight},
    {'F', A1Fighttothedeath},
    {'e', A3Eat},
    {'q', A3Quaff},
    {'r', A3ReadScroll},
    {'m', A1MoveOnto},
    {'d', A3Drop},
    {'P', A3PutonRing},
    {'R', A3RemoveRing},
    {'>', A1Descendlevel},
    {'<', A1Ascendlevel},
    {')', A2InventoryWeapon},
    {']', A2InventoryArmor},
    {'=', A2InventoryRings},
    {'^', A1IDTrap},
    {'T', A3TakeOff},
    {'W', A3Wear},
    {'w', A3Wield},
    {'z', A3Zap},
    {'t', A3Throw},
    {'c', A3Callit},
//    {'a', RogueReDo}
};

/***********************************************************************
 ***********************************************************************/
static VoidPtr GetObjectPtr(Word objectID )
{
    FormPtr frmP;

    frmP = FrmGetActiveForm();
    if (!frmP)
        return 0;
    return (FrmGetObjectPtr( frmP, FrmGetObjectIndex( frmP, objectID)));
}

/***********************************************************************
 ***********************************************************************/
//static Word old_cmd;
static void DoCommand(Word command)
{
    char ch = -1, flg = true;

    flg = true;
    if (command != RogueAbout && command != RogueRanking)
        check_message();

_do:
    switch (command) {
    case RogueNewGame:
        rogue.gameOver = 1;
        map_shown = 0;
        ClearGadget();
        rogueNewLevel(true);
        break;

    case RogueSaveGame:
        check_message();
        message(MESG_601, 0);

        if (save_game(SAV_NAME, SAV_TYPE))
            message(MESG_602, 0);
        flg = false;
        break;

    case RogueLoadGame:
        if (!FrmAlert(LoadAlert)) {
            if (restore(SAV_TYPE)) {
                check_message();
                message(MESG_603, 0);
                flg = true;
            }
            else {
                FrmAlert(NotFoundAlert);
                flg = false;
            }
        }
        else
            flg = false;
        break;

    case A2Discovered:
        check_message();
        message(MESG_045, 0);
        ch = PopupList(0, 3);
        if (ch != -1)
            if (PopupList(0, ch + 4) == CANCEL) {
                check_message();
                message(MESG_046, 0);
            }
        flg = false;
        break;

    case RogueOptions:
        FrmPopupForm(OptionsForm);
        flg = false;
        break;

    case RogueAbout:
        FrmPopupForm(AboutForm);
        flg = false;
        break;

    case RogueCommand:
        command = PopupList(0, 2);
        if (command)
            goto _do;
        else
            flg = false;
        break;

    case RogueMap:
        DrawMap(false); // Map(-1, -1);
        flg = false;
        break;

    case RogueRanking:
        FrmPopupForm(ScoreForm);
        flg = false;
        break;

    case A1Remessage:
        Remessage();
        flg = false;
        break;

    case A1Rest: /* ok */
        rest(count > 0 ? count : 1);
        break;

    case A1Search: /* ok */
        search(count > 0 ? count : 1, 0);
        break;

    case A1Fight:
    case A1Fighttothedeath:
    case A1MoveOnto:
    case A3Throw:
    case A1IDTrap:
    case A3Zap:
        message(MESG_055, 0);
        flg = false;
        actionFlag = command;
        break;

    case A2InventoryWeapon:
        inv_armor_weapon(true);
        break;

    case A2InventoryArmor:
        inv_armor_weapon(false);
        break;

    case A2Inventory:
        message(MESG_041, 0);
        PopupList(ALL_OBJECTS, 0);
        check_message();
        break;

    case A3Eat:
        eat();
        break;

    case A3Quaff:
        quaff();
        break;

    case A3ReadScroll:
        read_scroll();
        break;

    case A3Drop:
        drop();
        break;

    case A3Callit:
        call_it();
        break;

    case A3PutonRing:
        put_on_ring();
        break;

    case A3RemoveRing:
        remove_ring();
        break;

    case A2InventoryRings:
        inv_rings();
        break;

    case A1Descendlevel:
        if (drop_check())
            rogueNewLevel(true);
        break;

    case A1Ascendlevel:
        if (check_up())
            rogueNewLevel(true);
        break;

    case A3TakeOff:
        take_off();
        break;

    case A3Wear:
        wear();
        break;

    case A3Wield:
        wield();
        break;

    case A1KickIntoPack:
        kick_into_pack();
        break;

//    case RogueReDo:
//        message("Redo!", 0);
//        command = old_cmd;
//       goto _do;
//        break;
    default:
        break;
    }

//    old_cmd = command;
    if (flg)
        doSomething();
}

/***********************************************************************
 ***********************************************************************/
Boolean MainFormHandleEvent( EventPtr eventP)
{
    Boolean handled = false;
    char digit[3], i = 0, dirs[] = {'j', 'k', 'h', 'l'};

    switch (eventP->eType) {
    case menuEvent:
        if (rogue.gameOver)
        {
            if (eventP->data.menu.itemID == RogueNewGame || eventP->data.menu.itemID == RogueAbout || eventP->data.menu.itemID == RogueRanking)
                DoCommand(eventP->data.menu.itemID);
        }
        else
            DoCommand(eventP->data.menu.itemID);
        handled = true;
        break;

    case frmOpenEvent:
        FrmDrawForm(FrmGetActiveForm());

        DoCommand(RogueNewGame);
        RogueStatus();

        handled = true;
        break;

    case keyDownEvent:
        if (!rogue.gameOver)
        {
            switch (eventP->data.keyDown.chr)
            {
            case rightArrowChr: i++;
            case leftArrowChr:  i++;
            case upArrowChr:    i++;
            case downArrowChr: 
                direction = dirs[i];
                doSomething();
                break;

            case 'y':
            case 'b':
            case 'h':
            case 'u':
            case 'n':
            case 'l':
            case 'k':
            case 'j':

            case 'H':
            case 'J':
            case 'K':
            case 'L':
            case 'B':
            case 'Y':
            case 'U':
            case 'N':

            case '\010':
            case '\012':
            case '\013':
            case '\014':
            case '\031':
            case '\025':
            case '\016':
            case '\002':
                direction = eventP->data.keyDown.chr;
                doSomething();
                break;

            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':
            case '9':
                if (count < 100) {
                    count = (10 * count) + (eventP->data.keyDown.chr - '0');

                    StrPrintF(digit, "%d", count);
                    check_message();
                    message(digit, 0);
                }
                break;

            default:
                DoCommand(GetCommand(eventP->data.keyDown.chr));
                break;
            }
        }
        handled = true;
        break;
    case penDownEvent:
        if (!rogue.gameOver) {
            if (map_shown)
                Map(eventP->screenX, eventP->screenY);
            else {
                direction = Direction(eventP->screenX, eventP->screenY);
                doSomething();
            }
        }
        handled = true;
        break;
    default:
        break;
    }
    return handled;
}

/***********************************************************************
 ***********************************************************************/
Boolean AboutFormHandleEvent( EventPtr eventP)
{
    Boolean handled = false;
    FormPtr frmP;

    switch (eventP->eType) {
    case ctlSelectEvent:
        switch (eventP->data.ctlSelect.controlID) {
        case AboutOKButton:
            FrmReturnToForm(0);
            handled = true; 
            break;

        default:
            break;
        }
        break;

    case frmOpenEvent:
        frmP = FrmGetActiveForm();
        FrmDrawForm ( frmP);
        handled = true;
        break;

    default:
        break;
    }

    return handled;
}

/***********************************************************************
 ***********************************************************************/
Boolean HardKeyHandleEvent( EventPtr eventP)
{
    Boolean handled = false;
    char i = 0, dirs[] = {'j', 'k', 'h', 'l'};
    char current = !(FrmGetActiveFormID() == MainForm);
    
    if (prefs.use_hardkeys && eventP->eType == keyDownEvent && !(eventP->data.keyDown.modifiers & poweredOnKeyMask))
    {
        if(eventP->data.keyDown.modifiers & commandKeyMask)
        {
            switch (eventP->data.keyDown.chr)
            {       
            case hard3Chr:    i++;
            case hard2Chr:    i++; 
            case pageUpChr:   i++;
            case pageDownChr:
                if (!(current || paused || map_shown))
                    EvtEnqueueKey(dirs[i], 0, 0);
                handled = true;
                break;

            case hard1Chr:
                if (!rogue.gameOver && !paused && !map_shown) {
                    count = 10;
                    EvtEnqueueKey('s', 0, 0);
                }
                handled = true;
                break;

            case hard4Chr:
                if (!rogue.gameOver && !paused && !map_shown)
                    DoCommand(RogueCommand);
                handled = true;
                break;

            case calcChr:
                if (!(rogue.gameOver || paused || map_shown))
                {
                    statusPage++;
                    RogueStatus();
                }
                handled = true;
                break;

            case findChr:
                if (!(current || paused))
                    DrawMap(true);
                handled = true;
                break;

            default:
                break;
            }
        }
    }
    return handled;
}

static void SetStrToField(FormPtr frm, int theFieldID, char *theDrawStr)
{
    Handle myTextH;
    CharPtr myTextP;
    FieldPtr myFldPtr;
    ULong myStrSize = StrLen(theDrawStr)+1;

    myTextH = (Handle) MemHandleNew((ULong) myStrSize); 

    if (myTextH)
    {
        myTextP = (CharPtr)MemHandleLock(myTextH);
        MemMove(myTextP, theDrawStr, myStrSize); 
        myFldPtr = (FieldPtr)FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, theFieldID));
        FldFreeMemory(myFldPtr);
        FldSetTextHandle(myFldPtr, myTextH);
        FldEraseField(myFldPtr);
        FldDrawField(myFldPtr); 
        MemHandleUnlock(myTextH);
    } 
}

static int GetFldStr(FormPtr frm, Int FldID, CharPtr theStr)
{
    FieldPtr fld;
    CharPtr ptr;

    fld = (FieldPtr) GetObjectPtr (FldID);
    ptr = FldGetTextPtr (fld);

    if (ptr == NULL)
        MyClearStr(theStr);
    else
        StrCopy(theStr, ptr);
    return (*theStr != 0);
}

#define MESG_LINE 0
#define STUS_LINE 1
void ClearString(void)
{
    RectangleType r = {{0, 0}, {160, 11}};
    WinEraseRectangle(&r, 0);
}

void DrawString(char *s, Boolean flg)
{
    short  len; 
    RectangleType r = {0, 0, 160, 11};
//    RectangleType saveClip;

    len = StrLen(s);
    if (flg == STUS_LINE) {
        r.topLeft.y = 149;
        r.extent.x  = 150;
    }

    // Prevent drawing outside the bounds of the region passed.
//    WinGetClip (&saveClip);
//    WinClipRectangle (&r);
//    WinSetClip (&r);
    WinEraseRectangle(&r, 0);

    if (flg == MESG_LINE) {
        char buf[80];
        SWord t, l;

        while (1) {
            // �n����Ă��������񂪁A160pxl�ŕ\��������邩�`�F�b�N
            t = FntLineWidth(s, strlen(s));
            // �\���ł��Ȃ��ꍇ�́A���݂̍s��\���d�؂�镝�ŕ\��
            if (t >= 160)  {
                refresh();

                // �\���ł���ő吔���擾(MAX:34?)
                l = FntWordWrap(s, 160);
                
                // ���p��-2��������
                l -= 2;
                strcpy(buf, s);
                buf[l] = 0;
                s += l;
                // �������\��
                WinDrawChars(buf, strlen(buf), r.topLeft.x, r.topLeft.y);

#if 1
                // �������o���ăE�F�C�g
                wait_for_ack();

                // ���b�Z�[�W�\���̈���N���A
                ClearString();
#else
                r.topLeft.y += r.extent.y;
#endif
            }
            else {
                WinDrawChars(s, strlen(s), r.topLeft.x, r.topLeft.y);
                break;
            }
        }
    }
    else
        WinDrawChars(s, len, r.topLeft.x, r.topLeft.y);
//    WinSetClip (&saveClip);
}

static Word GetCommand(char c)
{
    int i;
    for (i = 0; i < (int)(sizeof(command_table)/sizeof(command_table[0])); i++)
        if (command_table[i].c == c)
            return command_table[i].cmd;
    return 0;
}

static void DrawBitmapChar(char c, SWord x, SWord y)
{
    int code;
    RectangleType r;
//    short fac_x, fac_y;
    short dx, dy;

    if (c == '|')
        c = '_';
    code = c - ' ';

//    fac_x = 0;
//    fac_y = 0; // FntCharHeight() - screen.charHeight;

    dx = x * screen.charWidth;
    dy = y * screen.charHeight + FntCharHeight();

    r.topLeft.x = (code % 16) * 6; // 8;
    r.topLeft.y = (code / 16) * 8;
    r.extent.x = screen.charWidth;
    r.extent.y = screen.charHeight;

    WinCopyRectangle(font, WinGetActiveWindow(),&r,dx, dy, scrCopy);
}

void SnapScreen(SWord row, SWord col)
{
    short i, j;
    SWord sRow = row - 7;
    SWord sCol = col - 12; // 9;

    for (j = 0; j < screen.height; j++) // Was 0 -- blank line
        for (i = 0; i < screen.width; i++) {
            SWord ypos = sRow + j;
            SWord xpos = sCol + i;

            if (ypos < 0 || xpos < 0 || ypos > DROWS-2 || xpos > DCOLS-1 ) {
                continue;
            }
            buffer[ypos][xpos] |= 0x80;
        }
    redraw_req = 1;
}

void DrawDungeon(void)
{
    short i, j;
    unsigned char c;
    RectangleType rec;

//    SnapScreen(rogue.row, rogue.col);

    WinDrawLine(0,54, 160,54);
    WinDrawLine(0,55+48, 160,55+48);

    rec.extent.x  = 2;
    rec.extent.y  = 2; // 4;

    for (i = 0; i < DROWS; i++) {
        rec.topLeft.y = 55 + 2 * i;

        for (j = 0; j < DCOLS; j++) {
            rec.topLeft.x = 2 * j;

            c = get_dungeon_char(i, j);
            switch (c) {
            case '#':
            case '|':
            case '-':
                if (terminal[i][j])
                    WinDrawRectangle(&rec, 0);
                break;
            case '%':
                if (terminal[i][j])
                    WinFillRectangle(&rec, 0);
                break;
            default:
                break;
            }
            if ((i == rogue.row) && (j == rogue.col))
                WinDrawRectangle(&rec, 0); 
        }
    }
}


static void scroll_col(int c_diff) // x���W
{
    RectangleType v;
    char flag = 0;
    DirectionType dir;
    int i, xpos = 0;
    int start,end;
    int sCol = rogue.col - 12;

    if (c_diff < 0)
        dir = right;
    else if (c_diff > 0)
    {
        dir = left;
        sCol += (screen.width - 1);
    }
    else
        return;


    WinScrollRectangle(&g, dir, 6, &v);
    WinEraseRectangle(&v, 0);


    if ((sCol < 0) || (sCol > DCOLS))
        return;

    start = rogue.row - 7;
    end   = start + screen.height;

    for (i = start; i <= end; i++) {
        if ( i < 0 || i > DROWS -1)
            continue;
        buffer[i][sCol] |= 0x80;
    }
}

static void scroll_row(int r_diff) // y���W
{
    RectangleType v;
    DirectionType dir;
    int i, ypos = 0;
    int start, end;
    int sRow = rogue.row - 7; // ����̍��W

    if (r_diff > 0)
    {
        dir = up;
        sRow = rogue.row + 9; 
    }
    else if (r_diff < 0)
        dir = down;
    else
        return;


    WinScrollRectangle(&g, (DirectionType)dir, 8, &v);
    WinEraseRectangle(&v, 0);

    if ((sRow < 0)||(sRow > DROWS -2))
        return;

    start = rogue.col - 12;
    end   = start + screen.width;

    for (i = start; i <= end; i++) {
        if ( i < 0 || i > DCOLS -1)
            continue;

        buffer[sRow][i] |= 0x80;
    }
}

static void ScrollScreen(SWord row, SWord col)
{
    static int old_row = -1, old_col = -1;

    if (is_first)
    {
        ClearGadget();
        old_row = -1;
        old_col = -1;
        is_first = 0;
    }

    if (old_row != -1 && old_col != -1)
    {
        scroll_col(col - old_col);
        scroll_row(row - old_row);
    }

    old_row = row;
    old_col = col;
}

void DrawScreen(SWord row, SWord col)
{
    short i, j;
    char c;
    SWord sRow = row - 7; 
    SWord sCol = col - 12; 
    RectangleType saveClip, clip = {0, 11, 160, 138};

    if (redraw_req)
    {
        ClearGadget();
        redraw_req = 0;
        if (!map_shown)
            RogueStatus();
    }
    ScrollScreen(row, col);

    // Prevent drawing outside the bounds of the region passed.
    WinGetClip (&saveClip);
    WinClipRectangle (&clip);
    WinSetClip (&clip);

    for (j = 0; j < screen.height; j++)
        for (i = 0; i < screen.width; i++) {
            SWord ypos = sRow + j;
            SWord xpos = sCol + i;

            if (ypos < 0 || xpos < 0 || ypos > DROWS-2 || xpos > DCOLS-1 ) {
                continue;
            }

            if (ypos == rogue.row && xpos == rogue.col) {
                rogue.x = i;
                rogue.y = j;
            }

           if (!map_shown)
                if (!(buffer[ypos][xpos] & 0x80))
                    continue;

            if (!map_shown)
            {
                buffer[ypos][xpos] &= 0x7f;
                c = buffer[ypos][xpos];
            }
            else
                c = buffer[ypos][xpos] & 0x7f;
            DrawBitmapChar(c, i, j);
        }

    WinSetClip (&saveClip);

#if 1
    {
        RectangleType v;
        RctSetRectangle(&v, 157, 11, 3, 136);
        WinEraseRectangle(&v, 0);

        RctSetRectangle(&v, 0, 147, 160, 2); // 4);
        WinEraseRectangle(&v, 0);
    }
#endif
}

void RogueStatus(void)
{
#if 0
    char buf[40]; // XXX_BUG
#else
    char buf[80]; // XXX_BUG
#endif

    switch (statusPage % 2)
    {
    case 0: // STAT_LEVEL, STAT_GOLD, STAT_HP, STAT_HUNGER
        if (rogue.gold > MAX_GOLD) {
            rogue.gold = MAX_GOLD;
        }
        if (rogue.hp_max > MAX_HP) {
            rogue.hp_current -= (rogue.hp_max - MAX_HP);
            rogue.hp_max = MAX_HP;
        }

        sprintf(buf,
                MESG_604,
                game.cur_level,
                rogue.gold,
                rogue.hp_current, rogue.hp_max, hunger_str);
        break;

    case 1: // STAT_STRENGTH, STAT_ARMOR, STAT_EXP
        if (rogue.str_max > MAX_STRENGTH) {
            rogue.str_current -= (rogue.str_max - MAX_STRENGTH);
            rogue.str_max = MAX_STRENGTH;
        }
        if (rogue.armor && (rogue.armor->d_enchant > MAX_ARMOR)) {
            rogue.armor->d_enchant = MAX_ARMOR;
        }

        sprintf(buf,
                MESG_605,
                (rogue.str_current + add_strength), rogue.str_max,
                get_armor_class(rogue.armor),
                rogue.exp, rogue.exp_points);

        break;

    default:
        break;
    }
    DrawString(buf, 1);
}

void DrawBitmap(int x, int y, int resID)
{
    Handle resH;
    BitmapPtr resP;

    resH = (Handle)DmGetResource(bitmapRsc, resID);
    ErrFatalDisplayIf( !resH, "Missing bitmap" );
    resP = (BitmapPtr)MemHandleLock(resH);
    WinDrawBitmap(resP, x, y);
    MemPtrUnlock(resP);
    DmReleaseResource(resH);
}


int get_input_line(char *buf, char *old)
{
    FormPtr oldform, frm;
    char ret = 0, f;
    FieldPtr fld;

    frm = FrmInitForm(NameForm);

    oldform = FrmGetActiveForm ();
    if (oldform)
        FrmSetActiveForm(frm);

    SetStrToField(frm, NameCallitField, old);
    fld = (FieldPtr)FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, NameCallitField));
    FrmSetFocus(frm, FrmGetObjectIndex (frm, NameCallitField));
    f = FrmDoDialog(frm);
    
    if (f) {
        if (GetFldStr(frm, NameCallitField, buf))
            ret = 1;
    }
    FrmDeleteForm(frm);
    if (oldform)
        FrmSetActiveForm(oldform);

    SnapScreen(rogue.row, rogue.col);

    return ret;
}

void wait_for_ack(void)
{
    RectangleType r;
    EventType e;
    FontID old;
    int sel = -1;

    old = FntGetFont();
    FntSetFont(symbol7Font);
    r.topLeft.x = 150;
    r.topLeft.y = 0;
    r.extent.x  = FntCharWidth('\002');
    r.extent.y  = FntCharHeight(); 
    WinDrawChars("\002", 1, r.topLeft.x, r.topLeft.y);
    FntSetFont(old);

    EvtFlushPenQueue();
    EvtFlushKeyQueue();

    EvtGetEvent (&e, evtWaitForever);
    if (e.eType == penDownEvent) {
        Boolean penDown;
        short x, y;
        do {
            EvtGetPen(&x, &y,&penDown);
        } while (penDown);
    }
    else 
    if (e.eType == keyDownEvent) {
        switch (e.data.keyDown.chr) {
        case pageDownChr:
        case pageUpChr:
        case hard1Chr:
        case hard2Chr:
        case hard3Chr:
        case hard4Chr:
        case calcChr:
        case findChr:
        case menuChr:
            break;
        default:
            if (SysHandleEvent (&e)) {
                interrupted = 1;
//              doRogueAction = true; XXX
            }
            break;
        }
    }
    WinEraseRectangle(&r, 0);
}

#define C1 2
#define C2 25
#define C3 55
#define C4 70

static char *format_str(int num, int cnt)
{
    int pos, len, i;
    static char fm[10];

    memset(fm, 0, sizeof(fm));
    pos = len = cnt;

    for( i = 0; i < cnt; i++ ){
        fm[--pos] = (num % 10) + 48;
        num /= 10;
    }
    fm[len] = 0;

    return fm;
}

static void put_ranking_sub(int by, char rank, ScoreType *sc)
{
    char buf[10], *desc;
    int level, score, height = FntCharHeight();
    
    if (!sc->level)
        return;

    level = sc->level;
    score = sc->score;
    desc  = sc->desc;

    by += rank * height + 1;
    rank++;

    if (sc->current == 1) {
        RectangleType r = {0, 0, 160, 0};
        r.topLeft.y = by;
        r.extent.y  = height;

        WinInvertRectangle(&r, 0);

        sprintf(buf, rank < 10 ? "0%d" : "%d", rank);
        WinDrawInvertedChars(buf, strlen(buf), C1 + 5, by);

        sprintf(buf, format_str(score, 5));
        WinDrawInvertedChars(buf, strlen(buf), C2, by);

        sprintf(buf, level < 10 ? "0%d" : "%d", level);
        WinDrawInvertedChars(buf, strlen(buf), C3, by);

        WinDrawInvertedChars(desc, strlen(desc), C4, by);

        DmSet(sc, 0, 1, 0); //         sc->current = 0;
    }
    else {
        sprintf(buf, rank < 10 ? "0%d" : "%d", rank);
        WinDrawChars(buf, strlen(buf), C1 + 5, by);

        sprintf(buf, format_str(score, 5));
        WinDrawChars(buf, strlen(buf), C2, by);

        sprintf(buf, level < 10 ? "0%d" : "%d", level);
        WinDrawChars(buf, strlen(buf), C3, by);

        WinDrawChars(desc, strlen(desc), C4, by);
    }
}

// ������y���W�̃x�[�X���W
static void put_ranking(int by)
{
    int i;
    DmOpenRef ref;
    VoidHand handle;
    ScoreType *sc;

    ref = DmOpenDatabaseByTypeCreator(SCO_TYPE, ROGUE, dmModeReadOnly);

    for (i = 0; i < 10; i++)
    {
        handle = DmGetRecord(ref, i);
        ErrFatalDisplayIf(!handle, "Error Get record");
        sc = (ScoreType*)MemHandleLock(handle);
        put_ranking_sub(by, i, sc);
        MemHandleUnlock(handle);
        DmReleaseRecord(ref, i, false);
    }

    DmCloseDatabase(ref);
}

static void ScoreFormInit(void)
{
    RectangleType r = {0, 0, 160, 0};
    int h = FntCharHeight();
    char *head = "PocketRogue Top Ranking";

    // �w�b�_��`��
    r.extent.y = h;

    WinInvertRectangle(&r, 0);
    WinDrawInvertedChars(head, strlen(head), 2, 0);

    h += 3;
    WinDrawLine(0, h, 160, h);

    h += 2;
    WinDrawChars("Rank",  4, C1, h);
    WinDrawChars("Score", 5, C2, h);
    WinDrawChars("Lvl",   3, C3, h);
    WinDrawChars("Desc",  4, C4, h);

    h = h * 2 - 3;
    WinDrawLine(0, h, 160, h);

    put_ranking(h+1);
    WinDrawLine(0, 144, 160, 144);
}

Boolean ScoreFormHandleEvent(EventPtr e)
{
    Boolean handled = false;

    switch (e->eType) {
    case frmOpenEvent:
        FrmDrawForm(FrmGetActiveForm());
        ScoreFormInit();
        handled = true;
        break;

    case ctlSelectEvent:
        if (e->data.ctlSelect.controlID == ScoreOkButton) {
            if (rogue.gameOver) // from RipForm
                FrmGotoForm(MainForm);
            else
                FrmReturnToForm(0);
        }
        handled = true;
        break;

    default:
        break;
    }

    return handled;
}

static void  RipFormInit(void)
{
    FieldPtr fld;
    char *p;

    h = MemHandleNew(80);
    p = MemHandleLock(h);
    StrCopy(p, current_score);
    MemHandleUnlock(h);

    fld = GetObjectPtr(RipKilledByField);
    FldEraseField(fld);

    FldSetTextHandle(fld, (Handle)h);
    FldDrawField(fld);
}

static void RipFormClose(void)
{
    FieldPtr fld;

    fld = GetObjectPtr(RipKilledByField);
    FldSetTextHandle(fld, NULL);

    if (h != NULL)
        MemHandleFree(h);
    h = 0;
}

Boolean RipFormHandleEvent(EventPtr e)
{
    Boolean handled = false;

    switch (e->eType) {
    case frmOpenEvent:
        FrmDrawForm(FrmGetActiveForm());
        RipFormInit();
        handled = true;
        break;

    case ctlSelectEvent:
        if (e->data.ctlSelect.controlID == RipNextButton) {
            FrmGotoForm(ScoreForm);
            RipFormClose();
        }
        else if (e->data.ctlSelect.controlID == RipExportButton) {
            if (!FrmAlert(ExportAlert))
                ExportScore(current_score);
        }
        handled = true;
        break;

    default:
        break;
    }

    return handled;
}

static void OptionsInit(void)
{
    ControlPtr ctl;

    ctl = GetObjectPtr (OptionsHardKeysCheckbox);
    CtlSetValue (ctl, prefs.use_hardkeys);

    ctl = GetObjectPtr (OptionsDontRemoveCheckbox);
    CtlSetValue (ctl, prefs.dont_remove);
}

static void OptionsApply(void)
{
    prefs.use_hardkeys = CtlGetValue (GetObjectPtr (OptionsHardKeysCheckbox));
    prefs.dont_remove  = CtlGetValue (GetObjectPtr (OptionsDontRemoveCheckbox));
}

Boolean OptionFormHandleEvent(EventPtr e)
{
    Boolean handled = false;

    switch (e->eType) {
    case frmOpenEvent:
        FrmDrawForm(FrmGetActiveForm());
        OptionsInit();
        handled = true;
        break;

    case ctlSelectEvent:
        switch (e->data.ctlSelect.controlID)
        {
        case OptionsOkButton:
            OptionsApply();
            FrmReturnToForm(0);
            handled = true;
            break;
        case OptionsCancelButton:
            FrmReturnToForm(0);
            handled = true;
            break;
        }
        break;

    default:
        break;
    }

    return handled;
}
