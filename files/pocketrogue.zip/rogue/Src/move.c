/*
 * move.c
 *
 * This source herein may be modified and/or distributed by anybody who
 * so desires, with the following restrictions:
 *    1.)  No portion of this notice shall be removed.
 *    2.)  Credit shall not be taken for the creation of this source.
 *    3.)  This code is not to be traded, sold, or used for personal
 *         gain or profit.
 *
 */

#include "rogue.h"

char *you_can_move_again = MESG_066;

short m_moves = 0;
boolean jump = 0;
boolean bent_passage = 0;

static int next_to_something(int drow, int dcol);
static boolean check_hunger(boolean messages_only);
static int gr_dir();
static void heal();

extern short cur_room, halluc, blind, levitate;
extern short cur_level, max_level;
extern short bear_trap, haste_self, confused;
extern short e_rings, regeneration, auto_search;
extern char hunger_str[];
extern boolean being_held, interrupted, r_teleport;
extern boolean pass_go;


one_move_rogue(short dirch, short pickup)
{
    register short row, col;
    short r, c;
    char *p;
    object *obj;

    char desc[DCOLS];
    short status;

    r = rogue.row;
    c = rogue.col;
    bent_passage = 0;

    if (game.confused) {
        dirch = gr_dir();
    }
    get_dir_rc(dirch, &r, &c, 1);
    row = r;
    col = c;

    if (!can_move(rogue.row, rogue.col, row, col)) {
        if (game.cur_room == PASSAGE && !game.blind && !game.confused && !strchr("yubn", dirch))
            bent_passage = 1;
        return(MOVE_FAILED);
    }
    if (game.being_held || game.bear_trap) {
        if (!(dungeon[row][col] & MONSTER)) {
            if (game.being_held) {
                message(MESG_067, 1);
            } else {
                message(MESG_068, 0);
                (void) reg_move();
            }
            return(MOVE_FAILED);
        }
    }

    if (r_teleport) {
        if (rand_percent(R_TELE_PERCENT)) {
            tele();
            return(STOPPED_ON_SOMETHING);
        }
    }

    if (dungeon[row][col] & MONSTER) {
        rogue_hit(object_at(&level_monsters, row, col), 0);
        (void) reg_move();
        return(MOVE_FAILED);
    }
    if (dungeon[row][col] & DOOR) {
        if (game.cur_room == PASSAGE) {
            game.cur_room = get_room_number(row, col);
            light_up_room(game.cur_room);
            wake_room(game.cur_room, 1, row, col);
        } else {
            light_passage(row, col);
        }
    } else if ((dungeon[rogue.row][rogue.col] & DOOR) &&
               (dungeon[row][col] & TUNNEL)) {
        light_passage(row, col);
        wake_room(game.cur_room, 0, rogue.row, rogue.col);
        darken_room(game.cur_room);
        game.cur_room = PASSAGE;
    } else if (dungeon[row][col] & TUNNEL) {
        light_passage(row, col);
    }
    mvaddch(rogue.row, rogue.col, get_dungeon_char(rogue.row, rogue.col));
    mvaddch(row, col, rogue.fchar);

#if 0
    if (!jump) {
		refresh();
	}
#endif
    rogue.row = row;
    rogue.col = col;
    if (dungeon[row][col] & OBJECT) {
        if (game.levitate && pickup) {
            return(STOPPED_ON_SOMETHING);
        }
        if (pickup && !game.levitate) {
            obj = pick_up(row, col, &status);
            if (obj) {
                get_desc(obj, desc, 1);

                if (obj->what_is == GOLD) {
                    free_object(obj);
#ifdef JP
                    strcat(desc, MESG_069);
#endif
                    goto NOT_IN_PACK;
                }
            } else if (!status) {
                goto MVED;
            } else {
                goto MOVE_ON;
            }
        } else {
        MOVE_ON:
            obj = object_at(&level_objects, row, col);
#ifndef JP
            (void) strcpy(desc, MESG_070);
            get_desc(obj, desc+strlen(MESG_070), 0);
#else
            get_desc(obj, desc, 0);
            (void) strcat(desc, MESG_070);
#endif
            goto NOT_IN_PACK;
        }

#ifdef JP
        strcat(desc, MESG_069);
#endif
        p = desc + strlen(desc);
        *p++ = '(';
        *p++ = obj->ichar;
        *p++ = ')';
        *p = 0;

    NOT_IN_PACK:
        message(desc, 1);
        (void) reg_move();
        return(STOPPED_ON_SOMETHING);
    }
    if (dungeon[row][col] & (DOOR | STAIRS | TRAP)) {
        if ((!game.levitate) && (dungeon[row][col] & TRAP)) {
            trap_player(row, col);
        }
        (void) reg_move();
        return(STOPPED_ON_SOMETHING);
    }
MVED:
    if (reg_move()) {           /* fainted from hunger */
        return(STOPPED_ON_SOMETHING);
    }
    return((game.confused ? STOPPED_ON_SOMETHING : MOVED));
}

void multiple_move_rogue(dirch)
{
    short row, col;
    short m;
    short n, i, ch;
    char *dir;

    switch(dirch) {
    case '\010':
    case '\012':
    case '\013':
    case '\014':
    case '\031':
    case '\025':
    case '\016':
    case '\002':
        dirch += 96;
        do {
        retry:
            row = rogue.row;
            col = rogue.col;
            m = one_move_rogue(dirch, 1);
            if (m == STOPPED_ON_SOMETHING || interrupted)
                break;
            if (m != MOVE_FAILED)
                continue;
            if (!pass_go || !bent_passage)
                break;
            for (n = 0, dir = "hjkl", i = 0; i < 4; i++) {
                row = rogue.row;
                col = rogue.col;
                get_dir_rc(dir[i], &row, &col, 1);
                if (is_passable(row,col) && dirch!=dir[3-i])
                    n++, ch = dir[i];
            }
            if (n == 1) {
                dirch = ch;
                goto retry;
            }
            break;
        } while (!next_to_something(row, col));
        break;
    case 'H':
    case 'J':
    case 'K':
    case 'L':
    case 'B':
    case 'Y':
    case 'U':
    case 'N':
        dirch += 32;
        for (;;) {
        retry2:
            m = one_move_rogue(dirch, 1);
            if (interrupted)
                break;
            if (m == MOVED)
                continue;
            if (m != MOVE_FAILED || !pass_go || !bent_passage)
                break;
            for (n = 0, dir = "hjkl", i = 0; i < 4; i++) {
                row = rogue.row;
                col = rogue.col;
                get_dir_rc(dir[i], &row, &col, 1);
                if (is_passable(row,col) && dirch!=dir[3-i])
                    n++, ch = dir[i];
            }
            if (n == 1) {
                dirch = ch;
                goto retry2;
            }
            break;
        }
        break;
    }
}
        

is_passable(register int row, register int col)
{
    if ((row < MIN_ROW) || (row > (DROWS - 2)) || (col < 0) ||
        (col > (DCOLS-1))) {
        return(0);
    }
    if (dungeon[row][col] & HIDDEN) {
        return((dungeon[row][col] & TRAP) ? 1 : 0);
    }
    return(int)(dungeon[row][col] & (FLOOR|TUNNEL|DOOR|STAIRS|TRAP));
}
        
static int next_to_something(register int drow, register int dcol)
{
    short i, j, i_end, j_end, row, col;
    short pass_count = 0;
    unsigned short s;

    if (game.confused) {
        return(1);
    }
    if (game.blind) {
        return(0);
    }
    i_end = (rogue.row < (DROWS-2)) ? 1 : 0;
    j_end = (rogue.col < (DCOLS-1)) ? 1 : 0;

    for (i = ((rogue.row > MIN_ROW) ? -1 : 0); i <= i_end; i++) {
        for (j = ((rogue.col > 0) ? -1 : 0); j <= j_end; j++) {
            if (i == 0 && j == 0 ||
                rogue.row+i == drow && rogue.col+j == dcol)
            {
                continue;
            }
            row = rogue.row + i;
            col = rogue.col + j;
            s = dungeon[row][col];
            if (s & HIDDEN) {
                continue;
            }
            /* If the rogue used to be right, up, left, down,
                 * or right of row, col, and now isn't,
                 * then don't stop */
            if (s & (MONSTER | OBJECT | STAIRS)) {
                if ((row == drow || col == dcol) &&
                    (!(row==rogue.row || col==rogue.col)))
                {
                    continue;
                }
                return(1);
            }
            if (s & TRAP) {
                if (!(s & HIDDEN)) {

                    if ((row == drow || col == dcol) &&
                        (!(row == rogue.row ||
                           col == rogue.col)))
                    {
                        continue;
                    }
                    return(1);
                }
            }
            if (((i - j == 1) || (i - j == -1)) && (s & TUNNEL))
            {
                if (++pass_count > 1) {
                    return(1);
                }
            }
            if ((s & DOOR) && ((i == 0) || (j == 0))) {
                return(1);
            }
        }
    }
    return(0);
}
        
can_move(row1, col1, row2, col2) 
{
    if (!is_passable(row2, col2)) {
        return(0);
    }

    if ((row1 != row2) && (col1 != col2)) {
        if ((dungeon[row1][col1]&DOOR) || (dungeon[row2][col2]&DOOR)
            || (!dungeon[row1][col2]) || (!dungeon[row2][col1])) 
        {
            return(0);
        }
    }
    return(1);
}

void move_onto(short ch)

{
    if (ch != CANCEL) {
        (void) one_move_rogue(ch, 0);
    }
}
        
static boolean check_hunger(boolean messages_only)
{
    register short i, n;
    boolean fainted = 0;
    static short move_left_cou = 0;     /* Yasha */

    if (rogue.moves_left == HUNGRY) {
        (void) strcpy(hunger_str, MESG_071);
        message(MESG_072, 0);
        print_stats(STAT_HUNGER);
    }

    if (rogue.moves_left == WEAK) {
        (void) strcpy(hunger_str, MESG_073);
        message(MESG_074, 1);
        print_stats(STAT_HUNGER);
    }

    if (rogue.moves_left <= FAINT) {
        if (rogue.moves_left == FAINT) {
            (void) strcpy(hunger_str, MESG_075);
            message(MESG_076, 1);
            print_stats(STAT_HUNGER);
        }

        n = get_rand(0, (FAINT - rogue.moves_left));
        if (n > 0) {
            fainted = 1;
            if (rand_percent(40)) {
                rogue.moves_left++;
            }
            message(MESG_077, 1);
            for (i = 0; i < n; i++) {
                if (coin_toss()) {
                    mv_mons();
                }
            }
            message(you_can_move_again, 1);
        }
    }
    if (messages_only) {
        return(fainted);
    }
    if (rogue.moves_left <= STARVE) {
        killed_by((object *) 0, STARVATION);
    }

    switch(e_rings) {
        /*case -2:
                Subtract 0, i.e. do nothing.
                break;*/
    case -1:
        rogue.moves_left -= move_left_cou;  /* by Yasha */
        break;
    case 0:
        rogue.moves_left--;
        break;
    case 1:
        rogue.moves_left--;
        (void) check_hunger(1);
        rogue.moves_left -= move_left_cou;  /* by Yasha */
        break;
    case 2:
        rogue.moves_left--;
        (void) check_hunger(1);
        rogue.moves_left--;
        break;
    }
    move_left_cou ^= 1;     /* by Yasha */
    return(fainted);
}
        
boolean reg_move()
{
    boolean fainted;
        
    if ((rogue.moves_left <= HUNGRY) || (game.cur_level >= game.max_level)) {
        fainted = check_hunger(0);
    } else {
        fainted = 0;
    }
    mv_mons();

    if (++game.m_moves >= 120) {
        game.m_moves = 0;
        wanderer();
    }

    if (game.halluc) {
        if (!(--game.halluc)) {
            unhallucinate();
        } else {
            hallucinate();
        }
    }

    if (game.blind) {
        if (!(--game.blind)) {
            unblind();
        }
    }

    if (game.confused) {
        if (!(--game.confused)) {
            unconfuse();
        }
    }

    if (game.bear_trap) {
        game.bear_trap--;
    }

    if (game.levitate) {
        if (!(--game.levitate)) {
            message(MESG_078, 1);
            if (dungeon[rogue.row][rogue.col] & TRAP) {
                trap_player(rogue.row, rogue.col);
            }
        }
    }
    if (game.haste_self) {
        if (!(--game.haste_self)) {
            message(MESG_079, 0);
        }
    }
    heal();
    if (auto_search > 0) {
        search(auto_search, auto_search);
    }
    return(fainted);
}
        
void rest(count)
{
    int i;

    interrupted = 0;

    for (i = 0; i < count; i++) {
        if (interrupted) {
            break;
        }
        (void) reg_move();
    }
}
        
static int gr_dir()
{
    return (*("jklhyubn" + get_rand(1, 8) - 1));
}

static void heal()
{
    static short heal_exp = -1, n, c = 0;
    static boolean alt;
    static char na[] = { 0, 20, 18, 17, 14, 13, 10, 9, 8, 7, 4, 3 };

    if (rogue.hp_current == rogue.hp_max) {
        c = 0;
        return;
    }
    if (rogue.exp != heal_exp) {
        heal_exp = rogue.exp;
        n = (heal_exp < 1 || heal_exp > 11)? 2: na[heal_exp];
    }
    if (++c >= n) {
        c = 0;
        rogue.hp_current++;

        alt = !alt;
        if (alt) {
            rogue.hp_current++;
        }
        if ((rogue.hp_current += regeneration) > rogue.hp_max) {
            rogue.hp_current = rogue.hp_max;
        }
        print_stats(STAT_HP);
    }
}
