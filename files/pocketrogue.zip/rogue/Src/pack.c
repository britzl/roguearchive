/*
 * pack.c
 *
 * This source herein may be modified and/or distributed by anybody who
 * so desires, with the following restrictions:
 *    1.)  No portion of this notice shall be removed.
 *    2.)  Credit shall not be taken for the creation of this source.
 *    3.)  This code is not to be traded, sold, or used for personal
 *         gain or profit.
 *
 */

#include "rogue.h"
        
static object *check_duplicate(object *obj, object *pack);
static int next_avail_ichar();
static boolean mask_pack(object *pack, unsigned short mask);

char *curse_message = MESG_085;

object *add_to_pack(object *obj, object *pack, int condense)
{
    object *op, *p;

    if (condense) {
        op = check_duplicate(obj, pack);
        if (op) {
            free_object(obj);
            return(op);
        } else {
            obj->ichar = next_avail_ichar();
        }
    }

    for (op = pack; op->next_object; op = op->next_object) {
        if (op->next_object->what_is > obj->what_is) {
            p = op->next_object;
            op->next_object = obj;
            obj->next_object = p;
            return obj;
        }
    }
    op->next_object = obj;
    obj->next_object = 0;
    return obj;

}
        
void take_from_pack(object *obj, object *pack)
{
    while (pack->next_object != obj) {
        pack = pack->next_object;
    }
    pack->next_object = pack->next_object->next_object;
}
        
object *pick_up(int row, int col, short *status)
{
    object *obj;

    obj = object_at(&level_objects, row, col);
    *status = 1;

    if ((obj->what_is == SCROLL) && (obj->which_kind == SCARE_MONSTER) && obj->picked_up)
    {
        message(MESG_086, 0);
        dungeon[row][col] &= (~OBJECT);
        vanish(obj, 0, &level_objects);
        *status = 0;
        if (id_scrolls[SCARE_MONSTER].id_status == UNIDENTIFIED) {
            id_scrolls[SCARE_MONSTER].id_status = IDENTIFIED;
            rw_id_table(TMP_TYPE, ID_SCROLLS, SCARE_MONSTER, 1);
        }
        return(0);
    }
    if (obj->what_is == GOLD) {
        rogue.gold += obj->quantity;
        dungeon[row][col] &= ~(OBJECT);
        take_from_pack(obj, &level_objects);
        print_stats(STAT_GOLD);
        return(obj);    /* obj will be free_object()ed in one_move_rogue() */
    }
    if (pack_count(obj) >= MAX_PACK_COUNT) {
        message(MESG_087, 1);
        return(0);
    }
    dungeon[row][col] &= ~(OBJECT);

    take_from_pack(obj, &level_objects);
    obj = add_to_pack(obj, &rogue.pack, 1);
    obj->picked_up = 1;
    return(obj);
}
        
void drop(void)
{
    object *obj, *new;
    short ch;
    char desc[DCOLS];

    if (dungeon[rogue.row][rogue.col] & (OBJECT | STAIRS | TRAP)) {
        message(MESG_088, 0);
        return;
    }
    if (!rogue.pack.next_object) {
        message(MESG_089, 0);
        return;
    }

    if ((ch = pack_letter(MESG_090, ALL_OBJECTS)) == CANCEL)
    {
        return;
    }
    if (!(obj = get_letter_object(ch))) {
        message(MESG_091, 0);
        return;
    }
    if (obj->in_use_flags & BEING_WIELDED) {
        if (obj->is_cursed) {
            message(curse_message, 0);
            return;
        }
        unwield(rogue.weapon);
    } else if (obj->in_use_flags & BEING_WORN) {
        if (obj->is_cursed) {
            message(curse_message, 0);
            return;
        }
        mv_aquatars();
        unwear(rogue.armor);
        print_stats(STAT_ARMOR);
    } else if (obj->in_use_flags & ON_EITHER_HAND) {
        if (obj->is_cursed) {
            message(curse_message, 0);
            return;
        }
        un_put_on(obj);
    }

    obj->row = rogue.row;
    obj->col = rogue.col;


    if ((obj->quantity > 1) && (obj->what_is != WEAPON)) {
        obj->quantity--;

        new = alloc_object();

        bcopy(obj, new, sizeof(object));
        new->quantity = 1;

        obj = new;
    } else {
        obj->ichar = 'L';
        take_from_pack(obj, &rogue.pack);
    }

    place_at(obj, rogue.row, rogue.col);

#ifndef JP
    (void) strcpy(desc, MESG_092);
    get_desc(obj, desc+strlen(MESG_092), 0);
#else
    get_desc(obj, desc, 0);
    (void) strcat(desc, MESG_092);
#endif

    message(desc, 0);
    (void) reg_move();
}
        
static object *check_duplicate(object *obj, object *pack)
{
    object *op;

    if (!(obj->what_is & (WEAPON | FOOD | SCROLL | POTION)))
    {
        return(0);
    }

    if ((obj->what_is == FOOD) && (obj->which_kind == FRUIT)) {
        return(0);
    }

    op = pack->next_object;

    while (op) {
        if ((op->what_is == obj->what_is) && (op->which_kind == obj->which_kind)) {

            if ((obj->what_is != WEAPON) ||
                ((obj->what_is == WEAPON) &&
                 ((obj->which_kind == ARROW) ||
                  (obj->which_kind == DAGGER) ||
                  (obj->which_kind == DART) ||
                  (obj->which_kind == SHURIKEN)) &&
                 (obj->quiver == op->quiver))) {
                op->quantity += obj->quantity;
                return(op);
            }
        }
        op = op->next_object;
    }
    return(0);
}
        
static int next_avail_ichar()
{
    register object *obj;
    register i;
    boolean ichars[26];

    for (i = 0; i < 26; i++) {
        ichars[i] = 0;
    }
    obj = rogue.pack.next_object;
    while (obj) {
        ichars[(obj->ichar - 'a')] = 1;
        obj = obj->next_object;
    }

    for (i = 0; i < 26; i++) {
        if (!ichars[i]) {
            return(i + 'a');
        }
    }
    return('?');
}
        

pack_letter(char *prompt, unsigned short mask)
{
    short ch;
    if (!mask_pack(&rogue.pack, mask)) {
        message(MESG_093, 0);
        return(CANCEL);
    }

    message(prompt, 0);

    ch = PopupList(mask, 0);
    check_message();
    return(ch);
}
        
void take_off()
{
    char desc[DCOLS];
    object *obj;

    if (rogue.armor) {
        if (rogue.armor->is_cursed) {
            message(curse_message, 0);
        } else {
            mv_aquatars();
            obj = rogue.armor;
            unwear(rogue.armor);
#ifndef JP
            (void) strcpy(desc, MESG_094);
            get_desc(obj, desc+strlen(MESG_094), 0);
#else
            get_desc(obj, desc, 0);
            (void) strcat(desc, MESG_094);
#endif
            message(desc, 0);
            print_stats(STAT_ARMOR);
            (void) reg_move();
        }
    } else {
        message(MESG_095, 0);
    }
}
        
void wear(void)
{
    short ch;
    register object *obj;
    char desc[DCOLS];

    if (rogue.armor) {
        message(MESG_096, 0);
        return;
    }
    ch = pack_letter(MESG_097, ARMOR);

    if (ch == CANCEL) {
        return;
    }
    if (!(obj = get_letter_object(ch))) {
        message(MESG_098, 0);
        return;
    }

    if (obj->what_is != ARMOR) {
        message(MESG_099, 0);
        return;
    }

    obj->identified = 1;
#ifndef JP
    (void) strcpy(desc, MESG_100);
    get_desc(obj, desc + strlen(MESG_100), 0);
#else
    get_desc(obj, desc, 0);
    (void) strcat(desc, MESG_100);
#endif
    message(desc, 0);

    do_wear(obj);
    print_stats(STAT_ARMOR);
    (void) reg_move();
}
        
void unwear(object *obj)
{
    if (obj) {
        obj->in_use_flags &= (~BEING_WORN);
    }
    rogue.armor = (object *) 0;
}
        
void do_wear(object *obj)
{
    rogue.armor = obj;
    obj->in_use_flags |= BEING_WORN;
    obj->identified = 1;
}
        
void wield(void)
{
    short ch;
    register object *obj;
    char desc[DCOLS];

    if (rogue.weapon && rogue.weapon->is_cursed) {
        message(curse_message, 0);
        return;
    }
    ch = pack_letter(MESG_101, WEAPON);

    if (ch == CANCEL) {
        return;
    }
    if (!(obj = get_letter_object(ch))) {
        message(MESG_102, 0);
        return;
    }
    if (obj->what_is & (ARMOR | RING)) {
        sprintf(desc, MESG_103, ((obj->what_is == ARMOR) ? MESG_104 : MESG_105));
        message(desc, 0);
        return;
    }
    if (obj->in_use_flags & BEING_WIELDED) {
        message(MESG_106, 0);
    } else {
        unwield(rogue.weapon);
#ifndef JP
        (void) strcpy(desc, MESG_107);
        get_desc(obj, desc + strlen(MESG_107), 0);
#else
        get_desc(obj, desc, 0);
        (void) strcat(desc, MESG_107);
#endif
        message(desc, 0);
        do_wield(obj);
        (void) reg_move();
    }
}
        
void do_wield(object *obj)
{
    rogue.weapon = obj;
    obj->in_use_flags |= BEING_WIELDED;
}
        
void unwield(object *obj)
{
    if (obj) {
        obj->in_use_flags &= (~BEING_WIELDED);
    }
    rogue.weapon = (object *) 0;
}
        
void call_it(void)
{
    short ch;
    register object *obj;
    struct id *id_table;
    char buf[MAX_TITLE_LENGTH+2];
     int type;

    ch = pack_letter(MESG_108, (SCROLL | POTION | WAND | RING));
    if (ch == CANCEL) {
        return;
    }
    if (!(obj = get_letter_object(ch))) {
        message(MESG_109, 0);
        return;
    }


    if (!(obj->what_is & (SCROLL | POTION | WAND | RING))) 
    {
        message(MESG_110, 0);
        return;
    }

    id_table = get_id_table(obj, &type);

    if (get_input_line(buf, id_table[obj->which_kind].title)) {
        id_table[obj->which_kind].id_status = CALLED;
        (void) strcpy(id_table[obj->which_kind].title, buf);
        if (type != -1)
            rw_id_table(TMP_TYPE, type, obj->which_kind, 1); // TOTA
    }
}
        
int pack_count(object *new_obj)
{
    object *obj;
    short count = 0;

    obj = rogue.pack.next_object;

    while (obj) {
        if (obj->what_is != WEAPON) {
            count += obj->quantity;
        } else if (!new_obj) {
            count++;
        } else if ((new_obj->what_is != WEAPON) ||
                   ((obj->which_kind != ARROW) &&
                    (obj->which_kind != DAGGER) &&
                    (obj->which_kind != DART) &&
                    (obj->which_kind != SHURIKEN)) ||
                   (new_obj->which_kind != obj->which_kind) ||
                   (obj->quiver != new_obj->quiver)) {
            count++;
        }
        obj = obj->next_object;
    }
    return(count);
}
        
static boolean mask_pack(object *pack, unsigned short mask)
{
    while (pack->next_object) {
        pack = pack->next_object;
        if (pack->what_is & mask) {
            return(1);
        }
    }
    return(0);
}

has_amulet()
{
     return(mask_pack(&rogue.pack, AMULET));
}
        
void kick_into_pack()
{
    object *obj;
    char *p;
    char desc[DCOLS];
    short stat;

    if (!(dungeon[rogue.row][rogue.col] & OBJECT)) {
        message(MESG_112, 0);
    } else {

        if (game.levitate) {
            message(MESG_113, 0);
            return;
        }
        obj = pick_up(rogue.row, rogue.col, &stat);
        if (obj) {
            get_desc(obj, desc, 1);
#ifdef JP
            (void) strcat(desc, MESG_114);
#endif
            if (obj->what_is == GOLD) {
                message(desc, 0);
                free_object(obj);
            } else {
                p = desc + strlen(desc);
                *p++ = '(';
                *p++ = obj->ichar;
                *p++ = ')';
                *p = 0;
                message(desc, 0);
            }
        }
        if (obj || (!stat)) {
            (void) reg_move();
        }
    }
}
