/*
 * score.c
 *
 * This source herein may be modified and/or distributed by anybody who
 * so desires, with the following restrictions:
 *    1.)  No portion of this notice shall be removed.
 *    2.)  Credit shall not be taken for the creation of this source.
 *    3.)  This code is not to be traded, sold, or used for personal
 *         gain or profit.
 *
 */

#include "rogue.h"

static void put_scores(object *monster, short int other, int gold);
static void sell_pack(void);
static int get_value(object *obj);
static int get_score_note(object *, char, int );

extern char login_name[];
extern char *m_names[];
extern short cur_level, max_level;
extern boolean score_only, show_skull, msg_cleared;
extern char *byebye_string, *nick_name;

static int score_comp(ScoreType *s1, ScoreType *s2, int other, 
               SortRecordInfoPtr info1, SortRecordInfoPtr info2, VoidHand appInfoH)
{
    int result;
    
    if (s1->score < s2->score)
        result = 1;
    else if (s1->score > s2->score)
        result = -1;
    else
    {
        if (s1->level < s2->level)
            result = 1;
        else if (s1->level > s2->level)
            result = -1;
    }
    return result;
}

void killed_by(object *monster, short int other)
{
    if (rogue.gameOver)
        return;

    rogue.gold = ((rogue.gold * 9) / 10);

    put_scores(monster, other, rogue.gold);
    get_score_note(monster, other, rogue.gold);
    rogue.gameOver = 1;
}

void win(void)
{
    unwield(rogue.weapon);      /* disarm and relax */
    unwear(rogue.armor);
    un_put_on(rogue.left_ring);
    un_put_on(rogue.right_ring);

    id_all();
    sell_pack();
    put_scores((object *) 0, WIN, rogue.gold);
    get_score_note((object *)0, WIN, rogue.gold);

    rogue.gameOver = 2;
}

static int get_score_note(object *monster, char other, int gold)
{
    char *buf, *p;
    
    buf = current_score;
    sprintf(buf, "Score: %d\n", gold);

#ifdef JP
    if (other != WIN) {
        sprintf(buf, "%s%d%s", 
                MESG_190, game.cur_level, MESG_191);
    }
#endif
    if (other) {
        switch(other) {
        case HYPOTHERMIA:
            p = MESG_192;
            break;
        case STARVATION:
            p = MESG_193;
            break;
        case POISON_DART:
            p = MESG_194;
            break;
        case WIN:
            p = MESG_196;
            break;
        }
        (void) strcat(buf, p);
    } else {
#ifdef JP
        (void) strcat(buf, m_names[monster->m_char - 'A']);
#endif
        (void) strcat(buf, MESG_197);
#ifndef JP
        if (is_vowel(m_names[monster->m_char - 'A'][0])) {
            p = "an ";
        } else {
            p = "a ";
        }
        (void) strcat(buf, p);
        (void) strcat(buf, m_names[monster->m_char - 'A']);
#endif
    }
#ifndef JP
    sprintf(buf+strlen(buf), " on level %d ",  game.max_level);
#endif
    if ((other != WIN) && has_amulet()) {
#ifndef JP
        (void) strcat(buf, MESG_189);
#endif
    }
    buf[strlen(buf)] = 0;
    return 0;
}

static void put_scores(object *monster, short int other, int gold)
{
    char *p;
    ScoreType sc;
    DmOpenRef ref;
    VoidHand handle;
    int size;

    size = sizeof(ScoreType);
    memset(&sc, 0, size);

    sc.score = gold;
    p = sc.desc;
    if (other) {
        switch(other) {
        case HYPOTHERMIA:
            strcpy(p, MESG_192);
            break;
        case STARVATION:
            strcpy(p, MESG_193);
            break;
        case POISON_DART:
            strcpy(p, MESG_194);
            break;
        case WIN:
            strcpy(p, MESG_196);
            break;
        }
    } else {
#ifdef JP
        (void) strcpy(p, m_names[monster->m_char - 'A']);
        (void) strcat(p, MESG_197);
#else
        (void) strcpy(p, MESG_197);
#endif

#ifndef JP
        if (is_vowel(m_names[monster->m_char - 'A'][0])) {
            strcat(p, "an ");
        } else {
            strcat(p, "a ");
        }
        strcat(p, m_names[monster->m_char - 'A']);
#endif
    }
    sc.level = game.max_level;
    sc.current = 1;
    
    ref = DmOpenDatabaseByTypeCreator(SCO_TYPE, ROGUE, dmModeReadWrite);
    ErrFatalDisplayIf(!ref, "");

    handle = DmGetRecord(ref, 10);
    DmWrite(MemHandleLock(handle), 0, &sc, size);
    MemHandleUnlock(handle);
    DmReleaseRecord(ref, 10, true);

    DmQuickSort(ref, (DmComparF *)score_comp, 0);

    DmCloseDatabase(ref);
}

int is_vowel(short int ch)
{
    return( (ch == 'a') ||
        (ch == 'e') ||
        (ch == 'i') ||
        (ch == 'o') ||
        (ch == 'u') );
}

static void sell_pack(void)
{
    object *obj;
    short row = 2, val;

    obj = rogue.pack.next_object;
    clear();

    while (obj) {
        if (obj->what_is != FOOD) {
            obj->identified = 1;
            val = get_value(obj);
            rogue.gold += val;

        }
        obj = obj->next_object;
    }
    if (rogue.gold > MAX_GOLD) {
        rogue.gold = MAX_GOLD;
    }
    message("", 0);
}

static int get_value(object *obj)
{
    short wc;
    int val;

    wc = obj->which_kind;

    switch(obj->what_is) {
    case WEAPON:
        val = id_weapons[wc].value;
        if ((wc == ARROW) || (wc == DAGGER) || (wc == SHURIKEN) ||
            (wc == DART)) {
            val *= obj->quantity;
        }
        val += (obj->d_enchant * 85);
        val += (obj->hit_enchant * 85);
        break;
    case ARMOR:
        val = id_armors[wc].value;
        val += (obj->d_enchant * 75);
        if (obj->is_protected) {
            val += 200;
        }
        break;
    case WAND:
        val = id_wands[wc].value * (obj->class + 1);
        break;
    case SCROLL:
        val = id_scrolls[wc].value * obj->quantity;
        break;
    case POTION:
        val = id_potions[wc].value * obj->quantity;
        break;
    case AMULET:
        val = 5000;
        break;
        case RING:
            val = id_rings[wc].value * (obj->class + 1);
                break;
    }
    if (val <= 0) {
        val = 10;
    }
    return(val);
}

void id_all(void)
{
    short i;

    for (i = 0; i < SCROLLS; i++) {
        id_scrolls[i].id_status = IDENTIFIED;
    }
    for (i = 0; i < WEAPONS; i++) {
        id_weapons[i].id_status = IDENTIFIED;
    }
    for (i = 0; i < ARMORS; i++) {
        id_armors[i].id_status = IDENTIFIED;
    }
    for (i = 0; i < WANDS; i++) {
        id_wands[i].id_status = IDENTIFIED;
    }
    for (i = 0; i < POTIONS; i++) {
        id_potions[i].id_status = IDENTIFIED;
    }
}
