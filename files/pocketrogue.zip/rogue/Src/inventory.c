/*
 * inventory.c
 *
 * This source herein may be modified and/or distributed by anybody who
 * so desires, with the following restrictions:
 *    1.)  No portion of this notice shall be removed.
 *    2.)  Credit shall not be taken for the creation of this source.
 *    3.)  This code is not to be traded, sold, or used for personal
 *         gain or profit.
 *
 */
        
#include "rogue.h"
        

#define swap_string(x,y) {char t[40]; strcpy(t, x); strcpy(x, y); strcpy(y, t);}
static void single_inv(short int ch);

boolean is_wood[WANDS];

char *wand_materials[WAND_MATERIALS] = {
    MESG_410, MESG_411, MESG_412, MESG_413, MESG_414, MESG_415,
    MESG_416, MESG_417, MESG_418, MESG_419, MESG_420, MESG_421,
    MESG_422, MESG_423, MESG_424, MESG_425, MESG_426, MESG_427,
    MESG_428, MESG_429, MESG_430, MESG_431, MESG_432, MESG_433,
    MESG_434, MESG_435, MESG_436, MESG_437, MESG_438, MESG_439,
};
      
char *gems[GEMS] = {
    MESG_440, MESG_441, MESG_442, MESG_443, MESG_444, MESG_445,
    MESG_446, MESG_447, MESG_448, MESG_449, MESG_450, MESG_451,
    MESG_452, MESG_453,
};
      
char *syllables[MAXSYLLABLES] = {
    MESG_454, MESG_455, MESG_456, MESG_457, MESG_458, MESG_459,
    MESG_460, MESG_461, MESG_462, MESG_463, MESG_464, MESG_465,
    MESG_466, MESG_467, MESG_468, MESG_469, MESG_470, MESG_471,
    MESG_472, MESG_473, MESG_474, MESG_475, MESG_476, MESG_477,
    MESG_478, MESG_479, MESG_480, MESG_481, MESG_482, MESG_483,
    MESG_484, MESG_485, MESG_486, MESG_487, MESG_488, MESG_489,
    MESG_490, MESG_491, MESG_492, MESG_493,
};
      
extern boolean wizard;
char descs[DROWS][DCOLS];   /* multi-purpose screen saver */

int inventory(object *pack, unsigned short mask)
{
    object *obj;
    short i = 0;

    obj = rogue.pack.next_object;
    if (!obj) {
        message(MESG_026, 0);
        return 0;
    } else {
        while (obj) {
            if (obj->what_is & mask) {
                invList[i] = MemPtrNew(DCOLS * sizeof(char));
                invList[i][0] = obj->ichar;
                invList[i][1] = ((obj->what_is & ARMOR) && obj->is_protected) ? '}' : ')';
                invList[i][2] = ' ';
                get_desc(obj, invList[i]+3, 0);
                i++;
            }
            obj = obj->next_object;
        }
    }
    return i;
}

void mix_colors(void)
{
    short i, j;
    extern char *po_color[];

    for (i = 0; i < POTIONS; i++) {
        strcpy(id_potions[i].title, po_color[i]);   /* by Yahsa */
    }
    for (i = 0; i < POTIONS; i++) {
        j = get_rand(i, POTIONS - 1);
        swap_string(id_potions[i].title, id_potions[j].title);

        id_potions[i].id_status = UNIDENTIFIED;
    }
    rw_id_table(TMP_TYPE, ID_POTIONS, -1, 1);
}

void make_scroll_titles(void)
{
    short i, j, n;
    short sylls, s;
#ifdef JP
    short len;
#endif

    for (i = 0; i < SCROLLS; i++) {
        sylls = get_rand(2, 5);
#ifdef JP
        (void) strcpy(id_scrolls[i].title, "�u");
        len = 2;
        for (j = 0; j < sylls; j++) {
            s = get_rand(1, (MAXSYLLABLES-1));
            n = strlen(syllables[s]);
            if (len + n - 1 >= MAX_TITLE_LENGTH - 2)
                break;
            (void) strcat(id_scrolls[i].title, syllables[s]);
            len += n;
        }
        (void) strcpy(id_scrolls[i].title+(len-1), "�v");
#else
        (void) strcpy(id_scrolls[i].title, "'");
        for (j = 0; j < sylls; j++) {
            s = get_rand(1, (MAXSYLLABLES-1));
            (void) strcat(id_scrolls[i].title, syllables[s]);
        }
        n = strlen(id_scrolls[i].title);
        (void) strcpy(id_scrolls[i].title+(n-1), "' ");
#endif
        id_scrolls[i].id_status = UNIDENTIFIED;
    }
    rw_id_table(TMP_TYPE, ID_SCROLLS,-1, 1);
}

    
#ifdef JP /* for whole function */
void get_desc(register object *obj, register char *desc, boolean capitalized)
{
    char *item_name, *p;
    struct id *id_table;
    char more_info[32];
    short i;
    int type;
    
    *desc = 0;
    if (obj->what_is == AMULET) {
        (void) strcpy(desc, MESG_027);
        return;
    }
    item_name = name_of(obj);
    if (obj->what_is == GOLD) {
#if 0
        znum(desc, obj->quantity, 0); // �����Ȃ�
#else
        sprintf(desc, "%d", obj->quantity);
#endif
        strcat(desc, MESG_028);
        return;
    }
    if (obj->what_is == WEAPON && obj->quantity > 1) {
#if 0
        znum(desc, obj->quantity, 0); // �����Ȃ�
#else
        sprintf(desc, "%d", obj->quantity);
#endif
        strcat(desc, MESG_029);
    } else if (obj->what_is == FOOD) {
#if 0
        znum(desc, obj->quantity, 0); // �����Ȃ�
#else
        sprintf(desc, "%d", obj->quantity);
#endif
        strcat(desc, (obj->which_kind == RATION)? MESG_030: MESG_031);
        (void) strcat(desc, item_name);
        goto ANA;
    } else if (obj->what_is != ARMOR && obj->quantity > 1) {
#if 0
        znum(desc, obj->quantity, 0); // �����Ȃ�
#else
        sprintf(desc, "%d", obj->quantity);
#endif
        strcat(desc, MESG_032);
    }
    id_table = get_id_table(obj, &type);

    if (obj->what_is & (WEAPON | ARMOR | WAND | RING)) {
        goto CHECK;
    }

    switch(id_table[obj->which_kind].id_status) {
    case UNIDENTIFIED:
CHECK:
        switch(obj->what_is) {
        case SCROLL:
            (void) strcat(desc, id_table[obj->which_kind].title);
            (void) strcat(desc, MESG_033);
            (void) strcat(desc, item_name);
            break;
        case POTION:
            (void) strcat(desc, id_table[obj->which_kind].title);
            (void) strcat(desc, item_name);
            break;
        case WAND:
        case RING:
            if (obj->identified ||
            (id_table[obj->which_kind].id_status == IDENTIFIED)) {
                goto ID;
            }
            if (id_table[obj->which_kind].id_status == CALLED) {
                goto CALL;
            }
            (void) strcat(desc, id_table[obj->which_kind].title);
            (void) strcat(desc, item_name);
            break;
        case ARMOR:
            if (obj->identified) {
                goto ID;
            }
            (void) strcpy(desc, id_table[obj->which_kind].title);
            break;
        case WEAPON:
            if (obj->identified) {
                goto ID;
            }
            (void) strcat(desc, name_of(obj));
            break;
        }
        break;
    case CALLED:
CALL:   switch(obj->what_is) {
        case SCROLL:
        case POTION:
        case WAND:
        case RING:
            p = id_table[obj->which_kind].title;
            if (*desc && (*p >= ' ' && *p <= '~' || *p >= '\240' && *p < '\340'))
                (void) strcat(desc, " ");
            (void) strcat(desc, p);
            (void) strcat(desc, MESG_034);
            (void) strcat(desc, item_name);
            break;
        }
        break;
    case IDENTIFIED:
ID:     switch(obj->what_is) {
        case SCROLL:
        case POTION:
            (void) strcat(desc, id_table[obj->which_kind].real);
            (void) strcat(desc, item_name);
            break;
        case RING:
            (void) strcat(desc, id_table[obj->which_kind].real);
            if (obj->identified) {
                if ((obj->which_kind == DEXTERITY) ||
                    (obj->which_kind == ADD_STRENGTH)) {
#if 0
                    strcpy(more_info, "�i");
                    znum(more_info, obj->class, 1); // ��������
                    strcat(more_info, "�j");
#else
                    sprintf(more_info, "(%s%d )",
                        ((obj->class > 0) ? "+" : ""),
                        obj->class);
#endif
                    (void) strcat(desc, more_info);
                }
            }
            (void) strcat(desc, item_name);
            break;
        case WAND:
            (void) strcat(desc, id_table[obj->which_kind].real);
            (void) strcat(desc, item_name);
            if (obj->identified) {
#if 0
                strcpy(more_info, "�m");
                znum(more_info, obj->class, 0); // �����Ȃ�
                strcat(more_info, "�n");
#else
                sprintf(more_info, "[%d]", obj->class);
#endif
                (void) strcat(desc, more_info);
            }
            break;
        case ARMOR:
#if 0
            strcpy(desc, "�i");
            znum(desc, obj->d_enchant, 1); // ��������
            strcat(desc, "�j");
            (void) strcat(desc, id_table[obj->which_kind].title);
            strcpy(more_info, "�m");
            znum(more_info, get_armor_class(obj), 0); // �����Ȃ�
            strcat(more_info, "�n");
            (void) strcat(desc, more_info);
#else
            sprintf(desc, "(%s%d )",
                ((obj->d_enchant >= 0) ? "+" : ""),
                obj->d_enchant);
            (void) strcat(desc, id_table[obj->which_kind].title);
            sprintf(more_info, "[%d] ", get_armor_class(obj));
            (void) strcat(desc, more_info);
#endif
            break;
        case WEAPON:
#if 0
            strcat(desc, "�i");
            znum(desc, obj->hit_enchant, 1); // ��������
            strcat(desc, "�C");
            znum(desc, obj->d_enchant, 1); // ��������
            strcat(desc, "�j");
            (void) strcat(desc, name_of(obj));
#else
            sprintf(desc+strlen(desc), "(%s%d, %s%d )",
                ((obj->hit_enchant >= 0) ? "+" : ""),
                obj->hit_enchant,
                ((obj->d_enchant >= 0) ? "+" : ""),
                obj->d_enchant);
            (void) strcat(desc, name_of(obj));
#endif
            break;
        }
        break;
    }
ANA:
    i = obj->in_use_flags;
    if (i & BEING_WIELDED) {
        p = MESG_035;
    } else if (i & BEING_WORN) {
        p = MESG_036;
    } else if (i & ON_LEFT_HAND) {
        p = MESG_037;
    } else if (i & ON_RIGHT_HAND) {
        p = MESG_038;
    } else {
        p = "";
    }
    (void) strcat(desc, p);
}

#else /*JAPAN for whole function get_desc */

void get_desc(object *obj, char *desc, boolean capitalized)
{
    char *p;
    char *item_name;
    struct id *id_table;
    char more_info[32];
    short i;
    int type;
    
    if (obj->what_is == AMULET) {
        (void) strcpy(desc, MESG_027);
        if (!capitalized)
            *desc = 't';
        return;
    }
    item_name = name_of(obj);

    if (obj->what_is == GOLD) {
        sprintf(desc, MESG_028, obj->quantity);
        return;
    }

    if (obj->what_is != ARMOR) {
        if (obj->quantity == 1) {
            strcpy(desc, capitalized? "A ": "a ");
        } else {
            sprintf(desc, "%d ", obj->quantity);
        }
    }
    if (obj->what_is == FOOD) {
        if (obj->which_kind == RATION) {
            if (obj->quantity > 1) {
                sprintf(desc, MESG_030, obj->quantity);
            } else {
                strcpy(desc, capitalized? "Some ": "some ");
            }
        } else {
            strcpy(desc, capitalized? "A ": "a ");
        }
        (void) strcat(desc, item_name);
        goto ANA;
    }
    id_table = get_id_table(obj, &type);

    if (obj->what_is & (WEAPON | ARMOR | WAND | RING)) {
        goto CHECK;
    }

    switch(id_table[obj->which_kind].id_status) {
    case UNIDENTIFIED:
CHECK:
        switch(obj->what_is) {
        case SCROLL:
            (void) strcat(desc, item_name);
            (void) strcat(desc, MESG_033);
            (void) strcat(desc, id_table[obj->which_kind].title);
            break;
        case POTION:
            (void) strcat(desc, id_table[obj->which_kind].title);
            (void) strcat(desc, item_name);
            break;
        case WAND:
        case RING:
            if (obj->identified ||
            (id_table[obj->which_kind].id_status == IDENTIFIED)) {
                goto ID;
            }
            if (id_table[obj->which_kind].id_status == CALLED) {
                goto CALL;
            }
            (void) strcat(desc, id_table[obj->which_kind].title);
            (void) strcat(desc, item_name);
            break;
        case ARMOR:
            if (obj->identified) {
                goto ID;
            }
            (void) strcpy(desc, id_table[obj->which_kind].title);
            break;
        case WEAPON:
            if (obj->identified) {
                goto ID;
            }
            (void) strcat(desc, name_of(obj));
            break;
        }
        break;
    case CALLED:
CALL:   switch(obj->what_is) {
        case SCROLL:
        case POTION:
        case WAND:
        case RING:
            (void) strcat(desc, item_name);
            (void) strcat(desc, MESG_034);
            (void) strcat(desc, id_table[obj->which_kind].title);
            break;
        }
        break;
    case IDENTIFIED:
ID:     switch(obj->what_is) {
        case SCROLL:
        case POTION:
            (void) strcat(desc, item_name);
            (void) strcat(desc, id_table[obj->which_kind].real);
            break;
        case RING:
            if (obj->identified) {
                if ((obj->which_kind == DEXTERITY) ||
                    (obj->which_kind == ADD_STRENGTH)) {
                    sprintf(more_info, "%s%d ",
                        ((obj->class > 0) ? "+" : ""),
                        obj->class);
                    (void) strcat(desc, more_info);
                }
            }
            (void) strcat(desc, item_name);
            (void) strcat(desc, id_table[obj->which_kind].real);
            break;
        case WAND:
            (void) strcat(desc, item_name);
            (void) strcat(desc, id_table[obj->which_kind].real);
            if (obj->identified) {
                sprintf(more_info, "[%d]", obj->class);
                (void) strcat(desc, more_info);
            }
            break;
        case ARMOR:
            sprintf(desc, "%s%d ",
                ((obj->d_enchant >= 0) ? "+" : ""),
                obj->d_enchant);
            (void) strcat(desc, id_table[obj->which_kind].title);
            sprintf(more_info, "[%d] ", get_armor_class(obj));
            (void) strcat(desc, more_info);
            break;
        case WEAPON:
            sprintf(desc+strlen(desc), "%s%d, %s%d ",
                ((obj->hit_enchant >= 0) ? "+" : ""),
                obj->hit_enchant,
                ((obj->d_enchant >= 0) ? "+" : ""),
                obj->d_enchant);
            (void) strcat(desc, name_of(obj));
            break;
        }
        break;
    }
ANA:
    if (!strncmp(desc, (capitalized? "A ": "a "), 2)) {
        if (is_vowel(desc[2])) {
            for (i = strlen(desc) + 1; i > 1; i--) {
                desc[i] = desc[i-1];
            }
            desc[1] = 'n';
        }
    }
    i = obj->in_use_flags;
    if (i & BEING_WIELDED) {
        p = MESG_035;
    } else if (i & BEING_WORN) {
        p = MESG_036;
    } else if (i & ON_LEFT_HAND) {
        p = MESG_037;
    } else if (i & ON_RIGHT_HAND) {
        p = MESG_038;
    } else {
        p = "";
    }
    (void) strcat(desc, p);
}
#endif /*JAPAN for whole function get_desc() */

        
void get_wand_and_ring_materials(void)
{
    short i, j;
    char *p;
    boolean used[WAND_MATERIALS];

    for (i = 0; i < WAND_MATERIALS; i++) {
        used[i] = 0;
    }
    for (i = 0; i < WANDS; i++) {
        do {
            j = get_rand(0, WAND_MATERIALS-1);
        } while (used[j]);
        used[j] = 1;
        p = id_wands[i].title;
        (void) strcpy(p, wand_materials[j]);
#ifdef JP
        (void) strcat(p, MESG_039);
#endif
        game.is_wood[i] = (j > MAX_METAL);
        id_wands[i].id_status = UNIDENTIFIED;
    }


    rw_id_table(TMP_TYPE, ID_WANDS, -1, 1);

    for (i = 0; i < GEMS; i++) {
        used[i] = 0;
    }
    for (i = 0; i < RINGS; i++) {
        do {
            j = get_rand(0, GEMS-1);
        } while (used[j]);
        used[j] = 1;
        p = id_rings[i].title;
        (void) strcpy(p, gems[j]);
#ifdef JP
        (void) strcat(p, MESG_040);
#endif
        id_rings[i].id_status = UNIDENTIFIED;
    }
    rw_id_table(TMP_TYPE, ID_RINGS, -1, 1); // TOTA
}


void single_inv(short ichar)
{
    short ch;
    char *p;
    object *obj;
    char desc[DCOLS];

    ch = ichar? ichar: pack_letter(MESG_041, ALL_OBJECTS);

    if (ch == CANCEL) {
        return;
    }
    if (!(obj = get_letter_object(ch))) {
        message(MESG_041, 0);
        return;
    }
    p = desc;
    *p++ = ch;
    *p++ = ((obj->what_is & ARMOR) && obj->is_protected) ? '}' : ')';
    *p++ = ' ';
    get_desc(obj, p, 1);
    message(desc, 0);
}

struct id *get_id_table(object *obj, int *type)
{
    switch(obj->what_is) {
    case SCROLL:
        *type = ID_SCROLLS;
        return(id_scrolls);
    case POTION:
        *type = ID_POTIONS;
        return(id_potions);

    case WAND:
        *type = ID_WANDS;
        return(id_wands);

    case RING:
        *type = ID_RINGS;
        return(id_rings);
    case WEAPON:
        return(id_weapons);
    case ARMOR:
        return(id_armors);
    }
    return((struct id *) 0);
}
        
void inv_armor_weapon(boolean is_weapon)
{
    if (is_weapon) {
        if (rogue.weapon) {
            single_inv(rogue.weapon->ichar);
        } else {
            message(MESG_043, 0);
        }
    } else {
        if (rogue.armor) {
            single_inv(rogue.armor->ichar);
        } else {
            message(MESG_044, 0);
        }
    }
}

#ifdef JP
static char *_num[10] = { "�O","�P","�Q","�R","�S","�T","�U","�V","�W","�X" };
   
void znum(buf, n, plus)
    char *buf;
    int n, plus;
{
    char s[10], *p;

    while (*buf)
        buf++;
    if (plus && n >= 0) {
        strcpy(buf, "�{");
        buf += 2;
    }
    sprintf(s, "%d", n);
    for (p = s; *p; p++) {
        strcpy(buf, (*p == '-')? "�|": _num[*p - '0']);
        buf += 2;
    }
}
   
void lznum(buf, n, plus)
    char *buf;
    long n;
    int plus;
{
    char s[13], *p;

    while (*buf)
        buf++;
    if (plus && n >= 0L) {
        strcpy(buf, "�{");
        buf += 2;
    }
    sprintf(s, "%ld", n);
    for (p = s; *p; p++) {
        strcpy(buf, (*p == '-')? "�|": _num[*p - '0']);
        buf += 2;
    }
}
#endif
