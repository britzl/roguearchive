        /*
         * init.c
         *
         * This source herein may be modified and/or distributed by anybody who
         * so desires, with the following restrictions:
         *    1.)  No portion of this notice shall be removed.
         *    2.)  Credit shall not be taken for the creation of this source.
         *    3.)  This code is not to be traded, sold, or used for personal
         *         gain or profit.
         *
         */
        
#include "rogue.h"
        

static int player_init();
static void init_var(void);

char login_name[30];
//char *nick_name = "";
char *rest_file = 0;
boolean cant_int = 0, did_int = 0, score_only = 0, init_curses = 0;
boolean save_is_interactive = 1;
boolean show_skull = 1;
boolean pass_go = 1, do_restore = 0;
char org_dir[64], *game_dir = "";
        
char *error_file = "rogue.err";
char *mac_type = "none", *cursor_str = "";
char *init_string = "", *term_string = "";
char init_str[30], term_str[30];
char cursor_on[10], cursor_off[10];

extern char *fruit;
extern char *save_file;
extern short party_room, party_counter;
extern boolean jump;


rogue_init(void)
{
    initscr();

    srrandom(md_gseed());

    if (restore(TMP_TYPE))
        return(1);

    init_var();

    mix_colors();
    get_wand_and_ring_materials();
    make_scroll_titles();

    level_objects.next_object = 0;
    level_monsters.next_monster = 0;
    player_init();
    game.party_counter = get_rand(1, PARTY_TIME);
    ring_stats(0);
    return(0);
}

static int player_init()
{
    object *obj;

    rogue.pack.next_object = 0;

    obj = alloc_object();
    get_food(obj, 1);
    (void) add_to_pack(obj, &rogue.pack, 1);

    obj = alloc_object();       /* initial armor */
    obj->what_is = ARMOR;
    obj->which_kind = RINGMAIL;
    obj->class = RINGMAIL+2;
    obj->is_protected = 0;
    obj->d_enchant = 1;
    (void) add_to_pack(obj, &rogue.pack, 1);
    do_wear(obj);

    obj = alloc_object();       /* initial weapons */
    obj->what_is = WEAPON;
    obj->which_kind = MACE;
    strcpy(obj->damage, "2d3");
    obj->hit_enchant = obj->d_enchant = 1;
    obj->identified = 1;
    (void) add_to_pack(obj, &rogue.pack, 1);
    do_wield(obj);

    obj = alloc_object();
    obj->what_is = WEAPON;
    obj->which_kind = BOW;
    strcpy(obj->damage, "1d2");
    obj->hit_enchant = 1;
    obj->d_enchant = 0;
    obj->identified = 1;
    (void) add_to_pack(obj, &rogue.pack, 1);

    obj = alloc_object();
    obj->what_is = WEAPON;
    obj->which_kind = ARROW;
    obj->quantity = get_rand(25, 35);
    strcpy(obj->damage, "1d2");
    obj->hit_enchant = 0;
    obj->d_enchant = 0;
    obj->identified = 1;
    (void) add_to_pack(obj, &rogue.pack, 1);

    rogue.gameOver = 0;
    return 0;
}

static void init_var(void)
{
    hit_message[0] = 0;
    hunger_str[0] = 0;

    free_stuff(free_list, 1);

    new_level_message = (char *)0;

    fight_monster = 0;
    r_de = 0;
    mon_disappeared = 0;
    interrupted = 0;
    stealthy = 0;
    r_rings  = 0;
    add_strength = 0;
    e_rings = 0;
    regeneration = 0;
    ring_exp = 0;

    auto_search = 0;

    r_teleport = 0;
    r_see_invisible = 0;
    sustain_strength = 0;
    maintain_armor = 0;
    less_hp = 0;
    extra_hp = 0;

    // game
    memset(&game, 0, sizeof(game));
    game.max_level = 1;
    game.party_room = NO_ROOM;

    // rogue
    memset(&rogue, 0, sizeof(fighter));
    rogue.hp_current  = rogue.hp_max  = INIT_HP;
    rogue.str_current = rogue.str_max = 16;
    rogue.exp = 1;
    rogue.fchar = '@';
    rogue.moves_left = 1250;
}
