#include "rogue.h"
#include "rogueRsc.h"

static int ExportToMemoPad(VoidHand hndExportText);

#define BEG 54
#define END 54+48

void DrawMap(char flg)
{
    if (flg)
        SndPlaySystemSound (sndClick);

    WinEraseWindow();
    if (map_shown) {
        map_shown = 0;
        SnapScreen(rogue.row, rogue.col);
        DrawScreen(rogue.row, rogue.col);
    }
    else {
        map_shown = 1;
        Map(-1, -1);
    }
    RogueStatus();
}

void Map(SWord x, SWord y)
{
    static char toggle;

    if (x == -1 && y == -1)
        toggle = 0;

    ClearGadget();

    if (!toggle) {
#ifdef JP
        WinDrawInvertedChars("�n�}(�k��)", 10, 0, 0);
#else
        WinDrawInvertedChars("MAP(S)", 6, 0, 0);
#endif
        DrawDungeon();
        toggle = 1;
    }
    else {
        if (y < BEG || y > END) 
            return;

        y -= BEG;

        x /= 2;
        y /= 2;
#ifdef JP
        WinDrawInvertedChars("�n�}(�g��)", 10, 0, 0);
#else
        WinDrawInvertedChars("MAP(L)", 6, 0, 0);
#endif
        DrawScreen(y, x);
        toggle = 0;
    }
}


void Remessage(void)
{
    check_message();
    remessage();
}

#define OFFSET 3

char Direction(SWord x, SWord y)
{
    PointType start, end;
    Boolean penDown, upperCase = false;
    char horiz, vert, ch = 0;
    
    start.x = x / 6;
    start.y = y / 8;

    do {
        EvtGetPen(&end.x, &end.y,&penDown);
    } while (penDown);
    
    if (y < 12) {
        Remessage();
        return 0;
    }
    if (y > 148) {
        statusPage++;
        RogueStatus();
        return 0;
    }

    start.x = x / 6;
    start.y = (y - 11) / 8;

    end.x /= 6;
    end.y = (end.y -11) / 8;

#if 0
    if (start.x == end.x && start.y == end.y)
        upperCase = false;
    else if (start.x == rogue.x && start.y == rogue.y)
        upperCase = true;
#else
    if (rogue.x - 1 < start.x && start.x < rogue.x + 1)
        if (rogue.y - 1 < start.y && start.y < rogue.y + 1)
            upperCase = true;
    if (rogue.x - 1 < end.x && end.x < rogue.x + 1)
        if (rogue.y - 1 < end.y && end.y < rogue.y + 1)
            upperCase = false;
#endif
    if (end.x < rogue.x) {
        horiz = 0;     // left
    } else
        if (end.x > rogue.x) {
            horiz = 1; // right
        } else
            horiz = 2; // middle

    if (end.y < rogue.y) {
        vert = 0;     // up
    } else
        if (end.y > rogue.y) {
            vert = 1; // down
        } else
            vert = 2; // middle

    switch (horiz) {
    case 0: /* left */
        switch (vert) {
        case 0: /* up */
            ch = upperCase ? '\031' : 'y';
            break;
        case 1: /* down */
            ch = upperCase ? '\002' : 'b';
            break;
        case 2: /* middle */
            ch = upperCase ? '\010' : 'h';
            break;
        }
        break;

    case 1: /* right */
        switch (vert) {
        case 0: /* up */
            ch = upperCase ? '\025' : 'u';
            break;
        case 1: /* down */
            ch = upperCase ? '\016' : 'n';
            break;
        case 2: /* middle */
            ch = upperCase ? '\014' : 'l';
            break;
        }
        break;
    case 2: /* centre */
        switch (vert) {
        case 0: /* up */
            ch = upperCase ? '\013' : 'k';
            break;
        case 1: /* down */
            ch = upperCase ? '\012' : 'j';
            break;
        case 2: /* middle */
            ch = CANCEL;
            break;
        }
        break;
    }
    return(ch);
}


Boolean doSomething(void)
{
    unsigned short dir;

    if (direction)
    {
        /* action with directions */
        dir = direction;
        switch (actionFlag) {
        case A1Fight:
        case A1Fighttothedeath:
            fight(actionFlag == A1Fighttothedeath, dir);
            break;
        case A1MoveOnto:
            move_onto(dir);
            break;
        case A1IDTrap:
            id_trap(dir);
            break;
        case A3Throw:
            throw(dir);
            break;
        case A3Zap:
            zapp(dir);
            break;
        default:
            check_message();

            switch (dir) {
            case 'h':
            case 'j':
            case 'k':
            case 'l':
            case 'y':
            case 'u':
            case 'n':
            case 'b':
                one_move_rogue(dir, 1);
                break;
            case 'H':
            case 'J':
            case 'K':
            case 'L':
            case 'B':
            case 'Y':
            case 'U':
            case 'N':
            case '\010':
            case '\012':
            case '\013':
            case '\014':
            case '\031':
            case '\025':
            case '\016':
            case '\002':
                multiple_move_rogue(dir);
                SnapScreen(rogue.row, rogue.col);
                break;
            default:
                break;
            }
            break;
        }
        direction = 0;
    }
    interrupted = 0;
    count = 0;
    actionFlag = 0;

    if (rogue.gameOver == 1)
    {
        wait_for_ack();
        ClearGadget();
        FrmGotoForm(RipForm);
    }
    else if (rogue.gameOver == 2) 
    {
        int k;

        for (k = 0; k < 4; k++)
            WinDrawChars(win_msg[k], strlen(win_msg[k]), 2, 30+(k*11));
        DrawBitmap(0, 11, WinBitmap);
        for (k = 0; k < 3; k++)
            WinDrawChars(win_msg[k+4], strlen(win_msg[k+4]), 2, 90+(k*11));

        ExportScore(current_score);

        wait_for_ack();
        FrmGotoForm(ScoreForm);
    }
    else
        DrawScreen(rogue.row, rogue.col);

    return false;
}

void rogueNewLevel(Boolean free)
{
    if (free) {
        free_stuff(&level_objects, 0);      // XXX_LEVEL �f�[�^���
        free_stuff(&level_monsters, 0);     // XXX_MONSTER �f�[�^���
    }
    if (rogue.gameOver) {
        if (rogue_init())
        {
//            check_message(); // msg_cleared = 1;
//            message(MESG_603, 0);
            return;
        }
        message(MESG_010, 0);
    }

    interrupted = 0;
    is_first = 1;
    clear_level(), 
    make_level();
    put_objects();
    put_stairs();
    add_traps();
    put_mons();
    put_player(game.party_room);
    print_stats(STAT_ALL);
}

void rogueFreeLevel(void)
{
    free_stuff(&level_objects, 1);
    free_stuff(&level_monsters, 1);
    free_stuff(&rogue.pack, 1);
    free_stuff(free_list, 1);
}

void ExportScore(char *s)
{
    VoidHand h;
    CharPtr sFld;
    Char sDate[30];
    DateTimeType dtNow;
    int i, count;

    h = MemHandleNew ( 4000 );
    if (!h)
        return;

    sFld = (CharPtr) MemHandleLock( h );
    StrCopy( sFld, "PocketRogue: " );
    TimSecondsToDateTime( TimGetSeconds(), &dtNow );
    StrPrintF(sDate, "%d/%d/%d %d:%d", dtNow.year, dtNow.month, dtNow.day,
              dtNow.hour, dtNow.minute  );
    StrCat( sFld, sDate );
    StrCat( sFld, "\n\n" );

    /* Export Clock Out Time */
    StrCat( sFld, s );

    if (rogue.gameOver == 2)
    {
        StrCat( sFld, "\n\n");
        for (i = 0; i < 7; i++)
            StrCat( sFld, win_msg[i] );
    }

    {
        id_all();

#ifdef JP
        StrCat( sFld, "\n\n�����i: \n" );
#else
        StrCat( sFld, "\n\nInventory: \n" );
#endif
        invList = (char **) MemPtrNew(MAX_PACK_COUNT * sizeof(char *));
        count = inventory(&rogue.pack, ALL_OBJECTS);

        for (i = 0; i < count; i++) {
            StrCat( sFld, invList[i]);
            StrCat( sFld, "\n" );
        }

        for (i = 0; i < count; i++)
            MemPtrFree(invList[i]);
        MemPtrFree(invList);

        StrCat( sFld, "\n" );
    }

    MemHandleUnlock (h);
    ExportToMemoPad (h);

    MemHandleFree(h);
}

static int ExportToMemoPad(VoidHand hndExportText)
{
    UInt record = firstRecord;
    VoidHand hndNew;
    DmOpenRef pdbMemoPad;
    Word length;
    char *sExportText;

    /* Open MemoPad database */
    pdbMemoPad = DmOpenDatabaseByTypeCreator(memoPadDBType, memoPadAppType, dmModeReadWrite);
    if (!pdbMemoPad)
    {
        FrmAlert(ErrorAlert);
        return 1;
    }

    /* Create New MemoPad record */
    sExportText = (CharPtr) MemHandleLock(hndExportText);
    length = StrLen(sExportText);
    if (length > memoPadMaxChar)
    {
        FrmAlert(ErrorAlert);
        return 3;
    }
    record = 0;             // at index 0 in MemoPad database
    hndNew = DmNewRecord(pdbMemoPad, &record, length+1);

    if (!hndNew)
    {
        FrmAlert(ErrorAlert);
        return 2;
    }

    DmWrite(MemHandleLock(hndNew), 0, MemHandleLock(hndExportText), length+1);
    MemHandleUnlock(hndExportText);
    MemHandleUnlock(hndNew);
    DmReleaseRecord(pdbMemoPad, record, true);
    DmCloseDatabase(pdbMemoPad);

    return 0;
}

// ==================================================================================
static void rw_item(DmOpenRef ref, int pos, struct id *ptr, char rw)
{
    VoidHand handle;
    struct did d;
    ULong   s;
    
    handle = DmGetRecord(ref, pos);
    ErrFatalDisplayIf(!handle, "");

    s = sizeof(struct did);
    memset(&d, 0, s);

    if (rw) {
        d.value = ptr->value;
        strcpy(d.title, ptr->title);
        strcpy(d.real,  ptr->real);
        d.id_status = ptr->id_status;

        DmWrite(MemHandleLock(handle), 0, (VoidPtr)&d,  s);
    }
    else {
        MemMove((VoidPtr)&d, MemHandleLock(handle), s);

        ptr->value = d.value;
        strcpy(ptr->title, d.title);
        strcpy(ptr->real,  d.real);
        ptr->id_status  = d.id_status;
    }

    MemHandleUnlock(handle);
    DmReleaseRecord (ref, pos, true);
}

void rw_id_table(ULong db_type, int type, int pos, char rw)
{
    int i, start, end, count[] = {POTIONS, SCROLLS, WANDS, RINGS};
    struct id *ptr;
    DmOpenRef ref;

    ref = DmOpenDatabaseByTypeCreator(db_type, ROGUE, dmModeReadWrite);
    ErrFatalDisplayIf(!ref, "");

    start = 0;
    for (i = 0; i < type; i++)
        start += count[i];
    end = start + count[type];

    switch (type) {
    case ID_POTIONS:  ptr = id_potions; break;
    case ID_SCROLLS:  ptr = id_scrolls; break;
    case ID_WANDS:    ptr = id_wands;   break;
    case ID_RINGS:    ptr = id_rings;   break;
    default:
        return;
    }
    
    if (pos == -1)
        for (i = start, pos = 0; i < end; i++, pos++) {
            rw_item(ref, i, &ptr[pos], rw);
        }
    else {
        rw_item(ref, start + pos, &ptr[pos], 1);
    }

    DmCloseDatabase(ref);
}
