extern prefs_t prefs;

extern object mon_tab[MONSTERS];
extern object *fight_monster;
extern char hit_message[80];
extern char *new_level_message;
extern short r_de;
extern long level_points[];
extern boolean msg_cleared;
extern char hunger_str[];
extern object level_monsters;
extern boolean mon_disappeared;
extern char *you_can_move_again;
extern object level_objects;
extern unsigned short dungeon[DROWS][DCOLS];
extern object *free_list;
extern char *fruit;

extern fighter rogue;
extern struct id id_potions[];
extern struct id id_scrolls[];
extern struct id id_weapons[];
extern struct id id_armors[];
extern struct id id_wands[];
extern struct id id_rings[];

extern char *curse_message;

extern boolean interrupted;

extern short stealthy, r_rings, add_strength, e_rings, regeneration, ring_exp;
extern short auto_search;
extern boolean r_teleport, r_see_invisible, sustain_strength, maintain_armor;

extern room rooms[];
extern short less_hp;
extern short extra_hp;

extern struct Game game;
extern char is_first;

extern char buf[];
extern char *win_msg[];

extern char **invList;
extern char paused;

extern char buffer[DROWS][DCOLS];
extern char terminal[DROWS][DCOLS];
extern char map_shown;

extern unsigned char statusPage;
extern unsigned short actionFlag;
extern unsigned short direction;
extern int count;

extern ScreenType screen;
extern RectangleType g;
extern char current_score[];
extern WinHandle font;

// ================================================================================//
// curses.c
extern void addch(int ch);
extern void mvaddch(short row,short col,int ch);
extern int mvinch(short row,short col);
extern void clear(void);


// hit.c
extern void mon_hit(object *monster,char *other,char flame);
extern void rogue_hit(object *monster,char force_hit);
extern int get_damage(char *ds,char r);
extern int get_number(char *s);
extern int mon_damage(object *monster,int damage);
extern void fight(char to_the_death,short ch);
extern void get_dir_rc(short dir,short *row,short *col,short allow_off_screen);
extern short get_hit_chance(object *weapon);
extern int get_weapon_damage(object *weapon);


// init.c
extern int rogue_init(void );


// inventory.c
extern int inventory(object *pack, short unsigned int mask);
extern void mix_colors(void );
extern void make_scroll_titles(void );
extern void get_desc(object *obj, char *desc, boolean );
extern void get_wand_and_ring_materials(void );
extern struct id *get_id_table(struct obj *obj,int *type);
extern void inv_armor_weapon(char is_weapon);


// level.c
extern void make_level(void );
extern void clear_level(void);
extern void put_player(short nr);
extern int drop_check(void);
extern int check_up(void);
extern void add_exp(int e,char promotion);
extern int hp_raise(void);


/// message.c
extern void message(char *msg,char intrpt);
extern void remessage(void );
extern void check_message(void );
extern void print_stats(int stat_mask);


/// monster.c
extern void put_mons(void );
extern object *gr_monster(object *monster,int mn);
extern void mv_mons(void );
extern void party_monsters(int rn,int n);
extern int gmc_row_col(int row,int col);
extern int gmc(object *monster);
extern void mv_monster(object *monster,short row,short col);
extern void move_mon_to(object *monster,short row,short col);
extern int mon_can_go(object *monster,short row,short col);
extern void wake_up(object *monster);
extern void wake_room(short rn,char entering,short row,short col);
extern char *mon_name(object *monster);
extern int rogue_is_around(short row,short col);
extern void wanderer(void );
extern void show_monsters(void );
extern void create_monster(void );
extern int rogue_can_see(int row,int col);
extern int gr_obj_char(void );
extern void aggravate(void );
extern char mon_sees(object *monster,int row,int col);
extern void mv_aquatars(void );


/// move.c
extern int one_move_rogue(short dirch,short pickup);
extern void multiple_move_rogue(int dirch);
extern int is_passable(int row,int col);
extern int can_move(int row1,int col1,int row2,int col2);
extern void move_onto(short ch);
extern char reg_move(void);
extern void rest(int count);


/// object.c
extern void put_objects(void);
extern void place_at(object *obj,int row,int col);
extern object *object_at(object *pack,short row,short col);
extern object *get_letter_object(int ch);
extern void free_stuff(object *objlist,int type);
extern char *name_of(object *obj);
extern object *gr_object();
extern void get_food(object *obj, boolean force_ration);
extern void put_stairs(void);
extern int get_armor_class(object *obj);
extern object *alloc_object(void);
extern void free_object(object *obj);
extern void show_objects(void);
extern void put_amulet(void);


/// pack.c
extern object *add_to_pack(object *obj,object *pack,int condense);
extern void take_from_pack(object *obj,object *pack);
extern object *pick_up(int row,int col,short *status);
extern void drop(void );
extern int pack_letter(char *prompt,unsigned short mask);
extern void take_off(void);
extern void wear(void );
extern void unwear(object *obj);
extern void do_wear(object *obj);
extern void wield(void );
extern void do_wield(object *obj);
extern void unwield(object *obj);
extern void call_it(void );
extern int pack_count(object *new_obj);
extern int has_amulet(void);
extern void kick_into_pack(void);



/// random.c
extern void srrandom(long seed);
extern int get_rand(int x,int y);
extern int rand_percent(int percentage);
extern int coin_toss(void);



// ring.c
extern void put_on_ring(void );
extern void do_put_on(object *ring, boolean on_left);
extern void remove_ring(void);
extern void un_put_on(object *ring);
extern void gr_ring(object *ring, boolean assign_wk);
extern void inv_rings(void);
extern void ring_stats(boolean pr);


// rogue.c
extern DWord PilotMain( Word cmd, Ptr cmdPBP, Word launchFlags);

// rogue_gui.c
extern Boolean MainFormHandleEvent( EventPtr eventP);
extern Boolean AboutFormHandleEvent( EventPtr eventP);
extern Boolean HardKeyHandleEvent( EventPtr eventP);
extern Boolean ScoreFormHandleEvent(EventPtr e);
extern Boolean RipFormHandleEvent(EventPtr e);
extern Boolean OptionFormHandleEvent(EventPtr e);

extern void SnapScreen(SWord row, SWord col);
extern void DrawDungeon(void );
extern void DrawScreen(SWord row, SWord col);
extern void DrawString(char *s, Boolean status);
extern void DrawBitmap(int x,int y,int resID);
extern void RogueStatus(void );
extern int  get_input_line(char *buf,char *old);
extern void wait_for_ack(void );


/// rogue_lst.c
extern int  PopupList(int invMask,int type);
extern void Discovered(void);


/// rogue_sub.c
extern void DrawMap(char );
extern void Map(SWord, SWord);
extern void Remessage(void );
extern char Direction(SWord x,SWord y);
extern Boolean doSomething(void );
extern void rogueNewLevel(Boolean free);
extern void rogueFreeLevel(void );
extern void ExportScore(char *s);
extern void rw_id_table(ULong db_type, int type, int pos, char rw);


// room.c
extern void light_up_room(int rn);
extern void light_passage(int row,int col);
extern void darken_room(short rn);
extern int get_dungeon_char(int row,int col);
extern int get_mask_char(unsigned short mask);
extern void gr_row_col(short *row,short *col,unsigned short mask);
extern int gr_room(void);
extern int party_objects(int rn);
extern int get_room_number(int row,int col);
extern int is_all_connected(void);
extern void draw_magic_map(void);
extern void dr_course(object *monster, boolean entering, short row, short col);


// save.c
extern char save_game(char *fname, ULong type);
extern int  restore(ULong type);


/// score.c
extern void killed_by(object *monster,short other);
extern void win(void );
extern int is_vowel(short ch);

extern void id_all(void );

// spec_hit.c
extern void special_hit(object *monster);
extern void rust(object *monster);
extern void cough_up(object *monster);
extern void check_gold_seeker(object *monster);
extern char check_imitator(object *monster);
extern int imitating(short row,short col);
extern int m_confuse(object *monster);
extern int flame_broil(object *monster);
extern int seek_gold(object *monster);


/// throw.c
extern void throw(short dir);
extern void rand_around(short i,short *r,short *c);


/// trap.c
extern void trap_player(short row,short col);
extern void add_traps(void );
extern void id_trap(short dir);
extern void search(short n,char is_auto);


// use.c
extern void quaff(void );
extern void read_scroll(void );
extern void vanish(object *obj, short rm, object *pack);
extern void eat(void );
extern void tele(void);

extern void hallucinate(void);
extern void unhallucinate(void);
extern void unblind(void);
extern void relight(void);
extern void take_a_nap(void);
extern void confuse(void);
extern void unconfuse(void);

// zap.c
extern void zapp(short dir);
extern void zap_monster(object *monster, short unsigned int kind);

#ifdef JP
void znum(char *buf, int n, int plus);
void lznum(char *buf, long n, int plus);
#endif

extern void ClearString(void);
