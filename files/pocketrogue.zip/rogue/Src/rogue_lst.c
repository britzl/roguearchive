#include "rogue.h"
#include "rogueRsc.h"

// type0 : inventory, type:1..ring, type:2 action
typedef struct action
{
    int id;
    char str[20];
} action;

action actions[] = 
{
#ifdef JP
    {A1Rest,        ". ���̏�ŋx��"},
    {A1Search,      "s 㩂����T��"},
    {A2Inventory,   "i ���������݂�"},
    {A3Throw    ,   "t ���𓊂���"},
    {A3Zap,         "z ���U�肩����"},
    {A3Drop,        "d �������𗎂Ƃ�"},
    {A3Wield,       "w �������Ɏ���"},
    {A3Eat,         "e �H�ו���H�ׂ�"},
    {A3Quaff,       "q ���������"},
    {A1Ascendlevel, "< �K�i��o��"},
    {A1Descendlevel,"> �K�i�������"},
    {A1IDTrap,      "^ 㩂̎�ނ𒲂ׂ�"},
    {A3ReadScroll,  "r ������ǂ�"},
    {A3TakeOff,     "T ��낢��E��"},
    {A3Wear,        "W ��낢�𒅂�"},
    {A3PutonRing,   "P �w�ւ��͂߂�"},
    {A3RemoveRing,  "R �w�ւ��͂���"}
#else
    {A1Rest,        ". Rest"},
    {A1Search,      "s Search"},
    {A2Inventory,   "i Inventory"},
    {A3Throw    ,   "t Throw"},
    {A3Zap,         "z Zap"},
    {A3Drop,        "d Drop"},
    {A3Wield,       "w Wield"},
    {A3Eat,         "e Eat"},
    {A3Quaff,       "q Quaff"},
    {A1Ascendlevel, "< Ascend level"},
    {A1Descendlevel,"> Descend level"},
    {A1IDTrap,      "^ ID Trap"},
    {A3ReadScroll,  "r Read scroll"},
    {A3TakeOff,     "T Take off"},
    {A3Wear,        "W Wear"},
    {A3PutonRing,   "P Put on ring"},
    {A3RemoveRing,  "R Remove ring"}
#endif
};

char hands[][12] = 
{
#ifdef JP
    "����",
    "�E��",
#else
    "left hand",
    "right hand"
#endif
};

char discover_type[][8] = 
{
#ifdef JP
    "����",
    "����",
    "��",
    "�w��",
#else
    "potion ",
    "scroll ",
    "wand ",
    "ring ",
#endif
};

static int PopupList_sub(ListPtr list, int candidates)
{
    int item;
    int sel = -1, i;
    EventType event;
    FormPtr form;
    RectangleType r, v;
    WinHandle off;
    Word err;

    form = FrmGetActiveForm();

    FrmGetObjectBounds (form, FrmGetObjectIndex(form, MainInvList), &r);

    v = r;
    v.topLeft.x -= 3;
    v.topLeft.y -= 4;
    v.extent.x  += 6;
    v.extent.y  += 8;
    off = WinSaveBits(&v, &err);

    WinEraseRectangle(&r, 0);
    WinDrawRectangleFrame(popupFrame ,&r);

    list->attr.usable = 1;
    LstDrawList(list);

    do {
        EvtGetEvent (&event, evtWaitForever);
        if ( (event.eType == keyDownEvent ) && ((event.data.keyDown.chr == findChr) || (event.data.keyDown.chr == calcChr) || (event.data.keyDown.chr == menuChr))){
            continue;
        } else if ( (event.eType == keyDownEvent ) && ( event.data.keyDown.chr == pageDownChr)){ // scroll down button
            item = LstGetSelection(list);
            item += 1;
            if ( item >= candidates)
                item = candidates-1; // 0
            LstSetSelection(list, item);
        } else if ( (event.eType == keyDownEvent ) && ( event.data.keyDown.chr == pageUpChr)){ // scroll up button
            item = LstGetSelection(list);
            item -= 1;
            if ( item < 0)
                item = 0; // candidates - 1;
            LstSetSelection(list, item);
        } else if ( (event.eType == keyDownEvent ) && ( event.data.keyDown.chr == hard1Chr)){ // cancel
            item = LstGetSelection(list);
            item += 10;
            if ( item >= candidates)
                item = candidates-1;
            LstSetSelection(list, item);
        } else if ( (event.eType == keyDownEvent ) && ( event.data.keyDown.chr == hard2Chr)){ // cancel
            item = LstGetSelection(list);
            item -= 10;
            if ( item < 0)
                item =0;
            LstSetSelection(list, item);
        } else if ( (event.eType == keyDownEvent ) && ( event.data.keyDown.chr == 8)){ // cancel
            sel = -3;
        } else if ( (event.eType == keyDownEvent ) && ( event.data.keyDown.chr == hard3Chr)){ // cancel
            sel = -3;
        } else if ( (event.eType == keyDownEvent ) && ( event.data.keyDown.chr == escapeChr)){ // cancel
            sel = -3;
        } else if ( (event.eType == keyDownEvent ) && ( event.data.keyDown.chr == hard4Chr)){
            sel = LstGetSelection(list);
        } else if ( (event.eType == keyDownEvent ) && ( event.data.keyDown.chr == 10)){ // return
            sel = LstGetSelection(list);
        } else if ( (event.eType == keyDownEvent )&&( event.data.keyDown.chr >= ' ') &&( event.data.keyDown.chr <= 'z')){ // Now search for program names
            for (i = 0; i < candidates; i++) {
                if (invList[i][0] == event.data.keyDown.chr)
                    break;
            }
            if (i != candidates)
                LstSetSelection(list, i);
        } else if ( event.eType == appStopEvent){
            EvtAddEventToQueue( &event ); 
            sel = -2;
        } else if (! SysHandleEvent (&event)){
            if ( !FrmHandleEvent (form,&event)){
                if ( event.eType == lstSelectEvent){
                    sel = event.data.lstSelect.selection;
                } else if ( event.eType == penDownEvent){
                    sel = -2;
                }
            }
        }
    } while (sel == -1);
    SndPlaySystemSound (sndClick);
    LstEraseList(list);
    WinEraseRectangleFrame(popupFrame, &r);
    WinRestoreBits(off, v.topLeft.x, v.topLeft.y);

    if (sel < 0)
        sel = -1;
    return sel;
}

int PopupList(int invMask, int type)
{
    FormPtr form;
    ListPtr list;
    int i, num  = 0, j = 0;
    int ret = -1; // , flg = 0;
    int max[] = {POTIONS, SCROLLS, WANDS, RINGS};
    struct id *id_table[] = {id_potions, id_scrolls, id_wands, id_rings};

    form = FrmGetActiveForm();
    list = FrmGetObjectPtr(form, FrmGetObjectIndex(form, MainInvList));

    switch (type) {
    case 0: // pack list
// _redo:
        invList = (char **) MemPtrNew(MAX_PACK_COUNT * sizeof(char *));
        num = inventory(&rogue.pack, invMask);
        break;
    case 1: // hand list
        num = 2;
        invList = (char **) MemPtrNew(2 * sizeof(char *));
        for (i = 0; i < num; i++) {
            invList[i] = MemPtrNew(12);
            StrCopy(invList[i], hands[i]);
        }
        break;
    case 2: // action list
        num = (int)(sizeof(actions)/sizeof(actions[0])); // 10;
        invList = (char **)MemPtrNew(num * sizeof(char *));
        for (i = 0; i < num; i++)
        {
            invList[i] = (char *)MemPtrNew(20);
            StrCopy(invList[i], actions[i].str);
        }
        break;
    case 3: // type list
        num = (int)(sizeof(discover_type)/sizeof(discover_type[0]));
        invList = (char **)MemPtrNew(num * sizeof(char *));
        for (i = 0; i < num; i++) {
            invList[i] = MemPtrNew(8);
            StrCopy(invList[i], discover_type[i]);
        }
        break;
    case 7: j++;
    case 6: j++;
    case 5: j++;
    case 4: 
        invList = (char **)MemPtrNew(max[j] * sizeof(char *));
        for (i = 0; i < max[j]; i++)
        {
            if (id_table[j][i].id_status == IDENTIFIED) {
                invList[num] = (char *)MemPtrNew(DCOLS * sizeof(char));
#ifdef JP
                StrCopy(invList[num], id_table[j][i].real);
                StrCat(invList[num], discover_type[j]);
#else
                if (j == 2 && game.is_wood[i])
                    StrCopy(invList[num], MESG_006);
                else
                    StrCopy(invList[num], discover_type[j]);
                StrCat(invList[num], id_table[j][i].real);
#endif
                num++;
            }
        }
        break;
    default:
        break;
    }
    
    if (num == 0) {
        MemPtrFree(invList);
        return CANCEL;
    }

    LstSetSelection(list, 0);
    LstSetListChoices(list, invList, num);

#ifndef JP
    if (type == 2)
        list->font = boldFont;
    else
        list->font = stdFont;
#endif

    LstSetHeight(list, (num > 10) ? 10 : num);
    LstMakeItemVisible(list, 0);

    ret = PopupList_sub(list, num);

    switch (type) 
    {
    case 2:
        if (ret != -1)
            ret = actions[ret].id;
        else
            ret = 0;
        break;
    case 1:
    case 0:
        if (invMask)
        {
#if 1
            if (ret != -1)
                ret = invList[ret][0];
            else
                ret = CANCEL;
#else
            if (ret == 0 && !flg) {
                flg = 1;
                goto _redo;
            }
            if (ret != -1)
                ret = invList[ret][0];
            else
                ret = CANCEL;
#endif
        }
        else
        {
            if (ret != -1)
                ret = ret == 0 ? 'l' : 'r';
            else
                ret = CANCEL;
        }
        break;
    default:
        break;
    }

    for (i = 0; i < num; i++)
        MemPtrFree(invList[i]);
    MemPtrFree(invList);

    return ret;
}
