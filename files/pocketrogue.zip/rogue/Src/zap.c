/*
 * zap.c
 *
 * This source herein may be modified and/or distributed by anybody who
 * so desires, with the following restrictions:
 *    1.)  No portion of this notice shall be removed.
 *    2.)  Credit shall not be taken for the creation of this source.
 *    3.)  This code is not to be traded, sold, or used for personal
 *         gain or profit.
 *
 */
    
#include "rogue.h"
    
object *get_missiled_monster(short dir, short *row, short *col);


static object *get_zapped_monster(short int dir, short int *row, short int *col);
static void tele_away(object *monster);

boolean wizard = 0;
char *wiz_passwd = "\253\104\114\266\134\245\000\333\355\064\000";
extern boolean being_held, score_only, detect_monster;


void zapp(short dir)
{
    object *wand;
    short row, col;
    short wch;
    object *monster, *get_missiled_monster();

    check_message();
    if (dir == CANCEL) {
        return;
    }

    if ((wch = pack_letter(MESG_278, WAND)) == CANCEL) {
        return;
    }
        check_message();
    
     if (!(wand = get_letter_object(wch))) {
         message(MESG_279, 0);
         return;
     }
        if (wand->what_is != WAND) {
            message(MESG_280, 0);
            return;
        }

        if (wand->class <= 0) {
            message(MESG_281, 0);
        } else {
            wand->class--;
            row = rogue.row; col = rogue.col;
            if (wand->which_kind == MAGIC_MISSILE) {
                monster = get_missiled_monster(dir, &row, &col);
                mvaddch(rogue.row, rogue.col, rogue.fchar);
                refresh();
                if ((row != rogue.row || col != rogue.col)
                    && rogue_can_see(row, col)) {
                    mvaddch(row, col, get_dungeon_char(row, col));
                }
            } else {
                monster = get_zapped_monster(dir, &row, &col);
            }
            if (monster) {
                wake_up(monster);
                zap_monster(monster, wand->which_kind);
                relight();
            }
        }
    (void) reg_move();
}
        
static object *get_zapped_monster(short int dir, short int *row, short int *col)
{
    short orow, ocol;

    for (;;) {
        orow = *row; ocol = *col;
        get_dir_rc(dir, row, col, 0);
        if (((*row == orow) && (*col == ocol)) ||
            (dungeon[*row][*col] & (HORWALL | VERTWALL)) ||
            (dungeon[*row][*col] == NOTHING)) {
            return(0);
        }
        if (dungeon[*row][*col] & MONSTER) {
            if (!imitating(*row, *col)) {
                return(object_at(&level_monsters, *row, *col));
            }
        }
    }
}

object *
get_missiled_monster(short dir, short *row, short *col)
{
    short orow, ocol, first = 1;

    orow = *row; ocol = *col;
    for (;;) {
        get_dir_rc(dir, row, col, 0);
        if (((*row == orow) && (*col == ocol)) ||
            (dungeon[*row][*col] & (HORWALL | VERTWALL)) ||
            (dungeon[*row][*col] == NOTHING)) {
            *row = orow;
            *col = ocol;
            return(0);
        }
        if (!first && rogue_can_see(orow, ocol))
            mvaddch(orow, ocol,
                    get_dungeon_char(orow, ocol));
        if (rogue_can_see(*row, *col)) {
            if (!(dungeon[*row][*col] & MONSTER))
                mvaddch(*row, *col, '*');
            refresh();
        }
        if (dungeon[*row][*col] & MONSTER) {
            if (!imitating(*row, *col)) {
                return(object_at(&level_monsters, *row, *col));
            }
        }
        first = 0;
        orow = *row; ocol = *col;
    }
}

void zap_monster(object *monster, unsigned short kind)
{
    short row, col;
    object *nm;
    short tc;

    row = monster->row;
    col = monster->col;

    switch(kind) {
    case SLOW_MONSTER:
        if (monster->m_flags & HASTED) {
            monster->m_flags &= (~HASTED);
        } else {
            monster->slowed_toggle = 0;
            monster->m_flags |= SLOWED;
        }
        break;
    case HASTE_MONSTER:
        if (monster->m_flags & SLOWED) {
            monster->m_flags &= (~SLOWED);
        } else {
            monster->m_flags |= HASTED;
        }
        break;
    case TELE_AWAY:
        tele_away(monster);
        break;
    case CONFUSE_MONSTER:
        monster->m_flags |= CONFUSED;
        monster->moves_confused += get_rand(12, 22);
        break;
    case INVISIBILITY:
        monster->m_flags |= INVISIBLE;
        break;
    case POLYMORPH:
        if (monster->m_flags & HOLDS) {
            game.being_held = 0;
        }
        nm = monster->next_monster;
        tc = monster->trail_char;
        (void) gr_monster(monster, get_rand(0, MONSTERS-1));
        monster->row = row;
        monster->col = col;
        monster->next_monster = nm;
        monster->trail_char = tc;
        if (!(monster->m_flags & IMITATES)) {
            wake_up(monster);
        }
        break;
    case PUT_TO_SLEEP:
        monster->m_flags |= (ASLEEP | NAPPING);
        monster->nap_length = get_rand(3, 6);
        break;
    case MAGIC_MISSILE:
        rogue_hit(monster, 1);
        break;
    case CANCELLATION:
        if (monster->m_flags & HOLDS) {
            game.being_held = 0;
        }
        if (monster->m_flags & STEALS_ITEM) {
            monster->drop_percent = 0;
        }
        monster->m_flags &= (~(FLIES | FLITS | SPECIAL_HIT | INVISIBLE |
                               FLAMES | IMITATES | CONFUSES | SEEKS_GOLD | HOLDS));
        break;
    case DO_NOTHING:
        message(MESG_282, 0);
        break;
    }
}
        
static void tele_away(object *monster)
{
    short row, col;
    
    if (monster->m_flags & HOLDS) {
        game.being_held = 0;
    }
    gr_row_col(&row, &col, (FLOOR | TUNNEL | STAIRS | OBJECT));
    mvaddch(monster->row, monster->col,(unsigned char)monster->trail_char);
    dungeon[monster->row][monster->col] &= ~MONSTER;
    monster->row = row; monster->col = col;
    dungeon[row][col] |= MONSTER;
    monster->trail_char = mvinch(row, col);
    if (game.detect_monster || rogue_can_see(row, col)) {
        mvaddch(row, col, gmc(monster));
    }
}
