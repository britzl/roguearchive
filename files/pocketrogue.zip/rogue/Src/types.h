#ifndef __TYPES_H__
#define __TYPES_H__

typedef struct prefs_t {
    char use_hardkeys;
    char dont_remove;
} prefs_t;

struct id {
	short value;
	char *title;
	char *real;
	unsigned short id_status;
};

struct did {
	short value;
	char title[36];
	char real[36];
	unsigned short id_status;
};


struct obj {				/* comment is monster meaning */
	unsigned long m_flags;	/* monster flags */
	char damage[11];		/* damage it does */
	short quantity;			/* hit points to kill */
	short ichar;			/* 'A' is for aquatar */
	short kill_exp;			/* exp for killing it */
	short is_protected;		/* level starts */
	short is_cursed;		/* level ends */
	short class;			/* chance of hitting you */
	short identified;		/* 'F' damage, 1,2,3... */
	unsigned short which_kind; /* item carry/drop % */
	short o_row, o_col, o;	/* o is how many times stuck at o_row, o_col */
	short row, col;			/* current row, col */
	short d_enchant;		/* room char when detect_monster */
	short quiver;			/* monster slowed toggle */
	short trow, tcol;		/* target row, col */
	short hit_enchant;		/* how many moves is confused */
	unsigned short what_is;	/* imitator's charactor (?!%: */
	short picked_up;		/* sleep from wand of sleep */
	unsigned short in_use_flags;
	struct obj *next_object;	/* next monster */
};

typedef struct obj object;


struct fight {
	object *armor;
	object *weapon;
	object *left_ring, *right_ring;
	short hp_current;
	short hp_max;
	short str_current;
	short str_max;
	object pack;
	long gold;
	short exp;
	long exp_points;
	short row, col;
	short fchar;
	short moves_left;
    short x;
	short y;
    boolean gameOver;
};

typedef struct fight fighter;

struct dr {
	short oth_room;
	short oth_row,
	      oth_col;
	short door_row,
		  door_col;
};

typedef struct dr door;

struct rm {
	char bottom_row, right_col, left_col, top_row;
	door doors[4];
	unsigned short is_room;
};

typedef struct rm room;

struct tr {
	short trap_type;
	short trap_row, trap_col;
};

typedef struct tr trap;

struct rogue_time {
	short year;		/* >= 1987 */
	short month;	/* 1 - 12 */
	short day;		/* 1 - 31 */
	short hour;		/* 0 - 23 */
	short minute;	/* 0 - 59 */
	short second;	/* 0 - 59 */
};

struct _win_st {
	short _cury, _curx;
	short _maxy, _maxx;
};

typedef struct _win_st WINDOW;

/** Game data */
struct Game
{
	short cur_level;
	short max_level;
	short party_room;
	short party_counter;
	short foods;
	short cur_room;
	short bear_trap;
	short halluc;
	short blind;
	short confused;
	short levitate;
	short haste_self;
	boolean being_held;
	boolean see_invisible;
	boolean detect_monster;
	boolean is_wood[WANDS];
	short m_moves;
	trap traps[MAX_TRAPS];
};

typedef struct ScoreType
{
    char current;
	long score;
	int level;
	char desc[80];
    char reserved[4];
} ScoreType;


typedef struct ScreenType 
{
    FontID fontID;
    short charWidth;
    short charHeight;
    short width;
    short height;
} ScreenType;


#endif
