/*
 * save.c
 *
 * This source herein may be modified and/or distributed by anybody who
 * so desires, with the following restrictions:
 *    1.)  No portion of this notice shall be removed.
 *    2.)  Credit shall not be taken for the creation of this source.
 *    3.)  This code is not to be traded, sold, or used for personal
 *         gain or profit.
 *
 */

#include "rogue.h"
#include "rogueRsc.h"

static UInt index;

#define REMOVE   0
#define UPDATE   1

static void write_pack(object *pack, DmOpenRef pmDB);
static void read_pack(object *pack, DmOpenRef pmDB, char is_rogue);
static void rw_dungeon(DmOpenRef pmDB, char rw);
static void rw_id_alloc(struct id *id_table, DmOpenRef pmDB, int n, char rw);
static void rw_string(char *s, DmOpenRef pmDB, char rw);
static void rw_rooms(DmOpenRef pmDB, char rw);
static void rw_record(DmOpenRef pmDB, void *buf, int size, char rw);

static void remove_extra_record(DmOpenRef ref)
{
    int num, i;

    num = DmNumRecords(ref);
    if (ALL < num) {
        for (i = num - 1; i >= ALL; i--)
            DmRemoveRecord(ref, i);
    }
}

static char check_save_game(char *fname, ULong type)
{
    DmOpenRef ref;
    int num = 0;

    ref = DmOpenDatabaseByTypeCreator(type, ROGUE, dmModeReadWrite);
    ErrFatalDisplayIf(!ref, "");
    num = DmNumRecords(ref);
    DmCloseDatabase(ref);

    return (num != ALL);
}

char save_game(char *fname, ULong type)
{
    DmOpenRef ref;

    if (type == SAV_TYPE) {
        if (check_save_game(fname, type))
            if (FrmAlert(SaveAlert))
                return 0;

        index = 0;
        rogue.gold = ((rogue.gold * 9) / 10);
        rw_id_table(type, ID_POTIONS, -1, 1);
        rw_id_table(type, ID_SCROLLS, -1, 1);
        rw_id_table(type, ID_WANDS  , -1, 1);
        rw_id_table(type, ID_RINGS  , -1, 1);
    }

    ref = DmOpenDatabaseByTypeCreator(type, ROGUE, dmModeReadWrite);
    ErrFatalDisplayIf(!ref, "");

    remove_extra_record(ref);

    index = ALL;
    rw_record(ref, (char *)&game, sizeof(struct Game), 1);// 1
    rw_string(hunger_str, ref, 1); // 2? �����񒷂��ƕ�����

    write_pack(&level_monsters, ref); // XXX_MONSTER 
    write_pack(&level_objects, ref); // XXX_LEVEL

    rw_dungeon(ref, 1); // 48 - 50
    rw_record(ref, (char *)&rogue, sizeof(fighter), 1); // 1
    write_pack(&rogue.pack, ref); // XXX_PACK pack�̓��e�����o��
    rw_rooms(ref, 1); // 10

    DmCloseDatabase(ref);

    return 1;
}

int restore(ULong type)
{
    DmOpenRef ref;
	int num;
	
    ref = DmOpenDatabaseByTypeCreator(type, ROGUE, dmModeReadWrite);
    if (!ref) return 0;

    num = DmNumRecords(ref);
    if (num == ALL) {
        DmCloseDatabase(ref);
        return 0;
    }

    index = ALL;

    rw_record(ref, (char *)&game, sizeof(struct Game), 0);
    rw_string(hunger_str, ref, 0); //  XXX
    read_pack(&level_monsters, ref, 0); // XXX_MONSTER level_monsters�̓ǂݍ���
    read_pack(&level_objects, ref, 0); // XXX_LEVEL
    rw_dungeon(ref, 0);
    rw_record(ref, (char *) &rogue, sizeof(fighter), 0);
    read_pack(&rogue.pack, ref, 1); // XXX_PACK  pack�̓��e�ǂݏo��
    rw_rooms(ref, 0); 

    if (!prefs.dont_remove)
        remove_extra_record(ref);

    DmCloseDatabase(ref);

	rw_id_table(type, ID_POTIONS, -1, 0);
	rw_id_table(type, ID_SCROLLS, -1, 0);
	rw_id_table(type, ID_WANDS  , -1, 0);
	rw_id_table(type, ID_RINGS  , -1, 0);

    msg_cleared = 1; // 0
    ring_stats(0);

    return 1;
}

static void write_pack(object *pack, DmOpenRef pmDB)
{
    object t;

	pack = pack->next_object;
    while (pack) {
        rw_record(pmDB, (char *)pack, sizeof(object), 1);
        pack = pack->next_object;
    }
    t.ichar = t.what_is = 0;
    rw_record(pmDB, (char *)&t, sizeof(object), 1);
}

static void read_pack(object *pack, DmOpenRef pmDB, char is_rogue)
{
    object read_obj, *new_obj;

    for (;;) {
        rw_record(pmDB, (char *) &read_obj, sizeof(object), 0);

        if (read_obj.ichar == 0) {
            pack->next_object = (object *) 0;
            break;
        }
        new_obj = alloc_object();
        *new_obj = read_obj;
        if (is_rogue) {
            if (new_obj->in_use_flags & BEING_WORN) {
                do_wear(new_obj);
            } else if (new_obj->in_use_flags & BEING_WIELDED) {
                do_wield(new_obj);
            } else if (new_obj->in_use_flags & (ON_EITHER_HAND)) {
                do_put_on(new_obj,
                          ((new_obj->in_use_flags & ON_LEFT_HAND) ? 1 : 0));
            }
        }
        pack->next_object = new_obj;
        pack = new_obj;
    }
}

static void rw_dungeon(DmOpenRef pmDB, char rw)
{
    SnapScreen(rogue.row, rogue.col);
	rw_record(pmDB, dungeon,  sizeof(dungeon), rw);
	rw_record(pmDB, buffer ,  sizeof(buffer), rw);
	rw_record(pmDB, terminal, sizeof(terminal), rw);
}

static void rw_id_alloc(struct id *id_table, DmOpenRef pmDB, int n, char rw)
{
    short i;

    for (i = 0; i < n; i++) {
	    rw_record(pmDB, (char *)&(id_table[i].value), sizeof(short), rw);
        rw_record(pmDB, (char *)&(id_table[i].id_status), sizeof(unsigned short), rw);
        rw_string(id_table[i].title, pmDB, rw);
	}
}

static void rw_string(char *s, DmOpenRef pmDB, char rw)
{
    short n;

	if (rw)
		n = strlen(s) + 1;

	rw_record(pmDB, (char *) &n, sizeof(short), rw);
    rw_record(pmDB, s, n, rw);
}

static void rw_rooms(DmOpenRef pmDB, char rw)
{
	rw_record(pmDB, (char *)(rooms), sizeof(room) * MAXROOMS, rw);
}

static void rw_record(DmOpenRef pmDB, void *buf, int size, char rw)
{
    VoidHand      RecHandle;

	if (rw)
	{
	    RecHandle = DmNewRecord(pmDB, &index, size);
	    DmWrite(MemHandleLock(RecHandle), 0, buf, size);
	}
	else
	{
	    VoidPtr       RecPointer;

	    RecHandle = DmGetRecord(pmDB, index);
	    RecPointer = MemHandleLock(RecHandle);
	    MemMove(buf, RecPointer, size);
	}
    MemHandleUnlock(RecHandle);
    DmReleaseRecord(pmDB, index, true);

    index++;
}
