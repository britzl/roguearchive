/*
 * Super-Rogue
 * Copyright (C) 1984 Robert D. Kindelberger
 * All rights reserved.
 *
 * See the file LICENSE.TXT for full copyright and licensing information.
 */

extern bool My_term,	/* user specied terminal	*/
extern int _tty_ch;	/* channel with tty on it	*/
