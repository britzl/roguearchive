/*
    vers.c - version number
         
    
    XRogue: Expeditions into the Dungeons of Doom
    Copyright (c) 1988, 1992, 2000 Ken Dalka, Mike Morgan and Bob Pietkivitch
    All rights reserved.
    
    Based on "Rogue: Exploring the dungeons of doom"
    Copyright (c) 1981 by Michael Toy, Ken Arnold and Glenn Wichman
    All rights reserved
    
    See the file LICENSE.TXT for full copyright and licensing information
*/

unsigned char encstr[] = "\354\251\243\332A\201|\301\321p\210\251\327\"\257\365t\341%3\271^`~\203z{\341};\f\341\231\222e\234\351]\321";
char version[] = "@(#)vers.c    8.0.1 - 5/1/2000";
char *release = "8.0.1";
