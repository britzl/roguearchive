/*
    network.h  -  networking setup
    
    XRogue: Expeditions into the Dungeons of Doom
    Copyright (c) 1988, 1992, 2000 Ken Dalka, Mike Morgan and Bob Pietkivitch
    All rights reserved.
    
    Based on "Rogue: Exploring the dungeons of doom"
    Copyright (c) 1981 by Michael Toy, Ken Arnold and Glenn Wichman
    All rights reserved
    
    See the file LICENSE.TXT for full copyright and licensing information
*/

/*
 * Note that networking is set up for machines that can communicate
 * via some system such as uucp.  The mechanism listed here uses uux
 * and assumes that the target machine allows access to the game via
 * the uux command.  NETCOMMAND must be defined if networking is desired.
 */

/* #undef  NETCOMMAND "uux - -n '%s!%s -u' >/dev/null 2>&1" */
/* #define NETCOMMAND "usend -s -d%s -uNoLogin -!'%s -u' - 2>/dev/null" */
#undef NETCOMMAND /* "" */

/* Networking information -- should not vary among networking machines */
#ifndef __DJGPP__
#undef  NUMNET
#endif
struct network {
    char *system;
    char *rogue;
};
extern struct network Network[];
