    Welcome to Rogue v3.6.1 (04/29/2000)
    http://roguelike.sourceforge.net/rogue36

    Rogue: Exploring the Dungeons of Doom
    Copyright (c) 1980 Michael Toy and Glenn Wichman
    All rights reserved.

    To play:
        rogue36 [ save_file ]

    Rogue is a computer fantasy game with a new twist.  It is
    crt oriented and the object of the game is to survive the
    attacks of various monsters and get a lot of gold, rather
    than the puzzle solving orientation of most computer fantasy
    games.

    To get started you really only need to know two commands.
    The command ? will give you a list of the available commands
    and the command / will identify the things you see on the
    screen.

    To win the game (as opposed to merely playing to beat other
    people high scores) you must locate the Amulet of Yendor
    which is somewhere below the 20th level of the dungeon and
    get it out.  Few have achieved this yet and if somebody
    does, they go down in history as a hero among heros.

    When the game ends, either by your death, when you quit, or
    if you (by some miracle) manage to win, rogue will give you
    alist of the top-ten scorers.  The scoring is based entirely
    upon how much gold you get.  There is a 10% penalty for
    getting yourself killed.

    For more detailed directions, read the document "A Guide to
    the Dungeons of Doom."

    FILES CREATED

    UNIX:
          /usr/local/games/rogue36/rogue36.scr     Score file
          ~/rogue.sav                              Default save file

    DJGPP (DOS/WINDOWS)
          C:\GAMES\ROGUE36\ROGUE36.SCR       Score file
          rogue.sav                          Default save file


    SEE ALSO
        dod36.txt: Michael C. Toy, "A guide to the Dungeons of Doom"
