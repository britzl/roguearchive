PocketRogue - RogueClone5.3 for Palm/Pilot.
                               TAKEBAYASHI Tomoaki 1999.

- What's is all about?
You've just finished several years of training as a student at the local
fighters guild, and you're now ready to indulge in your first adventure. 

The local guildmasters have decided to send you off into the hideous and
foul Dungeons of Doom, and have asked you to return to town with the 
renowned Amulet of Yendor. If you succeed, you'll become a fully fledged 
member of the fighters guild, and you'll get to keep the booty you 
returned with. You start off your journey with an enchanted mace, a bow, 
a quiver of arrows, elven armour and enough food for you to reach the
 dungeons. 

see official site. (http://www.win.tue.nl/games/roguelike/rogue/index.html)

- How to Play: 

For 8-direction move, use "Tap", "Graffiti", or "Hard Button".
For command, "Menu", "Graffiti", or "Hard Button".

- Command map 

Command Keys 

	h	move left
	j	move down
	k	move up
	l	move right
	y	move up+left
	u	move up+right
	b	move down+left
	n	move down+right
	 Shifted (upper-case) versions of these move you until you hit a wall or
  	object.

    s: search 
    i: inventory 
    f: fight 
    F: fight to the death 
    e: Eat 
    q: Quaff 
    r: Read a scroll 
    d: Drop 
    P: Put on ring 
    R: Remove a ring 
    >: Descend level 
    <: Ascend level 
    ): List weapons 
    ]: List armour 
    =: List rings 
    ^: Identify trap 
    T: Take off 
    W: Wear armour 
    w: Wield weapon 
    z: Zap something 
    t: Throw something 
    v: Version 

- Hard Button's command map. 

-- Playing Game: 

      [DateBook] : search x 10 
      [Address] : move to left 
      [Up/Down] : move to up/down 
      [Todo] : move to right 
      [Memo] : show popup list 
      [Find] : show dungeon map 
      [Calc] : toggle status line 

-- Popuplist 

      [DateBook] : +10 
      [Address] : -10 
      [Up/Down] : +1/-1 
      [To Do] : cancel 
      [MemoPad] : select item 
      [Menu] : none 

- Disclaimer:
 Author makes NO WARRANTY with respect to this software.
 This software is provided AS IS. Please use this at your own risk.
 
Special Thanks to Sam Denton for document. :-)

 Enjoy happy hacking! 
