/*
 * Version number.  Whenever a new version number is desired, use sccs
 * to get vers.c.  encstr is declared here to force it to be loaded
 * before the version number, and therefore not to be written in saved
 * games.
 */

char *release = "5.3";
char encstr[] = "\211g\321_-\251b\324\237;\255\263\214g\"\327\224.,\252|9\265=\357+\343;\311]\341`\251\b\231)\266Y\325\251";
char version[] = "@(#)vers.c	5.3 (NMT version based of Berkeley 5.2) 8/25/83";
