
char datestring[] = "Tue Jul 23 1985";
